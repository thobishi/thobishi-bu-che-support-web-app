/*
 * see COPYRIGHT
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#ifndef WINDOWS
#	include <netinet/in.h>
#	include <unistd.h>
#else
#	include "windows.h"
#endif

#include "ttf.h"
#include "pt1.h"
#include "global.h"

/* big and small values for comparisons */
#define FBIGVAL	(1e20)
#define FEPS	(100000./FBIGVAL)

/* names of the axes */
#define X	0
#define	Y	1

/* the GENTRY extension structure used in fforceconcise() */

struct gex_con {
	double d[2 /*X, Y*/]; /* sizes of curve */
	double sin2; /* squared sinus of the angle to the next gentry */
	double len2; /* squared distance between the endpoints */

/* number of reference dots taken from each curve */
#define NREFDOTS	3

	double dots[NREFDOTS][2]; /* reference dots */

	int flags; /* flags for gentry and tits joint to the next gentry */
/* a vertical or horizontal line may be in 2 quadrants at once */
#define GEXF_QUL	0x00000001 /* in up-left quadrant */
#define GEXF_QUR	0x00000002 /* in up-right quadrant */
#define GEXF_QDR	0x00000004 /* in down-right quadrant */
#define GEXF_QDL	0x00000008 /* in down-left quadrant */
#define GEXF_QMASK	0x0000000F /* quadrant mask */

/* if a line is nearly vertical or horizontal, we remember that idealized quartant too */
#define GEXF_QTO_IDEAL(f)	(((f)&0xF)<<4)
#define GEXF_QFROM_IDEAL(f)	(((f)&0xF0)>>4)
#define GEXF_IDQ_L	0x00000090 /* left */
#define GEXF_IDQ_R	0x00000060 /* right */
#define GEXF_IDQ_U	0x00000030 /* up */
#define GEXF_IDQ_D	0x000000C0 /* down */

/* possibly can be joined with conditions: 
 * (in order of increasing preference, the numeric order is important) 
 */
#define GEXF_JLINE	0x00000100 /* into one line */
#define GEXF_JIGN	0x00000200 /* if one entry's tangent angle is ignored */
#define GEXF_JID	0x00000400 /* if one entry is idealized to hor/vert */
#define GEXF_JFLAT	0x00000800 /* if one entry is flattened */
#define GEXF_JGOOD	0x00001000 /* perfectly, no additional maodifications */

#define GEXF_JMASK	0x00001F00 /* the mask of all above */
#define GEXF_JCVMASK	0x00001E00 /* the mask of all above except JLINE */

/* which entry needs to be modified for conditional joining */
#define GEXF_JIGN1	0x00002000
#define GEXF_JIGN2	0x00004000
#define GEXF_JIGNDIR(dir)	(GEXF_JIGN1<<(dir))
#define GEXF_JID1	0x00008000
#define GEXF_JID2	0x00010000
#define GEXF_JIDDIR(dir)	(GEXF_JID1<<(dir))
#define GEXF_JFLAT1	0x00020000
#define GEXF_JFLAT2	0x00040000
#define GEXF_JFLATDIR(dir)	(GEXF_JFLAT1<<(dir))

#define GEXF_VERT	0x00100000 /* is nearly vertical */
#define GEXF_HOR	0x00200000 /* is nearly horizontal */
#define GEXF_FLAT	0x00400000 /* is nearly flat */

#define GEXF_VDOTS	0x01000000 /* the dots are valid */

	signed char isd[2 /*X,Y*/]; /* signs of the sizes */
};
typedef struct gex_con GEX_CON;

/* convenience macros */
#define	X_CON(ge)	((GEX_CON *)((ge)->ext))
#define X_CON_D(ge)	(X_CON(ge)->d)
#define X_CON_DX(ge)	(X_CON(ge)->d[0])
#define X_CON_DY(ge)	(X_CON(ge)->d[1])
#define X_CON_ISD(ge)	(X_CON(ge)->isd)
#define X_CON_ISDX(ge)	(X_CON(ge)->isd[0])
#define X_CON_ISDY(ge)	(X_CON(ge)->isd[1])
#define X_CON_SIN2(ge)	(X_CON(ge)->sin2)
#define X_CON_LEN2(ge)	(X_CON(ge)->len2)
#define X_CON_F(ge)	(X_CON(ge)->flags)

/* performance statistics about guessing the concise curves */
static int ggoodcv=0, ggoodcvdots=0, gbadcv=0, gbadcvdots=0;

int      stdhw, stdvw;	/* dominant stems widths */
int      stemsnaph[12], stemsnapv[12];	/* most typical stem width */

int      bluevalues[14];
int      nblues;
int      otherblues[10];
int      notherb;
int      bbox[4];	/* the FontBBox array */
double   italic_angle;

GLYPH   *glyph_list;
int    encoding[ENCTABSZ];	/* inverse of glyph[].char_no */
int    kerning_pairs = 0;

/* prototypes */
static void fixcvdir( GENTRY * ge, int dir);
static void fixcvends( GENTRY * ge);
static int fgetcvdir( GENTRY * ge);
static int igetcvdir( GENTRY * ge);
static int fiszigzag( GENTRY *ge);
static int iiszigzag( GENTRY *ge);
static GENTRY * freethisge( GENTRY *ge);
static void addgeafter( GENTRY *oge, GENTRY *nge );
static GENTRY * newgentry( int flags);
static void debugstems( char *name, STEM * hstems, int nhs, STEM * vstems, int nvs);
static int addbluestems( STEM *s, int n);
static void sortstems( STEM * s, int n);
static int stemoverlap( STEM * s1, STEM * s2);
static int steminblue( STEM *s);
static void markbluestems( STEM *s, int nold);
static int joinmainstems( STEM * s, int nold, int useblues);
static void joinsubstems( STEM * s, short *pairs, int nold, int useblues);
static void fixendpath( GENTRY *ge);
static void fdelsmall( GLYPH *g, double minlen);
static void alloc_gex_con( GENTRY *ge);
static double fjointsin2( GENTRY *ge1, GENTRY *ge2);
static double fcvarea( GENTRY *ge);
static double fcvval( GENTRY *ge, int axis, double t);
static void fsampledots( GENTRY *ge, double dots[][2], int ndots);
static void fnormalizege( GENTRY *ge);
static void fanalyzege( GENTRY *ge);
static void fanalyzejoint( GENTRY *ge);
static void fconcisecontour( GLYPH *g, GENTRY *ge);
static double fclosegap( GENTRY *from, GENTRY *to, int axis,
	double gap, double *ret);

int
isign(
     int x
)
{
	if (x > 0)
		return 1;
	else if (x < 0)
		return -1;
	else
		return 0;
}

int
fsign(
     double x
)
{
	if (x > 0.0)
		return 1;
	else if (x < 0.0)
		return -1;
	else
		return 0;
}

static GENTRY *
newgentry(
	int flags
)
{
	GENTRY         *ge;

	ge = calloc(1, sizeof(GENTRY));

	if (ge == 0) {
		fprintf(stderr, "***** Memory allocation error *****\n");
		exit(255);
	}
	ge->stemid = -1;
	ge->flags = flags;
	/* the rest is set to 0 by calloc() */
	return ge;
}

/*
 * Routines to print out Postscript functions with optimization
 */

void
rmoveto(
	int dx,
	int dy
)
{
	if (optimize && dx == 0)
		fprintf(pfa_file, "%d vmoveto\n", dy);
	else if (optimize && dy == 0)
		fprintf(pfa_file, "%d hmoveto\n", dx);
	else
		fprintf(pfa_file, "%d %d rmoveto\n", dx, dy);
}

void
rlineto(
	int dx,
	int dy
)
{
	if (optimize && dx == 0 && dy == 0)	/* for special pathologic
						 * case */
		return;
	else if (optimize && dx == 0)
		fprintf(pfa_file, "%d vlineto\n", dy);
	else if (optimize && dy == 0)
		fprintf(pfa_file, "%d hlineto\n", dx);
	else
		fprintf(pfa_file, "%d %d rlineto\n", dx, dy);
}

void
rrcurveto(
	  int dx1,
	  int dy1,
	  int dx2,
	  int dy2,
	  int dx3,
	  int dy3
)
{
	/* first two ifs are for crazy cases that occur surprisingly often */
	if (optimize && dx1 == 0 && dx2 == 0 && dx3 == 0)
		rlineto(0, dy1 + dy2 + dy3);
	else if (optimize && dy1 == 0 && dy2 == 0 && dy3 == 0)
		rlineto(dx1 + dx2 + dx3, 0);
	else if (optimize && dy1 == 0 && dx3 == 0)
		fprintf(pfa_file, "%d %d %d %d hvcurveto\n",
			dx1, dx2, dy2, dy3);
	else if (optimize && dx1 == 0 && dy3 == 0)
		fprintf(pfa_file, "%d %d %d %d vhcurveto\n",
			dy1, dx2, dy2, dx3);
	else
		fprintf(pfa_file, "%d %d %d %d %d %d rrcurveto\n",
			dx1, dy1, dx2, dy2, dx3, dy3);
}

void
closepath(void)
{
	fprintf(pfa_file, "closepath\n");
}

/*
 * Many of the path processing routines exist (or will exist) in
 * both floating-point and integer version. Fimally most of the
 * processing will go in floating point and the integer processing
 * will become legacy.
 * The names of floating routines start with f, names of integer 
 * routines start with i, and those old routines existing in one 
 * version only have no such prefix at all.
 */

/*
** Routine that checks integrity of the path, for debugging
*/

void
assertpath(
	   GENTRY * from,
	   char *file,
	   int line,
	   char *name
)
{
	GENTRY         *first, *pe, *ge;
	int	isfloat;

	if(from==0)
		return;
	isfloat = (from->flags & GEF_FLOAT);
	pe = from->prev;
	for (ge = from; ge != 0; pe = ge, ge = ge->next) {
		if( (ge->flags & GEF_FLOAT) ^ isfloat ) {
			fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
			fprintf(stderr, "float flag changes from %s to %s at 0x%p (type %c, prev type %c)\n",
				(isfloat ? "TRUE" : "FALSE"), (isfloat ? "FALSE" : "TRUE"), ge, ge->type, pe->type);
			abort();
		}
		if (pe != ge->prev) {
			fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
			fprintf(stderr, "unidirectional chain 0x%x -next-> 0x%x -prev-> 0x%x \n",
				(unsigned int)pe, (unsigned int)ge, (unsigned int)ge->prev);
			abort();
		}

		switch(ge->type) {
		case GE_MOVE:
			break;
		case GE_PATH:
			if (ge->prev == 0) {
				fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
				fprintf(stderr, "empty path at 0x%x \n", (unsigned int)ge);
				abort();
			}
			break;
		case GE_LINE:
		case GE_CURVE:
			if(ge->frwd->bkwd != ge) {
				fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
				fprintf(stderr, "unidirectional chain 0x%x -frwd-> 0x%x -bkwd-> 0x%x \n",
					(unsigned int)ge, (unsigned int)ge->frwd, (unsigned int)ge->frwd->bkwd);
				abort();
			}
			if(ge->prev->type == GE_MOVE) {
				first = ge;
				if(ge->bkwd->next->type != GE_PATH) {
					fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
					fprintf(stderr, "broken first backlink 0x%x -bkwd-> 0x%x -next-> 0x%x \n",
						(unsigned int)ge, (unsigned int)ge->bkwd, (unsigned int)ge->bkwd->next);
					abort();
				}
			}
			if(ge->next->type == GE_PATH) {
				if(ge->frwd != first) {
					fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
					fprintf(stderr, "broken loop 0x%x -...-> 0x%x -frwd-> 0x%x \n",
						(unsigned int)first, (unsigned int)ge, (unsigned int)ge->frwd);
					abort();
				}
			}
			break;
		}

	}
}

void
assertisfloat(
	GLYPH *g,
	char *msg
)
{
	if( !(g->flags & GF_FLOAT) ) {
		fprintf(stderr, "**! Glyph %s is not float: %s\n", g->name, msg);
		abort();
	}
	if(g->lastentry) {
		if( !(g->lastentry->flags & GEF_FLOAT) ) {
			fprintf(stderr, "**! Glyphs %s last entry is int: %s\n", g->name, msg);
			abort();
		}
	}
}

void
assertisint(
	GLYPH *g,
	char *msg
)
{
	if( (g->flags & GF_FLOAT) ) {
		fprintf(stderr, "**! Glyph %s is not int: %s\n", g->name, msg);
		abort();
	}
	if(g->lastentry) {
		if( (g->lastentry->flags & GEF_FLOAT) ) {
			fprintf(stderr, "**! Glyphs %s last entry is float: %s\n", g->name, msg);
			abort();
		}
	}
}


/*
 * Routines to save the generated data about glyph
 */

void
fg_rmoveto(
	  GLYPH * g,
	  double x,
	  double y)
{
	GENTRY         *oge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: f rmoveto(%g, %g)\n", g->name, x, y);

	assertisfloat(g, "adding float MOVE");

	if ((oge = g->lastentry) != 0) {
		if (oge->type == GE_MOVE) {	/* just eat up the first move */
			oge->fx3 = x;
			oge->fy3 = y;
		} else if (oge->type == GE_LINE || oge->type == GE_CURVE) {
			fprintf(stderr, "Glyph %s: MOVE in middle of path\n", g->name);
		} else {
			GENTRY         *nge;

			nge = newgentry(GEF_FLOAT);
			nge->type = GE_MOVE;
			nge->fx3 = x;
			nge->fy3 = y;

			oge->next = nge;
			nge->prev = oge;
			g->lastentry = nge;
		}
	} else {
		GENTRY         *nge;

		nge = newgentry(GEF_FLOAT);
		nge->type = GE_MOVE;
		nge->fx3 = x;
		nge->fy3 = y;
		nge->bkwd = (GENTRY*)&g->entries;
		g->entries = g->lastentry = nge;
	}

	if (0 && ISDBG(BUILDG))
		dumppaths(g, NULL, NULL);
}

void
ig_rmoveto(
	  GLYPH * g,
	  int x,
	  int y)
{
	GENTRY         *oge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: i rmoveto(%d, %d)\n", g->name, x, y);

	assertisint(g, "adding int MOVE");

	if ((oge = g->lastentry) != 0) {
		if (oge->type == GE_MOVE) {	/* just eat up the first move */
			oge->ix3 = x;
			oge->iy3 = y;
		} else if (oge->type == GE_LINE || oge->type == GE_CURVE) {
			fprintf(stderr, "Glyph %s: MOVE in middle of path, ignored\n", g->name);
		} else {
			GENTRY         *nge;

			nge = newgentry(0);
			nge->type = GE_MOVE;
			nge->ix3 = x;
			nge->iy3 = y;

			oge->next = nge;
			nge->prev = oge;
			g->lastentry = nge;
		}
	} else {
		GENTRY         *nge;

		nge = newgentry(0);
		nge->type = GE_MOVE;
		nge->ix3 = x;
		nge->iy3 = y;
		nge->bkwd = (GENTRY*)&g->entries;
		g->entries = g->lastentry = nge;
	}

}

void
fg_rlineto(
	  GLYPH * g,
	  double x,
	  double y)
{
	GENTRY         *oge, *nge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: f rlineto(%g, %g)\n", g->name, x, y);

	assertisfloat(g, "adding float LINE");

	nge = newgentry(GEF_FLOAT);
	nge->type = GE_LINE;
	nge->fx3 = x;
	nge->fy3 = y;

	if ((oge = g->lastentry) != 0) {
		if (x == oge->fx3 && y == oge->fy3) {	/* empty line */
			/* ignore it or we will get in troubles later */
			free(nge);
			return;
		}
		if (g->path == 0) {
			g->path = nge;
			nge->bkwd = nge->frwd = nge;
		} else {
			oge->frwd = nge;
			nge->bkwd = oge;
			g->path->bkwd = nge;
			nge->frwd = g->path;
		}

		oge->next = nge;
		nge->prev = oge;
		g->lastentry = nge;
	} else {
		WARNING_1 fprintf(stderr, "Glyph %s: LINE outside of path\n", g->name);
		free(nge);
	}

	if (0 && ISDBG(BUILDG))
		dumppaths(g, NULL, NULL);
}

void
ig_rlineto(
	  GLYPH * g,
	  int x,
	  int y)
{
	GENTRY         *oge, *nge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: i rlineto(%d, %d)\n", g->name, x, y);

	assertisint(g, "adding int LINE");

	nge = newgentry(0);
	nge->type = GE_LINE;
	nge->ix3 = x;
	nge->iy3 = y;

	if ((oge = g->lastentry) != 0) {
		if (x == oge->ix3 && y == oge->iy3) {	/* empty line */
			/* ignore it or we will get in troubles later */
			free(nge);
			return;
		}
		if (g->path == 0) {
			g->path = nge;
			nge->bkwd = nge->frwd = nge;
		} else {
			oge->frwd = nge;
			nge->bkwd = oge;
			g->path->bkwd = nge;
			nge->frwd = g->path;
		}

		oge->next = nge;
		nge->prev = oge;
		g->lastentry = nge;
	} else {
		WARNING_1 fprintf(stderr, "Glyph %s: LINE outside of path\n", g->name);
		free(nge);
	}

}

void
fg_rrcurveto(
	    GLYPH * g,
	    double x1,
	    double y1,
	    double x2,
	    double y2,
	    double x3,
	    double y3)
{
	GENTRY         *oge, *nge;

	oge = g->lastentry;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: f rrcurveto(%g, %g, %g, %g, %g, %g)\n"
			,g->name, x1, y1, x2, y2, x3, y3);

	assertisfloat(g, "adding float CURVE");

	if (oge && oge->fx3 == x1 && x1 == x2 && x2 == x3)	/* check if it's
								 * actually a line */
		fg_rlineto(g, x1, y3);
	else if (oge && oge->fy3 == y1 && y1 == y2 && y2 == y3)
		fg_rlineto(g, x3, y1);
	else {
		nge = newgentry(GEF_FLOAT);
		nge->type = GE_CURVE;
		nge->fx1 = x1;
		nge->fy1 = y1;
		nge->fx2 = x2;
		nge->fy2 = y2;
		nge->fx3 = x3;
		nge->fy3 = y3;

		if (oge != 0) {
			if (x3 == oge->fx3 && y3 == oge->fy3) {
				free(nge);	/* consider this curve empty */
				/* ignore it or we will get in troubles later */
				return;
			}
			if (g->path == 0) {
				g->path = nge;
				nge->bkwd = nge->frwd = nge;
			} else {
				oge->frwd = nge;
				nge->bkwd = oge;
				g->path->bkwd = nge;
				nge->frwd = g->path;
			}

			oge->next = nge;
			nge->prev = oge;
			g->lastentry = nge;
		} else {
			WARNING_1 fprintf(stderr, "Glyph %s: CURVE outside of path\n", g->name);
			free(nge);
		}
	}

	if (0 && ISDBG(BUILDG))
		dumppaths(g, NULL, NULL);
}

void
ig_rrcurveto(
	    GLYPH * g,
	    int x1,
	    int y1,
	    int x2,
	    int y2,
	    int x3,
	    int y3)
{
	GENTRY         *oge, *nge;

	oge = g->lastentry;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: i rrcurveto(%d, %d, %d, %d, %d, %d)\n"
			,g->name, x1, y1, x2, y2, x3, y3);

	assertisint(g, "adding int CURVE");

	if (oge && oge->ix3 == x1 && x1 == x2 && x2 == x3)	/* check if it's
								 * actually a line */
		ig_rlineto(g, x1, y3);
	else if (oge && oge->iy3 == y1 && y1 == y2 && y2 == y3)
		ig_rlineto(g, x3, y1);
	else {
		nge = newgentry(0);
		nge->type = GE_CURVE;
		nge->ix1 = x1;
		nge->iy1 = y1;
		nge->ix2 = x2;
		nge->iy2 = y2;
		nge->ix3 = x3;
		nge->iy3 = y3;

		if (oge != 0) {
			if (x3 == oge->ix3 && y3 == oge->iy3) {
				free(nge);	/* consider this curve empty */
				/* ignore it or we will get in troubles later */
				return;
			}
			if (g->path == 0) {
				g->path = nge;
				nge->bkwd = nge->frwd = nge;
			} else {
				oge->frwd = nge;
				nge->bkwd = oge;
				g->path->bkwd = nge;
				nge->frwd = g->path;
			}

			oge->next = nge;
			nge->prev = oge;
			g->lastentry = nge;
		} else {
			WARNING_1 fprintf(stderr, "Glyph %s: CURVE outside of path\n", g->name);
			free(nge);
		}
	}
}

void
g_closepath(
	    GLYPH * g
)
{
	GENTRY         *oge, *nge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: closepath\n", g->name);

	oge = g->lastentry;

	if (g->path == 0) {
		WARNING_1 fprintf(stderr, "Warning: **** closepath on empty path in glyph \"%s\" ****\n",
			g->name);
		if (oge == 0) {
			WARNING_1 fprintf(stderr, "No previois entry\n");
		} else {
			WARNING_1 fprintf(stderr, "Previous entry type: %c\n", oge->type);
			if (oge->type == GE_MOVE) {
				g->lastentry = oge->prev;
				if (oge->prev == 0)
					g->entries = 0;
				else
					g->lastentry->next = 0;
				free(oge);
			}
		}
		return;
	}

	nge = newgentry(oge->flags & GEF_FLOAT); /* keep the same type */
	nge->type = GE_PATH;

	g->path = 0;

	oge->next = nge;
	nge->prev = oge;
	g->lastentry = nge;

	if (0 && ISDBG(BUILDG))
		dumppaths(g, NULL, NULL);
}

/*
 * * SB * Routines to smooth and fix the glyphs
 */

/*
** we don't want to see the curves with coinciding middle and
** outer points
*/

static void
fixcvends(
	  GENTRY * ge
)
{
	int             dx, dy;
	int             x0, y0, x1, y1, x2, y2, x3, y3;

	if (ge->type != GE_CURVE)
		return;

	if(ge->flags & GEF_FLOAT) {
		fprintf(stderr, "**! fixcvends(0x%x) on floating entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	x0 = ge->prev->ix3;
	y0 = ge->prev->iy3;
	x1 = ge->ix1;
	y1 = ge->iy1;
	x2 = ge->ix2;
	y2 = ge->iy2;
	x3 = ge->ix3;
	y3 = ge->iy3;


	/* look at the start of the curve */
	if (x1 == x0 && y1 == y0) {
		dx = x2 - x1;
		dy = y2 - y1;

		if (dx == 0 && dy == 0
		    || x2 == x3 && y2 == y3) {
			/* Oops, we actually have a straight line */
			/*
			 * if it's small, we hope that it will get optimized
			 * later
			 */
			if (abs(x3 - x0) <= 2 || abs(y3 - y0) <= 2) {
				ge->ix1 = x3;
				ge->iy1 = y3;
				ge->ix2 = x0;
				ge->iy2 = y0;
			} else {/* just make it a line */
				ge->type = GE_LINE;
			}
		} else {
			if (abs(dx) < 4 && abs(dy) < 4) {	/* consider it very
								 * small */
				ge->ix1 = x2;
				ge->iy1 = y2;
			} else if (abs(dx) < 8 && abs(dy) < 8) {	/* consider it small */
				ge->ix1 += dx / 2;
				ge->iy1 += dy / 2;
			} else {
				ge->ix1 += dx / 4;
				ge->iy1 += dy / 4;
			}
			/* make sure that it's still on the same side */
			if (abs(x3 - x0) * abs(dy) < abs(y3 - y0) * abs(dx)) {
				if (abs(x3 - x0) * abs(ge->iy1 - y0) > abs(y3 - y0) * abs(ge->ix1 - x0))
					ge->ix1 += isign(dx);
			} else {
				if (abs(x3 - x0) * abs(ge->iy1 - y0) < abs(y3 - y0) * abs(ge->ix1 - x0))
					ge->iy1 += isign(dy);
			}

			ge->ix2 += (x3 - x2) / 8;
			ge->iy2 += (y3 - y2) / 8;
			/* make sure that it's still on the same side */
			if (abs(x3 - x0) * abs(y3 - y2) < abs(y3 - y0) * abs(x3 - x2)) {
				if (abs(x3 - x0) * abs(y3 - ge->iy2) > abs(y3 - y0) * abs(x3 - ge->ix2))
					ge->iy1 -= isign(y3 - y2);
			} else {
				if (abs(x3 - x0) * abs(y3 - ge->iy2) < abs(y3 - y0) * abs(x3 - ge->ix2))
					ge->ix1 -= isign(x3 - x2);
			}

		}
	} else if (x2 == x3 && y2 == y3) {
		dx = x1 - x2;
		dy = y1 - y2;

		if (dx == 0 && dy == 0) {
			/* Oops, we actually have a straight line */
			/*
			 * if it's small, we hope that it will get optimized
			 * later
			 */
			if (abs(x3 - x0) <= 2 || abs(y3 - y0) <= 2) {
				ge->ix1 = x3;
				ge->iy1 = y3;
				ge->ix2 = x0;
				ge->iy2 = y0;
			} else {/* just make it a line */
				ge->type = GE_LINE;
			}
		} else {
			if (abs(dx) < 4 && abs(dy) < 4) {	/* consider it very
								 * small */
				ge->ix2 = x1;
				ge->iy2 = y1;
			} else if (abs(dx) < 8 && abs(dy) < 8) {	/* consider it small */
				ge->ix2 += dx / 2;
				ge->iy2 += dy / 2;
			} else {
				ge->ix2 += dx / 4;
				ge->iy2 += dy / 4;
			}
			/* make sure that it's still on the same side */
			if (abs(x3 - x0) * abs(dy) < abs(y3 - y0) * abs(dx)) {
				if (abs(x3 - x0) * abs(ge->iy2 - y3) > abs(y3 - y0) * abs(ge->ix2 - x3))
					ge->ix2 += isign(dx);
			} else {
				if (abs(x3 - x0) * abs(ge->iy2 - y3) < abs(y3 - y0) * abs(ge->ix2 - x3))
					ge->iy2 += isign(dy);
			}

			ge->ix1 += (x0 - x1) / 8;
			ge->iy1 += (y0 - y1) / 8;
			/* make sure that it's still on the same side */
			if (abs(x3 - x0) * abs(y0 - y1) < abs(y3 - y0) * abs(x0 - x1)) {
				if (abs(x3 - x0) * abs(y0 - ge->iy1) > abs(y3 - y0) * abs(x0 - ge->ix1))
					ge->iy1 -= isign(y0 - y1);
			} else {
				if (abs(x3 - x0) * abs(y0 - ge->iy1) < abs(y3 - y0) * abs(x0 - ge->ix1))
					ge->ix1 -= isign(x0 - x1);
			}

		}
	}
}

/*
** After transformations we want to make sure that the resulting
** curve is going in the same quadrant as the original one,
** because rounding errors introduced during transformations
** may make the result completeley wrong.
**
** `dir' argument describes the direction of the original curve,
** it is the superposition of two values for the front and
** rear ends of curve:
**
** >EQUAL - goes over the line connecting the ends
** =EQUAL - coincides with the line connecting the ends
** <EQUAL - goes under the line connecting the ends
**
** See CVDIR_* for exact definitions.
*/

static void
fixcvdir(
	 GENTRY * ge,
	 int dir
)
{
	int             a, b, c, d;
	double          kk, kk1, kk2;
	int             changed;
	int             fdir, rdir;

	if(ge->flags & GEF_FLOAT) {
		fprintf(stderr, "**! fixcvdir(0x%x) on floating entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	fdir = (dir & CVDIR_FRONT) - CVDIR_FEQUAL;
	if ((dir & CVDIR_REAR) == CVDIR_RSAME)
		rdir = fdir; /* we need only isign, exact value doesn't matter */
	else
		rdir = (dir & CVDIR_REAR) - CVDIR_REQUAL;

	fixcvends(ge);

	c = isign(ge->ix3 - ge->prev->ix3);	/* note the direction of
						 * curve */
	d = isign(ge->iy3 - ge->prev->iy3);

	a = ge->iy3 - ge->prev->iy3;
	b = ge->ix3 - ge->prev->ix3;
	kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
	a = ge->iy1 - ge->prev->iy3;
	b = ge->ix1 - ge->prev->ix3;
	kk1 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
	a = ge->iy3 - ge->iy2;
	b = ge->ix3 - ge->ix2;
	kk2 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));

	changed = 1;
	while (changed) {
		if (ISDBG(FIXCVDIR)) {
			/* for debugging */
			fprintf(stderr, "fixcvdir %d %d (%d %d %d %d %d %d) %f %f %f\n",
				fdir, rdir,
				ge->ix1 - ge->prev->ix3,
				ge->iy1 - ge->prev->iy3,
				ge->ix2 - ge->ix1,
				ge->iy2 - ge->iy1,
				ge->ix3 - ge->ix2,
				ge->iy3 - ge->iy2,
				kk1, kk, kk2);
		}
		changed = 0;

		if (fdir > 0) {
			if (kk1 > kk) {	/* the front end has problems */
				if (c * (ge->ix1 - ge->prev->ix3) > 0) {
					ge->ix1 -= c;
					changed = 1;
				} if (d * (ge->iy2 - ge->iy1) > 0) {
					ge->iy1 += d;
					changed = 1;
				}
				/* recalculate the coefficients */
				a = ge->iy3 - ge->prev->iy3;
				b = ge->ix3 - ge->prev->ix3;
				kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
				a = ge->iy1 - ge->prev->iy3;
				b = ge->ix1 - ge->prev->ix3;
				kk1 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
			}
		} else if (fdir < 0) {
			if (kk1 < kk) {	/* the front end has problems */
				if (c * (ge->ix2 - ge->ix1) > 0) {
					ge->ix1 += c;
					changed = 1;
				} if (d * (ge->iy1 - ge->prev->iy3) > 0) {
					ge->iy1 -= d;
					changed = 1;
				}
				/* recalculate the coefficients */
				a = ge->iy1 - ge->prev->iy3;
				b = ge->ix1 - ge->prev->ix3;
				kk1 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
				a = ge->iy3 - ge->prev->iy3;
				b = ge->ix3 - ge->prev->ix3;
				kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
			}
		}
		if (rdir > 0) {
			if (kk2 < kk) {	/* the rear end has problems */
				if (c * (ge->ix2 - ge->ix1) > 0) {
					ge->ix2 -= c;
					changed = 1;
				} if (d * (ge->iy3 - ge->iy2) > 0) {
					ge->iy2 += d;
					changed = 1;
				}
				/* recalculate the coefficients */
				a = ge->iy3 - ge->prev->iy3;
				b = ge->ix3 - ge->prev->ix3;
				kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
				a = ge->iy3 - ge->iy2;
				b = ge->ix3 - ge->ix2;
				kk2 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
			}
		} else if (rdir < 0) {
			if (kk2 > kk) {	/* the rear end has problems */
				if (c * (ge->ix3 - ge->ix2) > 0) {
					ge->ix2 += c;
					changed = 1;
				} if (d * (ge->iy2 - ge->iy1) > 0) {
					ge->iy2 -= d;
					changed = 1;
				}
				/* recalculate the coefficients */
				a = ge->iy3 - ge->prev->iy3;
				b = ge->ix3 - ge->prev->ix3;
				kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
				a = ge->iy3 - ge->iy2;
				b = ge->ix3 - ge->ix2;
				kk2 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
			}
		}
	}
	fixcvends(ge);
}

/* Get the directions of ends of curve for further usage */

/* expects that the previous element is also float */

static int
fgetcvdir(
	 GENTRY * ge
)
{
	double          a, b;
	double          k, k1, k2;
	int             dir = 0;

	if( !(ge->flags & GEF_FLOAT) ) {
		fprintf(stderr, "**! fgetcvdir(0x%x) on int entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	a = fabs(ge->fy3 - ge->prev->fy3);
	b = fabs(ge->fx3 - ge->prev->fx3);
	k = a < FEPS ? (b < FEPS ? 1. : 100000.) : ( b / a);

	a = fabs(ge->fy1 - ge->prev->fy3);
	b = fabs(ge->fx1 - ge->prev->fx3);
	if(a < FEPS) {
		if(b < FEPS) {
			a = fabs(ge->fy2 - ge->prev->fy3);
			b = fabs(ge->fx2 - ge->prev->fx3);
			k1 = a < FEPS ? (b < FEPS ? k : 100000.) : ( b / a);
		} else
			k1 = FBIGVAL;
	} else
		k1 = b / a;

	a = fabs(ge->fy3 - ge->fy2);
	b = fabs(ge->fx3 - ge->fx2);
	if(a < FEPS) {
		if(b < FEPS) {
			a = fabs(ge->fy3 - ge->fy1);
			b = fabs(ge->fx3 - ge->fx1);
			k2 = a < FEPS ? (b < FEPS ? k : 100000.) : ( b / a);
		} else
			k2 = FBIGVAL;
	} else
		k2 = b / a;

	if(fabs(k1-k) < 0.0001)
		dir |= CVDIR_FEQUAL;
	else if (k1 < k)
		dir |= CVDIR_FUP;
	else
		dir |= CVDIR_FDOWN;

	if(fabs(k2-k) < 0.0001)
		dir |= CVDIR_REQUAL;
	else if (k2 > k)
		dir |= CVDIR_RUP;
	else
		dir |= CVDIR_RDOWN;

	return dir;
}


/* expects that the previous element is also int */

static int
igetcvdir(
	 GENTRY * ge
)
{
	int             a, b;
	double          k, k1, k2;
	int             dir = 0;

	if(ge->flags & GEF_FLOAT) {
		fprintf(stderr, "**! igetcvdir(0x%x) on floating entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	a = ge->iy3 - ge->prev->iy3;
	b = ge->ix3 - ge->prev->ix3;
	k = (a == 0) ? (b == 0 ? 1. : 100000.) : fabs((double) b / (double) a);

	a = ge->iy1 - ge->prev->iy3;
	b = ge->ix1 - ge->prev->ix3;
	if(a == 0) {
		if(b == 0) {
			a = ge->iy2 - ge->prev->iy3;
			b = ge->ix2 - ge->prev->ix3;
			k1 = (a == 0) ? (b == 0 ? k : 100000.) : fabs((double) b / (double) a);
		} else
			k1 = FBIGVAL;
	} else
		k1 = fabs((double) b / (double) a);

	a = ge->iy3 - ge->iy2;
	b = ge->ix3 - ge->ix2;
	if(a == 0) {
		if(b == 0) {
			a = ge->iy3 - ge->iy1;
			b = ge->ix3 - ge->ix1;
			k2 = (a == 0) ? (b == 0 ? k : 100000.) : fabs((double) b / (double) a);
		} else
			k2 = FBIGVAL;
	} else
		k2 = fabs((double) b / (double) a);

	if(fabs(k1-k) < 0.0001)
		dir |= CVDIR_FEQUAL;
	else if (k1 < k)
		dir |= CVDIR_FUP;
	else
		dir |= CVDIR_FDOWN;

	if(fabs(k2-k) < 0.0001)
		dir |= CVDIR_REQUAL;
	else if (k2 > k)
		dir |= CVDIR_RUP;
	else
		dir |= CVDIR_RDOWN;

	return dir;
}

#if 0
/* a function just to test the work of fixcvdir() */
static void
testfixcvdir(
	     GLYPH * g
)
{
	GENTRY         *ge;
	int             dir;

	for (ge = g->entries; ge != 0; ge = ge->next) {
		if (ge->type == GE_CURVE) {
			dir = igetcvdir(ge);
			fixcvdir(ge, dir);
		}
	}
}
#endif

static int
iround(
	double val
)
{
	return (int) (val > 0 ? val + 0.5 : val - 0.5);
}
	
/* for debugging - dump the glyph
 * mark with a star the entries from start to end inclusive
 * (start == NULL means don't mark any, end == NULL means to the last)
 */

void
dumppaths(
	GLYPH *g,
	GENTRY *start,
	GENTRY *end
)
{
	GENTRY *ge;
	int i;
	char mark=' ';

	fprintf(stderr, "Glyph %s:\n", g->name);

	/* now do the conversion */
	for(ge = g->entries; ge != 0; ge = ge->next) {
		if(ge == start)
			mark = '*';
		fprintf(stderr, " %c %8x", mark, (unsigned int)ge);
		switch(ge->type) {
		case GE_MOVE:
		case GE_LINE:
			if(ge->flags & GEF_FLOAT)
				fprintf(stderr," %c float (%g, %g)\n", ge->type, ge->fx3, ge->fy3);
			else
				fprintf(stderr," %c int (%d, %d)\n", ge->type, ge->ix3, ge->iy3);
			break;
		case GE_CURVE:
			if(ge->flags & GEF_FLOAT) {
				fprintf(stderr," C float ");
				for(i=0; i<3; i++)
					fprintf(stderr,"(%g, %g) ", ge->fxn[i], ge->fyn[i]);
				fprintf(stderr,"\n");
			} else {
				fprintf(stderr," C int ");
				for(i=0; i<3; i++)
					fprintf(stderr,"(%d, %d) ", ge->ixn[i], ge->iyn[i]);
				fprintf(stderr,"\n");
			}
			break;
		default:
			fprintf(stderr, " %c\n", ge->type);
			break;
		}
		if(ge == end)
			mark = ' ';
	}
}

/*
 * Routine that converts all entries in the path from float to int
 */

void
pathtoint(
	GLYPH *g
)
{
	GENTRY *ge;
	int x[3], y[3];
	int i;


	if(ISDBG(TOINT))
		fprintf(stderr, "TOINT: glyph %s\n", g->name);
	assertisfloat(g, "converting path to int\n");

	fdelsmall(g, 1.0); /* get rid of sub-pixel contours */
	assertpath(g->entries, __FILE__, __LINE__, g->name);

	/* 1st pass, collect the directions of the curves: have
	 * to do that in advance, while everyting is float
	 */
	for(ge = g->entries; ge != 0; ge = ge->next) {
		if( !(ge->flags & GEF_FLOAT) ) {
			fprintf(stderr, "**! glyphs %s has int entry, found in conversion to int\n",
				g->name);
			exit(1);
		}
		if(ge->type == GE_CURVE) {
			ge->dir = fgetcvdir(ge);
		}
	}

	/* now do the conversion */
	for(ge = g->entries; ge != 0; ge = ge->next) {
		switch(ge->type) {
		case GE_MOVE:
		case GE_LINE:
			if(ISDBG(TOINT))
				fprintf(stderr," %c float x=%g y=%g\n", ge->type, ge->fx3, ge->fy3);
			x[0] = iround(ge->fx3);
			y[0] = iround(ge->fy3);
			for(i=0; i<3; i++) { /* put some valid values everywhere, for convenience */
				ge->ixn[i] = x[0];
				ge->iyn[i] = y[0];
			}
			if(ISDBG(TOINT))
				fprintf(stderr,"   int   x=%d y=%d\n", ge->ix3, ge->iy3);
			break;
		case GE_CURVE:
			if(ISDBG(TOINT))
				fprintf(stderr," %c float ", ge->type);

			for(i=0; i<3; i++) {
				if(ISDBG(TOINT))
					fprintf(stderr,"(%g, %g) ", ge->fxn[i], ge->fyn[i]);
				x[i] = iround(ge->fxn[i]);
				y[i] = iround(ge->fyn[i]);
			}

			if(ISDBG(TOINT))
				fprintf(stderr,"\n   int   ");

			for(i=0; i<3; i++) {
				ge->ixn[i] = x[i];
				ge->iyn[i] = y[i];
				if(ISDBG(TOINT))
					fprintf(stderr,"(%d, %d) ", ge->ixn[i], ge->iyn[i]);
			}
			ge->flags &= ~GEF_FLOAT; /* for fixcvdir */
			fixcvdir(ge, ge->dir);

			if(ISDBG(TOINT)) {
				fprintf(stderr,"\n   fixed ");
				for(i=0; i<3; i++)
					fprintf(stderr,"(%d, %d) ", ge->ixn[i], ge->iyn[i]);
				fprintf(stderr,"\n");
			}

			break;
		}
		ge->flags &= ~GEF_FLOAT;
	}
	g->flags &= ~GF_FLOAT;
}


/* check whether we can fix up the curve to change its size by (dx,dy) */
/* 0 means NO, 1 means YES */

/* for float: if scaling would be under 10% */

int
fcheckcv(
	GENTRY * ge,
	double dx,
	double dy
)
{
	if( !(ge->flags & GEF_FLOAT) ) {
		fprintf(stderr, "**! fcheckcv(0x%x) on int entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	if (ge->type != GE_CURVE)
		return 0;

	if( fabs(ge->fx3 - ge->prev->fx3) < fabs(dx) * 10 )
		return 0;

	if( fabs(ge->fy3 - ge->prev->fy3) < fabs(dy) * 10 )
		return 0;

	return 1;
}

/* for int: if won't create new zigzags at the ends */

int
icheckcv(
	GENTRY * ge,
	int dx,
	int dy
)
{
	int             xdep, ydep;

	if(ge->flags & GEF_FLOAT) {
		fprintf(stderr, "**! icheckcv(0x%x) on floating entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	if (ge->type != GE_CURVE)
		return 0;

	xdep = ge->ix3 - ge->prev->ix3;
	ydep = ge->iy3 - ge->prev->iy3;

	if (ge->type == GE_CURVE
	    && (xdep * (xdep + dx)) > 0
	    && (ydep * (ydep + dy)) > 0) {
		return 1;
	} else
		return 0;
}

/* float connect the ends of open contours */

void
fclosepaths(
	   GLYPH * g
)
{
	GENTRY         *ge, *fge, *xge, *nge;
	int             i;

	assertisfloat(g, "fclosepaths float\n");

	for (xge = g->entries; xge != 0; xge = xge->next) {
		if( xge->type != GE_PATH )
			continue;

		ge = xge->prev;
		if(ge == 0 || ge->type != GE_LINE && ge->type!= GE_CURVE) {
			fprintf(stderr, "**! Glyph %s got empty path\n",
				g->name);
			exit(1);
		}

		fge = ge->frwd;
		if (fge->prev == 0 || fge->prev->type != GE_MOVE) {
			fprintf(stderr, "**! Glyph %s got strange beginning of path\n",
				g->name);
			exit(1);
		}
		fge = fge->prev;
		if (fge->fx3 != ge->fx3 || fge->fy3 != ge->fy3) {
			/* we have to fix this open path */

			WARNING_4 fprintf(stderr, "Glyph %s got path open by dx=%g dy=%g\n",
			g->name, fge->fx3 - ge->fx3, fge->fy3 - ge->fy3);


			/* add a new line */
			nge = newgentry(GEF_FLOAT);
			(*nge) = (*ge);
			nge->fx3 = fge->fx3;
			nge->fy3 = fge->fy3;
			nge->type = GE_LINE;

			addgeafter(ge, nge);

			if (fabs(ge->fx3 - fge->fx3) <= 2 && fabs(ge->fy3 - fge->fy3) <= 2) {
				/*
				 * small change, try to get rid of the new entry
				 */

				double df[2];

				for(i=0; i<2; i++) {
					df[i] = ge->fpoints[i][2] - fge->fpoints[i][2];
					df[i] = fclosegap(nge, nge, i, df[i], NULL);
				}

				if(df[0] == 0. && df[1] == 0.) {
					/* closed gap successfully, remove the added entry */
					freethisge(nge);
				}
			}
		}
	}
}

void
smoothjoints(
	     GLYPH * g
)
{
	GENTRY         *ge, *ne;
	int             dx1, dy1, dx2, dy2, k;
	int             dir;

	return; /* this stuff seems to create problems */

	assertisint(g, "smoothjoints int");

	if (g->entries == 0)	/* nothing to do */
		return;

	for (ge = g->entries->next; ge != 0; ge = ge->next) {
		ne = ge->frwd;

		/*
		 * although there should be no one-line path * and any path
		 * must end with CLOSEPATH, * nobody can say for sure
		 */

		if (ge == ne || ne == 0)
			continue;

		/* now handle various joints */

		if (ge->type == GE_LINE && ne->type == GE_LINE) {
			dx1 = ge->ix3 - ge->prev->ix3;
			dy1 = ge->iy3 - ge->prev->iy3;
			dx2 = ne->ix3 - ge->ix3;
			dy2 = ne->iy3 - ge->iy3;

			/* check whether they have the same direction */
			/* and the same slope */
			/* then we can join them into one line */

			if (dx1 * dx2 >= 0 && dy1 * dy2 >= 0 && dx1 * dy2 == dy1 * dx2) {
				/* extend the previous line */
				ge->ix3 = ne->ix3;
				ge->iy3 = ne->iy3;

				/* and get rid of the next line */
				freethisge(ne);
			}
		} else if (ge->type == GE_LINE && ne->type == GE_CURVE) {
			fixcvends(ne);

			dx1 = ge->ix3 - ge->prev->ix3;
			dy1 = ge->iy3 - ge->prev->iy3;
			dx2 = ne->ix1 - ge->ix3;
			dy2 = ne->iy1 - ge->iy3;

			/* if the line is nearly horizontal and we can fix it */
			if (dx1 != 0 && 5 * abs(dy1) / abs(dx1) == 0
			    && icheckcv(ne, 0, -dy1)
			    && abs(dy1) <= 4) {
				dir = igetcvdir(ne);
				ge->iy3 -= dy1;
				ne->iy1 -= dy1;
				fixcvdir(ne, dir);
				if (ge->next != ne)
					ne->prev->iy3 -= dy1;
				dy1 = 0;
			} else if (dy1 != 0 && 5 * abs(dx1) / abs(dy1) == 0
				   && icheckcv(ne, -dx1, 0)
				   && abs(dx1) <= 4) {
				/* the same but vertical */
				dir = igetcvdir(ne);
				ge->ix3 -= dx1;
				ne->ix1 -= dx1;
				fixcvdir(ne, dir);
				if (ge->next != ne)
					ne->prev->ix3 -= dx1;
				dx1 = 0;
			}
			/*
			 * if line is horizontal and curve begins nearly
			 * horizontally
			 */
			if (dy1 == 0 && dx2 != 0 && 5 * abs(dy2) / abs(dx2) == 0) {
				dir = igetcvdir(ne);
				ne->iy1 -= dy2;
				fixcvdir(ne, dir);
				dy2 = 0;
			} else if (dx1 == 0 && dy2 != 0 && 5 * abs(dx2) / abs(dy2) == 0) {
				/* the same but vertical */
				dir = igetcvdir(ne);
				ne->ix1 -= dx2;
				fixcvdir(ne, dir);
				dx2 = 0;
			}
		} else if (ge->type == GE_CURVE && ne->type == GE_LINE) {
			fixcvends(ge);

			dx1 = ge->ix3 - ge->ix2;
			dy1 = ge->iy3 - ge->iy2;
			dx2 = ne->ix3 - ge->ix3;
			dy2 = ne->iy3 - ge->iy3;

			/* if the line is nearly horizontal and we can fix it */
			if (dx2 != 0 && 5 * abs(dy2) / abs(dx2) == 0
			    && icheckcv(ge, 0, dy2)
			    && abs(dy2) <= 4) {
				dir = igetcvdir(ge);
				ge->iy3 += dy2;
				ge->iy2 += dy2;
				fixcvdir(ge, dir);
				if (ge->next != ne)
					ne->prev->iy3 += dy2;
				dy2 = 0;
			} else if (dy2 != 0 && 5 * abs(dx2) / abs(dy2) == 0
				   && icheckcv(ge, dx2, 0)
				   && abs(dx2) <= 4) {
				/* the same but vertical */
				dir = igetcvdir(ge);
				ge->ix3 += dx2;
				ge->ix2 += dx2;
				fixcvdir(ge, dir);
				if (ge->next != ne)
					ne->prev->ix3 += dx2;
				dx2 = 0;
			}
			/*
			 * if line is horizontal and curve ends nearly
			 * horizontally
			 */
			if (dy2 == 0 && dx1 != 0 && 5 * abs(dy1) / abs(dx1) == 0) {
				dir = igetcvdir(ge);
				ge->iy2 += dy1;
				fixcvdir(ge, dir);
				dy1 = 0;
			} else if (dx2 == 0 && dy1 != 0 && 5 * abs(dx1) / abs(dy1) == 0) {
				/* the same but vertical */
				dir = igetcvdir(ge);
				ge->ix2 += dx1;
				fixcvdir(ge, dir);
				dx1 = 0;
			}
		} else if (ge->type == GE_CURVE && ne->type == GE_CURVE) {
			fixcvends(ge);
			fixcvends(ne);

			dx1 = ge->ix3 - ge->ix2;
			dy1 = ge->iy3 - ge->iy2;
			dx2 = ne->ix1 - ge->ix3;
			dy2 = ne->iy1 - ge->iy3;

			/*
			 * check if we have a rather smooth joint at extremal
			 * point
			 */
			/* left or right extremal point */
			if (abs(dx1) <= 4 && abs(dx2) <= 4
			    && dy1 != 0 && 5 * abs(dx1) / abs(dy1) == 0
			    && dy2 != 0 && 5 * abs(dx2) / abs(dy2) == 0
			    && (ge->iy3 < ge->prev->iy3 && ne->iy3 < ge->iy3
				|| ge->iy3 > ge->prev->iy3 && ne->iy3 > ge->iy3)
			  && (ge->ix3 - ge->prev->ix3) * (ne->ix3 - ge->ix3) < 0
				) {
				dir = igetcvdir(ge);
				ge->ix2 += dx1;
				dx1 = 0;
				fixcvdir(ge, dir);
				dir = igetcvdir(ne);
				ne->ix1 -= dx2;
				dx2 = 0;
				fixcvdir(ne, dir);
			}
			/* top or down extremal point */
			else if (abs(dy1) <= 4 && abs(dy2) <= 4
				 && dx1 != 0 && 5 * abs(dy1) / abs(dx1) == 0
				 && dx2 != 0 && 5 * abs(dy2) / abs(dx2) == 0
				 && (ge->ix3 < ge->prev->ix3 && ne->ix3 < ge->ix3
				|| ge->ix3 > ge->prev->ix3 && ne->ix3 > ge->ix3)
				 && (ge->iy3 - ge->prev->iy3) * (ne->iy3 - ge->iy3) < 0
				) {
				dir = igetcvdir(ge);
				ge->iy2 += dy1;
				dy1 = 0;
				fixcvdir(ge, dir);
				dir = igetcvdir(ne);
				ne->iy1 -= dy2;
				dy2 = 0;
				fixcvdir(ne, dir);
			}
			/* or may be we just have a smooth junction */
			else if (dx1 * dx2 >= 0 && dy1 * dy2 >= 0
				 && 10 * abs(k = abs(dx1 * dy2) - abs(dy1 * dx2)) < (abs(dx1 * dy2) + abs(dy1 * dx2))) {
				int             tries[6][4];
				int             results[6];
				int             i, b;

				/* build array of changes we are going to try */
				/* uninitalized entries are 0 */
				if (k > 0) {
					static int      t1[6][4] = {
						{0, 0, 0, 0},
						{-1, 0, 1, 0},
						{-1, 0, 0, 1},
						{0, -1, 1, 0},
						{0, -1, 0, 1},
					{-1, -1, 1, 1}};
					memcpy(tries, t1, sizeof tries);
				} else {
					static int      t1[6][4] = {
						{0, 0, 0, 0},
						{1, 0, -1, 0},
						{1, 0, 0, -1},
						{0, 1, -1, 0},
						{0, 1, 0, -1},
					{1, 1, -1, -1}};
					memcpy(tries, t1, sizeof tries);
				}

				/* now try the changes */
				results[0] = abs(k);
				for (i = 1; i < 6; i++) {
					results[i] = abs((abs(dx1) + tries[i][0]) * (abs(dy2) + tries[i][1]) -
							 (abs(dy1) + tries[i][2]) * (abs(dx2) + tries[i][3]));
				}

				/* and find the best try */
				k = abs(k);
				b = 0;
				for (i = 1; i < 6; i++)
					if (results[i] < k) {
						k = results[i];
						b = i;
					}
				/* and finally apply it */
				if (dx1 < 0)
					tries[b][0] = -tries[b][0];
				if (dy2 < 0)
					tries[b][1] = -tries[b][1];
				if (dy1 < 0)
					tries[b][2] = -tries[b][2];
				if (dx2 < 0)
					tries[b][3] = -tries[b][3];

				dir = igetcvdir(ge);
				ge->ix2 -= tries[b][0];
				ge->iy2 -= tries[b][2];
				fixcvdir(ge, dir);
				dir = igetcvdir(ne);
				ne->ix1 += tries[b][3];
				ne->iy1 += tries[b][1];
				fixcvdir(ne, dir);
			}
		}
	}
}

/* debugging: print out stems of a glyph */
static void
debugstems(
	   char *name,
	   STEM * hstems,
	   int nhs,
	   STEM * vstems,
	   int nvs
)
{
	int             i;

	fprintf(pfa_file, "%% %s\n", name);
	fprintf(pfa_file, "%% %d horizontal stems:\n", nhs);
	for (i = 0; i < nhs; i++)
		fprintf(pfa_file, "%% %3d    %d (%d...%d) %c %c%c%c%c\n", i, hstems[i].value,
			hstems[i].from, hstems[i].to,
			((hstems[i].flags & ST_UP) ? 'U' : 'D'),
			((hstems[i].flags & ST_END) ? 'E' : '-'),
			((hstems[i].flags & ST_FLAT) ? 'F' : '-'),
			((hstems[i].flags & ST_ZONE) ? 'Z' : ' '),
			((hstems[i].flags & ST_TOPZONE) ? 'T' : ' '));
	fprintf(pfa_file, "%% %d vertical stems:\n", nvs);
	for (i = 0; i < nvs; i++)
		fprintf(pfa_file, "%% %3d    %d (%d...%d) %c %c%c\n", i, vstems[i].value,
			vstems[i].from, vstems[i].to,
			((vstems[i].flags & ST_UP) ? 'U' : 'D'),
			((vstems[i].flags & ST_END) ? 'E' : '-'),
			((vstems[i].flags & ST_FLAT) ? 'F' : '-'));
}

/* add pseudo-stems for the limits of the Blue zones to the stem array */
static int
addbluestems(
	STEM *s,
	int n
)
{
	int i;

	for(i=0; i<nblues && i<2; i+=2) { /* baseline */
		s[n].value=bluevalues[i];
		s[n].flags=ST_UP|ST_ZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i;
		n++;
		s[n].value=bluevalues[i+1];
		s[n].flags=ST_ZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i+1;
		n++;
	}
	for(i=2; i<nblues; i+=2) { /* top zones */
		s[n].value=bluevalues[i];
		s[n].flags=ST_UP|ST_ZONE|ST_TOPZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i;
		n++;
		s[n].value=bluevalues[i+1];
		s[n].flags=ST_ZONE|ST_TOPZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i+1;
		n++;
	}
	for(i=0; i<notherb; i+=2) { /* bottom zones */
		s[n].value=otherblues[i];
		s[n].flags=ST_UP|ST_ZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i+nblues;
		n++;
		s[n].value=otherblues[i+1];
		s[n].flags=ST_ZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i+1+nblues;
		n++;
	}
	return n;
}

/* sort stems in array */
static void
sortstems(
	  STEM * s,
	  int n
)
{
	int             i, j;
	STEM            x;


	/* a simple sorting */
	/* hm, the ordering criteria are not quite simple :-) 
	 * if the values are tied
	 * ST_UP always goes under not ST_UP
	 * ST_ZONE goes on the most outer side
	 * ST_END goes towards inner side after ST_ZONE
	 * ST_FLAT goes on the inner side
	 */

	for (i = 0; i < n; i++)
		for (j = i + 1; j < n; j++) {
			if(s[i].value < s[j].value)
				continue;
			if(s[i].value == s[j].value) {
				if( (s[i].flags & ST_UP) < (s[j].flags & ST_UP) )
					continue;
				if( (s[i].flags & ST_UP) == (s[j].flags & ST_UP) ) {
					if( s[i].flags & ST_UP ) {
						if(
						(s[i].flags & (ST_ZONE|ST_FLAT|ST_END) ^ ST_FLAT)
							>
						(s[j].flags & (ST_ZONE|ST_FLAT|ST_END) ^ ST_FLAT)
						)
							continue;
					} else {
						if(
						(s[i].flags & (ST_ZONE|ST_FLAT|ST_END) ^ ST_FLAT)
							<
						(s[j].flags & (ST_ZONE|ST_FLAT|ST_END) ^ ST_FLAT)
						)
							continue;
					}
				}
			}
			x = s[j];
			s[j] = s[i];
			s[i] = x;
		}
}

/* check whether two stem borders overlap */

static int
stemoverlap(
	    STEM * s1,
	    STEM * s2
)
{
	int             result;

	if (s1->from <= s2->from && s1->to >= s2->from
	    || s2->from <= s1->from && s2->to >= s1->from)
		result = 1;
	else
		result = 0;

	if (ISDBG(STEMOVERLAP))
		fprintf(pfa_file, "%% overlap %d(%d..%d)x%d(%d..%d)=%d\n",
			s1->value, s1->from, s1->to, s2->value, s2->from, s2->to, result);
	return result;
}

/* 
 * check if the stem [border] is in an appropriate blue zone
 * (currently not used)
 */

static int
steminblue(
	STEM *s
)
{
	int i, val;

	val=s->value;
	if(s->flags & ST_UP) {
		/* painted size up, look at lower zones */
		if(nblues>=2 && val>=bluevalues[0] && val<=bluevalues[1] )
			return 1;
		for(i=0; i<notherb; i++) {
			if( val>=otherblues[i] && val<=otherblues[i+1] )
				return 1;
		}
	} else {
		/* painted side down, look at upper zones */
		for(i=2; i<nblues; i++) {
			if( val>=bluevalues[i] && val<=bluevalues[i+1] )
				return 1;
		}
	}

	return 0;
}

/* mark the outermost stem [borders] in the blue zones */

static void
markbluestems(
	STEM *s,
	int nold
)
{
	int i, j, a, b, c;
	/*
	 * traverse the list of Blue Values, mark the lowest upper
	 * stem in each bottom zone and the topmost lower stem in
	 * each top zone with ST_BLUE
	 */

	/* top zones */
	for(i=2; i<nblues; i+=2) {
		a=bluevalues[i]; b=bluevalues[i+1];
		if(ISDBG(BLUESTEMS))
			fprintf(pfa_file, "%% looking at blue zone %d...%d\n", a, b);
		for(j=nold-1; j>=0; j--) {
			if( s[j].flags & (ST_ZONE|ST_UP|ST_END) )
				continue;
			c=s[j].value;
			if(c<a) /* too low */
				break;
			if(c<=b) { /* found the topmost stem border */
				/* mark all the stems with the same value */
				if(ISDBG(BLUESTEMS))
					fprintf(pfa_file, "%% found D BLUE at %d\n", s[j].value);
				/* include ST_END values */
				while( s[j+1].value==c && (s[j+1].flags & ST_ZONE)==0 )
					j++;
				s[j].flags |= ST_BLUE;
				for(j--; j>=0 && s[j].value==c 
						&& (s[j].flags & (ST_UP|ST_ZONE))==0 ; j--)
					s[j].flags |= ST_BLUE;
				break;
			}
		}
	}
	/* baseline */
	if(nblues>=2) {
		a=bluevalues[0]; b=bluevalues[1];
		for(j=0; j<nold; j++) {
			if( (s[j].flags & (ST_ZONE|ST_UP|ST_END))!=ST_UP )
				continue;
			c=s[j].value;
			if(c>b) /* too high */
				break;
			if(c>=a) { /* found the lowest stem border */
				/* mark all the stems with the same value */
				if(ISDBG(BLUESTEMS))
					fprintf(pfa_file, "%% found U BLUE at %d\n", s[j].value);
				/* include ST_END values */
				while( s[j-1].value==c && (s[j-1].flags & ST_ZONE)==0 )
					j--;
				s[j].flags |= ST_BLUE;
				for(j++; j<nold && s[j].value==c
						&& (s[j].flags & (ST_UP|ST_ZONE))==ST_UP ; j++)
					s[j].flags |= ST_BLUE;
				break;
			}
		}
	}
	/* bottom zones: the logic is the same as for baseline */
	for(i=0; i<notherb; i+=2) {
		a=otherblues[i]; b=otherblues[i+1];
		for(j=0; j<nold; j++) {
			if( (s[j].flags & (ST_UP|ST_ZONE|ST_END))!=ST_UP )
				continue;
			c=s[j].value;
			if(c>b) /* too high */
				break;
			if(c>=a) { /* found the lowest stem border */
				/* mark all the stems with the same value */
				if(ISDBG(BLUESTEMS))
					fprintf(pfa_file, "%% found U BLUE at %d\n", s[j].value);
				/* include ST_END values */
				while( s[j-1].value==c && (s[j-1].flags & ST_ZONE)==0 )
					j--;
				s[j].flags |= ST_BLUE;
				for(j++; j<nold && s[j].value==c
						&& (s[j].flags & (ST_UP|ST_ZONE))==ST_UP ; j++)
					s[j].flags |= ST_BLUE;
				break;
			}
		}
	}
}

/* Eliminate invalid stems, join equivalent lines and remove nested stems
 * to build the main (non-substituted) set of stems.
 * XXX add consideration of the italic angle
 */
static int
joinmainstems(
	  STEM * s,
	  int nold,
	  int useblues /* do we use the blue values ? */
)
{
#define MAX_STACK	1000
	STEM            stack[MAX_STACK];
	int             nstack = 0;
	int             sbottom = 0;
	int             nnew;
	int             i, j, k;
	int             a, b, c, w1, w2, w3;
	int             fw, fd;
	/*
	 * priority of the last found stem: 
	 * 0 - nothing found yet 
	 * 1 - has ST_END in it (one or more) 
	 * 2 - has no ST_END and no ST_FLAT, can override only one stem 
	 *     with priority 1 
	 * 3 - has no ST_END and at least one ST_FLAT, can override one 
	 *     stem with priority 2 or any number of stems with priority 1
	 * 4 (handled separately) - has ST_BLUE, can override anything
	 */
	int             readystem = 0;
	int             pri;
	int             nlps = 0;	/* number of non-committed
					 * lowest-priority stems */


	for (i = 0, nnew = 0; i < nold; i++) {
		if (s[i].flags & (ST_UP|ST_ZONE)) {
			if(s[i].flags & ST_BLUE) {
				/* we just HAVE to use this value */
				if (readystem)
					nnew += 2;
				readystem=0;

				/* remember the list of Blue zone stems with the same value */
				for(a=i, i++; i<nold && s[a].value==s[i].value
					&& (s[i].flags & ST_BLUE); i++)
					{}
				b=i; /* our range is a <= i < b */
				c= -1; /* index of our best guess up to now */
				pri=0;
				/* try to find a match, don't cross blue zones */
				for(; i<nold && (s[i].flags & ST_BLUE)==0; i++) {
					if(s[i].flags & ST_UP) {
						if(s[i].flags & ST_TOPZONE)
							break;
						else
							continue;
					}
					for(j=a; j<b; j++) {
						if(!stemoverlap(&s[j], &s[i]) )
							continue;
						/* consider priorities */
						if( ( (s[j].flags|s[i].flags) & (ST_FLAT|ST_END) )==ST_FLAT ) {
							c=i;
							goto bluematch;
						}
						if( ((s[j].flags|s[i].flags) & ST_END)==0 )  {
							if(pri < 2) {
								c=i; pri=2;
							}
						} else {
							if(pri == 0) {
								c=i; pri=1;
							}
						}
					}
				}
			bluematch:
				/* clean up the stack */
				nstack=sbottom=0;
				readystem=0;
				/* add this stem */
				s[nnew++]=s[a];
				if(c<0) { /* make one-dot-wide stem */
					if(nnew>=b) { /* have no free space */
						for(j=nold; j>=b; j--) /* make free space */
							s[j]=s[j-1];
						b++;
						nold++;
					}
					s[nnew]=s[a];
					s[nnew].flags &= ~(ST_UP|ST_BLUE);
					nnew++;
					i=b-1;
				} else {
					s[nnew++]=s[c];
					i=c; /* skip up to this point */
				}
				if (ISDBG(MAINSTEMS))
					fprintf(pfa_file, "%% +stem %d...%d U BLUE\n",
						s[nnew-2].value, s[nnew-1].value);
			} else {
				if (nstack >= MAX_STACK) {
					WARNING_1 fprintf(stderr, "Warning: **** converter's stem stack overflow ****\n");
					nstack = 0;
				}
				stack[nstack++] = s[i];
			}
		} else if(s[i].flags & ST_BLUE) {
			/* again, we just HAVE to use this value */
			if (readystem)
				nnew += 2;
			readystem=0;

			/* remember the list of Blue zone stems with the same value */
			for(a=i, i++; i<nold && s[a].value==s[i].value
				&& (s[i].flags & ST_BLUE); i++)
				{}
			b=i; /* our range is a <= i < b */
			c= -1; /* index of our best guess up to now */
			pri=0;
			/* try to find a match */
			for (i = nstack - 1; i >= 0; i--) {
				if( (stack[i].flags & ST_UP)==0 ) {
					if( (stack[i].flags & (ST_ZONE|ST_TOPZONE))==ST_ZONE )
						break;
					else
						continue;
				}
				for(j=a; j<b; j++) {
					if(!stemoverlap(&s[j], &stack[i]) )
						continue;
					/* consider priorities */
					if( ( (s[j].flags|stack[i].flags) & (ST_FLAT|ST_END) )==ST_FLAT ) {
						c=i;
						goto bluedownmatch;
					}
					if( ((s[j].flags|stack[i].flags) & ST_END)==0 )  {
						if(pri < 2) {
							c=i; pri=2;
						}
					} else {
						if(pri == 0) {
							c=i; pri=1;
						}
					}
				}
			}
		bluedownmatch:
			/* if found no match make a one-dot-wide stem */
			if(c<0) {
				c=0;
				stack[0]=s[b-1];
				stack[0].flags |= ST_UP;
				stack[0].flags &= ~ST_BLUE;
			}
			/* remove all the stems conflicting with this one */
			readystem=0;
			for(j=nnew-2; j>=0; j-=2) {
				if (ISDBG(MAINSTEMS))
					fprintf(pfa_file, "%% ?stem %d...%d -- %d\n",
						s[j].value, s[j+1].value, stack[c].value);
				if(s[j+1].value < stack[c].value) /* no conflict */
					break;
				if(s[j].flags & ST_BLUE) {
					/* oops, we don't want to spoil other blue zones */
					stack[c].value=s[j+1].value+1;
					break;
				}
				if( (s[j].flags|s[j+1].flags) & ST_END ) {
					if (ISDBG(MAINSTEMS))
						fprintf(pfa_file, "%% -stem %d...%d p=1\n",
							s[j].value, s[j+1].value);
					continue; /* pri==1, silently discard it */
				}
				/* we want to discard no nore than 2 stems of pri>=2 */
				if( ++readystem > 2 ) {
					/* change our stem to not conflict */
					stack[c].value=s[j+1].value+1;
					break;
				} else {
					if (ISDBG(MAINSTEMS))
						fprintf(pfa_file, "%% -stem %d...%d p>=2\n",
							s[j].value, s[j+1].value);
					continue;
				}
			}
			nnew=j+2;
			/* add this stem */
			if(nnew>=b-1) { /* have no free space */
				for(j=nold; j>=b-1; j--) /* make free space */
					s[j]=s[j-1];
				b++;
				nold++;
			}
			s[nnew++]=stack[c];
			s[nnew++]=s[b-1];
			/* clean up the stack */
			nstack=sbottom=0;
			readystem=0;
			/* set the next position to search */
			i=b-1;
			if (ISDBG(MAINSTEMS))
				fprintf(pfa_file, "%% +stem %d...%d D BLUE\n",
					s[nnew-2].value, s[nnew-1].value);
		} else if (nstack > 0) {

			/*
			 * check whether our stem overlaps with anything in
			 * stack
			 */
			for (j = nstack - 1; j >= sbottom; j--) {
				if (s[i].value <= stack[j].value)
					break;
				if (stack[j].flags & ST_ZONE)
					continue;

				if ((s[i].flags & ST_END)
				    || (stack[j].flags & ST_END))
					pri = 1;
				else if ((s[i].flags & ST_FLAT)
					 || (stack[j].flags & ST_FLAT))
					pri = 3;
				else
					pri = 2;

				if (pri < readystem && s[nnew + 1].value >= stack[j].value
				    || !stemoverlap(&stack[j], &s[i]))
					continue;

				if (readystem > 1 && s[nnew + 1].value < stack[j].value) {
					nnew += 2;
					readystem = 0;
					nlps = 0;
				}
				/*
				 * width of the previous stem (if it's
				 * present)
				 */
				w1 = s[nnew + 1].value - s[nnew].value;

				/* width of this stem */
				w2 = s[i].value - stack[j].value;

				if (readystem == 0) {
					/* nothing yet, just add a new stem */
					s[nnew] = stack[j];
					s[nnew + 1] = s[i];
					readystem = pri;
					if (pri == 1)
						nlps = 1;
					else if (pri == 2)
						sbottom = j;
					else {
						sbottom = j + 1;
						while (sbottom < nstack
						       && stack[sbottom].value <= stack[j].value)
							sbottom++;
					}
					if (ISDBG(MAINSTEMS))
						fprintf(pfa_file, "%% +stem %d...%d p=%d n=%d\n",
							stack[j].value, s[i].value, pri, nlps);
				} else if (pri == 1) {
					if (stack[j].value > s[nnew + 1].value) {
						/*
						 * doesn't overlap with the
						 * previous one
						 */
						nnew += 2;
						nlps++;
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% +stem %d...%d p=%d n=%d\n",
								stack[j].value, s[i].value, pri, nlps);
					} else if (w2 < w1) {
						/* is narrower */
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% /stem %d...%d p=%d n=%d %d->%d\n",
								stack[j].value, s[i].value, pri, nlps, w1, w2);
					}
				} else if (pri == 2) {
					if (readystem == 2) {
						/* choose the narrower stem */
						if (w1 > w2) {
							s[nnew] = stack[j];
							s[nnew + 1] = s[i];
							sbottom = j;
							if (ISDBG(MAINSTEMS))
								fprintf(pfa_file, "%% /stem %d...%d p=%d n=%d\n",
									stack[j].value, s[i].value, pri, nlps);
						}
						/* else readystem==1 */
					} else if (stack[j].value > s[nnew + 1].value) {
						/*
						 * value doesn't overlap with
						 * the previous one
						 */
						nnew += 2;
						nlps = 0;
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						sbottom = j;
						readystem = pri;
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% +stem %d...%d p=%d n=%d\n",
								stack[j].value, s[i].value, pri, nlps);
					} else if (nlps == 1
						   || stack[j].value > s[nnew - 1].value) {
						/*
						 * we can replace the top
						 * stem
						 */
						nlps = 0;
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						readystem = pri;
						sbottom = j;
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% /stem %d...%d p=%d n=%d\n",
								stack[j].value, s[i].value, pri, nlps);
					}
				} else if (readystem == 3) {	/* that means also
								 * pri==3 */
					/* choose the narrower stem */
					if (w1 > w2) {
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						sbottom = j + 1;
						while (sbottom < nstack
						       && stack[sbottom].value <= stack[j].value)
							sbottom++;
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% /stem %d...%d p=%d n=%d\n",
								stack[j].value, s[i].value, pri, nlps);
					}
				} else if (pri == 3) {
					/*
					 * we can replace as many stems as
					 * neccessary
					 */
					nnew += 2;
					while (nnew > 0 && s[nnew - 1].value >= stack[j].value) {
						nnew -= 2;
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% -stem %d..%d\n",
								s[nnew].value, s[nnew + 1].value);
					}
					nlps = 0;
					s[nnew] = stack[j];
					s[nnew + 1] = s[i];
					readystem = pri;
					sbottom = j + 1;
					while (sbottom < nstack
					       && stack[sbottom].value <= stack[j].value)
						sbottom++;
					if (ISDBG(MAINSTEMS))
						fprintf(pfa_file, "%% +stem %d...%d p=%d n=%d\n",
							stack[j].value, s[i].value, pri, nlps);
				}
			}
		}
	}
	if (readystem)
		nnew += 2;

	/* change the 1-pixel-wide stems to 20-pixel-wide stems if possible 
	 * the constant 20 is recommended in the Type1 manual 
	 */
	if(useblues) {
		for(i=0; i<nnew; i+=2) {
			if(s[i].value != s[i+1].value)
				continue;
			if( ((s[i].flags ^ s[i+1].flags) & ST_BLUE)==0 )
				continue;
			if( s[i].flags & ST_BLUE ) {
				if(nnew>i+2 && s[i+2].value<s[i].value+22)
					s[i+1].value=s[i+2].value-2; /* compensate for fuzziness */
				else
					s[i+1].value+=20;
			} else {
				if(i>0 && s[i-1].value>s[i].value-22)
					s[i].value=s[i-1].value+2; /* compensate for fuzziness */
				else
					s[i].value-=20;
			}
		}
	}
	/* make sure that no stem it stretched between
	 * a top zone and a bottom zone
	 */
	if(useblues) {
		for(i=0; i<nnew; i+=2) {
			a=10000; /* lowest border of top zone crosing the stem */
			b= -10000; /* highest border of bottom zone crossing the stem */

			for(j=2; j<nblues; j++) {
				c=bluevalues[j];
				if( c>=s[i].value && c<=s[i+1].value && c<a )
					a=c;
			}
			if(nblues>=2) {
				c=bluevalues[1];
				if( c>=s[i].value && c<=s[i+1].value && c>b )
					b=c;
			}
			for(j=1; j<notherb; j++) {
				c=otherblues[j];
				if( c>=s[i].value && c<=s[i+1].value && c>b )
					b=c;
			}
			if( a!=10000 && b!= -10000 ) { /* it is stretched */
				/* split the stem into 2 ghost stems */
				for(j=nnew+1; j>i+1; j--) /* make free space */
					s[j]=s[j-2];
				nnew+=2;

				if(s[i].value+22 >= a)
					s[i+1].value=a-2; /* leave space for fuzziness */
				else
					s[i+1].value=s[i].value+20;

				if(s[i+3].value-22 <= b)
					s[i+2].value=b+2; /* leave space for fuzziness */
				else
					s[i+2].value=s[i+3].value-20;

				i+=2;
			}
		}
	}
	/* look for triple stems */
	for (i = 0; i < nnew; i += 2) {
		if (nnew - i >= 6) {
			a = s[i].value + s[i + 1].value;
			b = s[i + 2].value + s[i + 3].value;
			c = s[i + 4].value + s[i + 5].value;

			w1 = s[i + 1].value - s[i].value;
			w2 = s[i + 3].value - s[i + 2].value;
			w3 = s[i + 5].value - s[i + 4].value;

			fw = w3 - w1;	/* fuzz in width */
			fd = ((c - b) - (b - a));	/* fuzz in distance
							 * (doubled) */

			/* we are able to handle some fuzz */
			/*
			 * it doesn't hurt if the declared stem is a bit
			 * narrower than actual unless it's an edge in
			 * a blue zone
			 */
			if (abs(abs(fd) - abs(fw)) * 5 < w2
			    && abs(fw) * 20 < (w1 + w3)) {	/* width dirrerence <10% */

				if(useblues) { /* check that we don't disturb any blue stems */
					j=c; k=a;
					if (fw > 0) {
						if (fd > 0) {
							if( s[i+5].flags & ST_BLUE )
								continue;
							j -= fw;
						} else {
							if( s[i+4].flags & ST_BLUE )
								continue;
							j += fw;
						}
					} else if(fw < 0) {
						if (fd > 0) {
							if( s[i+1].flags & ST_BLUE )
								continue;
							k -= fw;
						} else {
							if( s[i].flags & ST_BLUE )
								continue;
							k += fw;
						}
					}
					pri = ((j - b) - (b - k));

					if (pri > 0) {
						if( s[i+2].flags & ST_BLUE )
							continue;
					} else if(pri < 0) {
						if( s[i+3].flags & ST_BLUE )
							continue;
					}
				}

				/*
				 * first fix up the width of 1st and 3rd
				 * stems
				 */
				if (fw > 0) {
					if (fd > 0) {
						s[i + 5].value -= fw;
						c -= fw;
					} else {
						s[i + 4].value += fw;
						c += fw;
					}
				} else {
					if (fd > 0) {
						s[i + 1].value -= fw;
						a -= fw;
					} else {
						s[i].value += fw;
						a += fw;
					}
				}
				fd = ((c - b) - (b - a));

				if (fd > 0) {
					s[i + 2].value += abs(fd) / 2;
				} else {
					s[i + 3].value -= abs(fd) / 2;
				}

				s[i].flags |= ST_3;
				i += 4;
			}
		}
	}

	return (nnew & ~1);	/* number of lines must be always even */
}

/*
 * these macros and function allow to set the base stem,
 * check that it's not empty and subtract another stem
 * from the base stem (possibly dividing it into multiple parts)
 */

/* pairs for pieces of the base stem */
static short xbstem[MAX_STEMS*2]; 
/* index of the last point */
static int xblast= -1; 

#define setbasestem(from, to) \
	(xbstem[0]=from, xbstem[1]=to, xblast=1)
#define isbaseempty()	(xblast<=0)

/* returns 1 if was overlapping, 0 otherwise */
static int
subfrombase(
	int from,
	int to
) 
{
	int a, b;
	int i, j;

	if(isbaseempty())
		return 0;

	/* handle the simple case simply */
	if(from > xbstem[xblast] || to < xbstem[0])
		return 0;

	/* the binary search may be more efficient */
	/* but for now the linear search is OK */
	for(b=1; from > xbstem[b]; b+=2) {} /* result: from <= xbstem[b] */
	for(a=xblast-1; to < xbstem[a]; a-=2) {} /* result: to >= xbstem[a] */

	/* now the interesting examples are:
	 * (it was hard for me to understand, so I looked at the examples)
	 * 1
	 *     a|-----|          |-----|b   |-----|     |-----|
	 *              f|-----|t
	 * 2
	 *     a|-----|b         |-----|    |-----|     |-----|
	 *      f|--|t
	 * 3
	 *     a|-----|b         |-----|    |-----|     |-----|
	 *           f|-----|t
	 * 4
	 *      |-----|b        a|-----|    |-----|     |-----|
	 *          f|------------|t
	 * 5
	 *      |-----|          |-----|b   |-----|    a|-----|
	 *                   f|-----------------------------|t
	 * 6
	 *      |-----|b         |-----|    |-----|    a|-----|
	 *   f|--------------------------------------------------|t
	 * 7
	 *      |-----|b         |-----|   a|-----|     |-----|
	 *          f|--------------------------|t
	 */

	if(a < b-1) /* hits a gap  - example 1 */
		return 0;

	/* now the subtraction itself */

	if(a==b-1 && from > xbstem[a] && to < xbstem[b]) {
		/* overlaps with only one subrange and splits it - example 2 */
		j=xblast; i=(xblast+=2);
		while(j>=b)
			xbstem[i--]=xbstem[j--];
		xbstem[b]=from-1;
		xbstem[b+1]=to+1;
		return 1;
	/* becomes
	 * 2a
	 *     a|b   ||          |-----|    |-----|     |-----|
	 *      f|--|t
	 */
	}

	if(xbstem[b-1] < from) {
		/* cuts the back of this subrange - examples 3, 4, 7 */
		xbstem[b] = from-1;
		b+=2;
	/* becomes
	 * 3a
	 *     a|----|           |-----|b   |-----|     |-----|
	 *           f|-----|t
	 * 4a
	 *      |---|           a|-----|b   |-----|     |-----|
	 *          f|------------|t
	 * 7a
	 *      |---|            |-----|b  a|-----|     |-----|
	 *          f|--------------------------|t
	 */
	}

	if(xbstem[a+1] > to) {
		/* cuts the front of this subrange - examples 4a, 5, 7a */
		xbstem[a] = to+1;
		a-=2;
	/* becomes
	 * 4b
	 *     a|---|              |---|b   |-----|     |-----|
	 *          f|------------|t
	 * 5b
	 *      |-----|          |-----|b  a|-----|          ||
	 *                   f|-----------------------------|t
	 * 7b
	 *      |---|           a|-----|b        ||     |-----|
	 *          f|--------------------------|t
	 */
	}

	if(a < b-1) /* now after modification it hits a gap - examples 3a, 4b */
		return 1; /* because we have removed something */

	/* now remove the subranges completely covered by the new stem */
	/* examples 5b, 6, 7b */
	i=b-1; j=a+2;
	/* positioned as:
	 * 5b                    i                           j
	 *      |-----|          |-----|b  a|-----|          ||
	 *                   f|-----------------------------|t
	 * 6    i                                             xblast  j
	 *      |-----|b         |-----|    |-----|    a|-----|
	 *   f|--------------------------------------------------|t
	 * 7b                    i               j
	 *      |---|           a|-----|b        ||     |-----|
	 *          f|--------------------------|t
	 */
	while(j <= xblast)
		xbstem[i++]=xbstem[j++];
	xblast=i-1;
	return 1;
}

/* for debugging */
static void
printbasestem(void)
{
	int i;

	printf("( ");
	for(i=0; i<xblast; i+=2)
		printf("%d-%d ", xbstem[i], xbstem[i+1]);
	printf(") %d\n", xblast);
}

/*
 * Join the stem borders to build the sets of substituted stems
 * XXX add consideration of the italic angle
 */
static void
joinsubstems(
	  STEM * s,
	  short *pairs,
	  int nold,
	  int useblues /* do we use the blue values ? */
)
{
	int i, j, x;
	static unsigned char mx[MAX_STEMS][MAX_STEMS];

	/* we do the substituted groups of stems first
	 * and it looks like it's going to be REALLY SLOW 
	 * AND PAINFUL but let's bother about it later
	 */

	/* for the substituted stems we don't bother about [hv]stem3 -
	 * anyway the X11R6 rasterizer does not bother about hstem3
	 * at all and is able to handle only one global vstem3
	 * per glyph 
	 */

	/* clean the used part of matrix */
	for(i=0; i<nold; i++)
		for(j=0; j<nold; j++)
			mx[i][j]=0;

	/* build the matrix of stem pairs */
	for(i=0; i<nold; i++) {
		if( s[i].flags & ST_ZONE )
			continue;
		if(s[i].flags & ST_BLUE)
			mx[i][i]=1; /* allow to pair with itself if no better pair */
		if(s[i].flags & ST_UP) { /* the down-stems are already matched */
			setbasestem(s[i].from, s[i].to);
			for(j=i+1; j<nold; j++) {
				if(s[i].value==s[j].value
				|| s[j].flags & ST_ZONE ) {
					continue;
				}
				x=subfrombase(s[j].from, s[j].to);

				if(s[j].flags & ST_UP) /* match only up+down pairs */
					continue;

				mx[i][j]=mx[j][i]=x;

				if(isbaseempty()) /* nothing else to do */
					break;
			}
		}
	}

	if(ISDBG(SUBSTEMS)) {
		fprintf(pfa_file, "%%     ");
		for(j=0; j<nold; j++)
			putc( j%10==0 ? '0'+(j/10)%10 : ' ', pfa_file);
		fprintf(pfa_file, "\n%%     ");
		for(j=0; j<nold; j++)
			putc('0'+j%10, pfa_file);
		putc('\n', pfa_file);
		for(i=0; i<nold; i++) {
			fprintf(pfa_file, "%% %3d ",i);
			for(j=0; j<nold; j++)
				putc( mx[i][j] ? 'X' : '.', pfa_file);
			putc('\n', pfa_file);
		}
	}

	/* now use the matrix to find the best pair for each stem */
	for(i=0; i<nold; i++) {
		int pri, lastpri, v, f;

		x= -1; /* best pair: none */
		lastpri=0;

		v=s[i].value;
		f=s[i].flags;

		if(f & ST_ZONE) {
			pairs[i]= -1;
			continue;
		}

		if(f & ST_UP) {
			for(j=i+1; j<nold; j++) {
				if(mx[i][j]==0)
					continue;

				if( (f | s[j].flags) & ST_END )
					pri=1;
				else if( (f | s[j].flags) & ST_FLAT )
					pri=3;
				else
					pri=2;

				if(lastpri==0
				|| pri > lastpri  
				&& ( lastpri==1 || s[j].value-v<20 || (s[x].value-v)*2 >= s[j].value-v ) ) {
					lastpri=pri;
					x=j;
				}
			}
		} else {
			for(j=i-1; j>=0; j--) {
				if(mx[i][j]==0)
					continue;

				if( (f | s[j].flags) & ST_END )
					pri=1;
				else if( (f | s[j].flags) & ST_FLAT )
					pri=3;
				else
					pri=2;

				if(lastpri==0
				|| pri > lastpri  
				&& ( lastpri==1 || v-s[j].value<20 || (v-s[x].value)*2 >= v-s[j].value ) ) {
					lastpri=pri;
					x=j;
				}
			}
		}
		if(x== -1 && mx[i][i])
			pairs[i]=i; /* a special case */
		else
			pairs[i]=x;
	}

	if(ISDBG(SUBSTEMS)) {
		for(i=0; i<nold; i++) {
			j=pairs[i];
			if(j>0)
				fprintf(pfa_file, "%% %d...%d  (%d x %d)\n", s[i].value, s[j].value, i, j);
		}
	}
}

/*
 * Make all the stems originating at the same value get the
 * same width. Without this the rasterizer may move the dots
 * randomly up or down by one pixel, and that looks bad.
 * The prioritisation is the same as in findstemat().
 */
static void
uniformstems(
	  STEM * s,
	  short *pairs,
	  int ns
)
{
	int i, j, from, to, val, dir;
	int pri, prevpri[2], wd, prevwd[2], prevbest[2];

	for(from=0; from<ns; from=to) {
		prevpri[0] = prevpri[1] = 0;
		prevwd[0] = prevwd[1] = 0;
		prevbest[0] = prevbest[1] = -1;
		val = s[from].value;

		for(to = from; to<ns && s[to].value == val; to++) {
			dir = ((s[to].flags & ST_UP)!=0);

			i=pairs[to]; /* the other side of this stem */
			if(i<0 || i==to)
				continue; /* oops, no other side */
			wd=abs(s[i].value-val);
			if(wd == 0)
				continue;
			pri=1;
			if( (s[to].flags | s[i].flags) & ST_END )
				pri=0;
			if( prevbest[dir] == -1 || pri > prevpri[dir] || wd<prevwd[dir] ) {
				prevbest[dir]=i;
				prevpri[dir]=pri;
				prevwd[dir]=wd;
			}
		}

		for(i=from; i<to; i++) {
			dir = ((s[i].flags & ST_UP)!=0);
			if(prevbest[dir] >= 0) {
				if(ISDBG(SUBSTEMS)) {
					fprintf(stderr, "at %d (%s %d) pair %d->%d(%d)\n", i, 
						(dir ? "UP":"DOWN"), s[i].value, pairs[i], prevbest[dir],
						s[prevbest[dir]].value);
				}
				pairs[i] = prevbest[dir];
			}
		}
	}
}

/* 
 * Find the best stem in the array at the specified (value, origin),
 * related to the entry ge.
 * Returns its index in the array sp, -1 means "none".
 * prevbest is the result for the other end of the line, we must 
 * find something better than it or leave it as it is.
 */
static int
findstemat(
	int value,
	int origin,
	GENTRY *ge,
	STEM *sp,
	short *pairs,
	int ns,
	int prevbest /* -1 means "none" */
)
{
	int i, min, max;
	int v, si;
	int pri, prevpri; /* priority, 0 = has ST_END, 1 = no ST_END */
	int wd, prevwd; /* stem width */

	si= -1; /* nothing yet */

	/* stems are ordered by value, binary search */
	min=0; max=ns; /* min <= i < max */
	while( min < max ) {
		i=(min+max)/2;
		v=sp[i].value;
		if(v<value)
			min=i+1;
		else if(v>value)
			max=i;
		else {
			si=i; /* temporary value */
			break;
		}
	}

	if( si < 0 ) /* found nothing this time */
		return prevbest;

	/* find the priority of the prevbest */
	/* we expect that prevbest has a pair */
	if(prevbest>=0) {
		i=pairs[prevbest];
		prevpri=1;
		if( (sp[prevbest].flags | sp[i].flags) & ST_END )
			prevpri=0; 
		prevwd=abs(sp[i].value-value);
	}

	/* stems are not ordered by origin, so now do the linear search */

	while( si>0 && sp[si-1].value==value ) /* find the first one */
		si--;

	for(; si<ns && sp[si].value==value; si++) {
		if(sp[si].origin != origin) 
			continue;
		if(sp[si].ge != ge) {
			if(ISDBG(SUBSTEMS)) {
				fprintf(stderr, 
					"dbg: possible self-intersection at v=%d o=%d exp_ge=0x%x ge=0x%x\n",
					value, origin, (unsigned int)ge, (unsigned int)sp[si].ge);
			}
			continue;
		}
		i=pairs[si]; /* the other side of this stem */
		if(i<0)
			continue; /* oops, no other side */
		pri=1;
		if( (sp[si].flags | sp[i].flags) & ST_END )
			pri=0;
		wd=abs(sp[i].value-value);
		if( prevbest == -1 || pri >prevpri 
		|| pri==prevpri && prevwd==0 || wd!=0 && wd<prevwd ) {
			prevbest=si;
			prevpri=pri;
			prevwd=wd;
			continue;
		}
	}

	return prevbest;
}

/* add the substems for one glyph entry 
 * (called from groupsubstems())
 * returns 0 if all OK, 1 if too many groups
 */

static int gssentry_lastgrp=0; /* reset to 0 for each new glyph */

static int
gssentry( /* crazy number of parameters */
	GENTRY *ge,
	STEM *hs, /* horizontal stems, sorted by value */
	short *hpairs,
	int nhs,
	STEM *vs, /* vertical stems, sorted by value */
	short *vpairs,
	int nvs,
	STEMBOUNDS *s,
	short *egp,
	int *nextvsi, 
	int *nexthsi /* -2 means "check by yourself" */
) {
	enum {
		SI_VP,	/* vertical primary */
		SI_HP,	/* horizontal primary */
		SI_SIZE /* size of the array */
	};
	int si[SI_SIZE]; /* indexes of relevant stems */

	/* the bounds of the existing relevant stems */
	STEMBOUNDS r[ sizeof(si) / sizeof(si[0]) * 2 ];
	char rexpand; /* by how much we need to expand the group */
	int nr; /* and the number of them */

	/* yet more temporary storage */
	short lb, hb, isvert;
	int conflict, grp;
	int i, j, x, y;


	/* for each line or curve we try to find a horizontal and
	 * a vertical stem corresponding to its first point
	 * (corresponding to the last point of the previous
	 * glyph entry), because the directions of the lines
	 * will be eventually reversed and it will then become the last
	 * point. And the T1 rasterizer applies the hints to 
	 * the last point.
	 *
	 */

	/* start with the common part, the first point */
	x=ge->prev->ix3;
	y=ge->prev->iy3;

	if(*nextvsi == -2)
		si[SI_VP]=findstemat(x, y, ge, vs, vpairs, nvs, -1);
	else {
		si[SI_VP]= *nextvsi; *nextvsi= -2;
	}
	if(*nexthsi == -2)
		si[SI_HP]=findstemat(y, x, ge, hs, hpairs, nhs, -1);
	else {
		si[SI_HP]= *nexthsi; *nexthsi= -2;
	}

	/*
	 * For the horizontal lines we make sure that both
	 * ends of the line have the same horizontal stem,
	 * and the same thing for vertical lines and stems.
	 * In both cases we enforce the stem for the next entry.
	 * Otherwise unpleasant effects may arise.
	 */

	if(ge->type==GE_LINE) {
		if(ge->ix3==x) { /* vertical line */
			*nextvsi=si[SI_VP]=findstemat(x, ge->iy3, ge->frwd, vs, vpairs, nvs, si[SI_VP]);
		} else if(ge->iy3==y) { /* horizontal line */
			*nexthsi=si[SI_HP]=findstemat(y, ge->ix3, ge->frwd, hs, hpairs, nhs, si[SI_HP]);
		}
	}

	if(si[SI_VP]+si[SI_HP] == -2) /* no stems, leave it alone */
		return 0;

	/* build the array of relevant bounds */
	nr=0;
	for(i=0; i< sizeof(si) / sizeof(si[0]); i++) {
		STEM *sp;
		short *pairs;
		int step;
		int f;
		int nzones, firstzone, binzone, einzone;
		int btype, etype;

		if(si[i] < 0)
			continue;

		if(i<SI_HP) {
			r[nr].isvert=1; sp=vs; pairs=vpairs;
		} else {
			r[nr].isvert=0; sp=hs; pairs=hpairs;
		}

		r[nr].low=sp[ si[i] ].value;
		r[nr].high=sp[ pairs[ si[i] ] ].value;

		if(r[nr].low > r[nr].high) {
			j=r[nr].low; r[nr].low=r[nr].high; r[nr].high=j;
			step= -1;
		} else {
			step=1;
		}

		/* handle the interaction with Blue Zones */

		if(i>=SI_HP) { /* only for horizontal stems */
			if(si[i]==pairs[si[i]]) {
				/* special case, the outermost stem in the
				 * Blue Zone without a pair, simulate it to 20-pixel
				 */
				if(sp[ si[i] ].flags & ST_UP) {
					r[nr].high+=20;
					for(j=si[i]+1; j<nhs; j++)
						if( (sp[j].flags & (ST_ZONE|ST_TOPZONE))
						== (ST_ZONE|ST_TOPZONE) ) {
							if(r[nr].high > sp[j].value-2)
								r[nr].high=sp[j].value-2;
							break;
						}
				} else {
					r[nr].low-=20;
					for(j=si[i]-1; j>=0; j--)
						if( (sp[j].flags & (ST_ZONE|ST_TOPZONE))
						== (ST_ZONE) ) {
							if(r[nr].low < sp[j].value+2)
								r[nr].low=sp[j].value+2;
							break;
						}
				}
			}

			/* check that the stem borders don't end up in
			 * different Blue Zones */
			f=sp[ si[i] ].flags;
			nzones=0; einzone=binzone=0;
			for(j=si[i]; j!=pairs[ si[i] ]; j+=step) {
				if( (sp[j].flags & ST_ZONE)==0 )
					continue;
				/* if see a zone border going in the same direction */
				if( ((f ^ sp[j].flags) & ST_UP)==0 ) {
					if( ++nzones == 1 ) {
						firstzone=sp[j].value; /* remember the first one */
						etype=sp[j].flags & ST_TOPZONE;
					}
					einzone=1;

				} else { /* the opposite direction */
					if(nzones==0) { /* beginning is in a blue zone */
						binzone=1;
						btype=sp[j].flags & ST_TOPZONE;
					}
					einzone=0;
				}
			}

			/* beginning and end are in Blue Zones of different types */
			if( binzone && einzone && (btype ^ etype)!=0 ) {
				if( sp[si[i]].flags & ST_UP ) {
					if(firstzone > r[nr].low+22)
						r[nr].high=r[nr].low+20;
					else
						r[nr].high=firstzone-2;
				} else {
					if(firstzone < r[nr].high-22)
						r[nr].low=r[nr].high-20;
					else
						r[nr].low=firstzone+2;
				}
			}
		}

		if(ISDBG(SUBSTEMS))
			fprintf(pfa_file, "%%  at(%d,%d)[%d,%d] %d..%d %c (%d x %d)\n", x, y, i, nr,
				r[nr].low, r[nr].high, r[nr].isvert ? 'v' : 'h',
				si[i], pairs[si[i]]);

		nr++;
	}

	/* now try to find a group */
	conflict=0; /* no conflicts found yet */
	for(j=0; j<nr; j++)
		r[j].already=0;

	/* check if it fits into the last group */
	grp = gssentry_lastgrp;
	i = (grp==0)? 0 : egp[grp-1];
	for(; i<egp[grp]; i++) {
		lb=s[i].low; hb=s[i].high; isvert=s[i].isvert;
		for(j=0; j<nr; j++)
			if( r[j].isvert==isvert  /* intersects */
			&& r[j].low <= hb && r[j].high >= lb ) {
				if( r[j].low == lb && r[j].high == hb ) /* coincides */
					r[j].already=1;
				else
					conflict=1;
			}

		if(conflict) 
			break;
	}

	if(conflict) { /* nope, check all the groups */
		for(j=0; j<nr; j++)
			r[j].already=0;

		for(i=0, grp=0; i<egp[NSTEMGRP-1]; i++) {
			if(i == egp[grp]) { /* checked all stems in a group */
				if(conflict) {
					grp++; conflict=0; /* check the next group */
					for(j=0; j<nr; j++)
						r[j].already=0;
				} else
					break; /* insert into this group */
			}

			lb=s[i].low; hb=s[i].high; isvert=s[i].isvert;
			for(j=0; j<nr; j++)
				if( r[j].isvert==isvert  /* intersects */
				&& r[j].low <= hb && r[j].high >= lb ) {
					if( r[j].low == lb && r[j].high == hb ) /* coincides */
						r[j].already=1;
					else
						conflict=1;
				}

			if(conflict) 
				i=egp[grp]-1; /* fast forward to the next group */
		}
	}

	/* do we have any empty group ? */
	if(conflict && grp < NSTEMGRP-1) {
		grp++; conflict=0;
		for(j=0; j<nr; j++)
			r[j].already=0;
	}

	if(conflict) { /* oops, can't find any group to fit */
		return 1;
	}

	/* OK, add stems to this group */

	rexpand = nr;
	for(j=0; j<nr; j++)
		rexpand -= r[j].already;

	if(rexpand > 0) {
		for(i=egp[NSTEMGRP-1]-1; i>=egp[grp]; i--)
			s[i+rexpand]=s[i];
		for(i=0; i<nr; i++)
			if(!r[i].already)
				s[egp[grp]++]=r[i];
		for(i=grp+1; i<NSTEMGRP; i++)
			egp[i]+=rexpand;
	}

	ge->stemid = gssentry_lastgrp = grp;
	return 0;
}

/*
 * Create the groups of substituted stems from the list.
 * Each group will be represented by a subroutine in the Subs
 * array.
 */

static void
groupsubstems(
	GLYPH *g,
	STEM *hs, /* horizontal stems, sorted by value */
	short *hpairs,
	int nhs,
	STEM *vs, /* vertical stems, sorted by value */
	short *vpairs,
	int nvs
)
{
	GENTRY *ge;
	int i, j;

	/* temporary storage */
	STEMBOUNDS s[MAX_STEMS*2];
	/* indexes in there, pointing past the end each stem group */
	short egp[NSTEMGRP]; 

	int nextvsi, nexthsi; /* -2 means "check by yourself" */

	for(i=0; i<NSTEMGRP; i++)
		egp[i]=0;

	nextvsi=nexthsi= -2; /* processed no horiz/vert line */

	gssentry_lastgrp = 0; /* reset the last group for new glyph */

	for (ge = g->entries; ge != 0; ge = ge->next) {
		if(ge->type!=GE_LINE && ge->type!=GE_CURVE) {
			nextvsi=nexthsi= -2; /* next path is independent */
			continue;
		}

		if( gssentry(ge, hs, hpairs, nhs, vs, vpairs, nvs, s, egp, &nextvsi, &nexthsi) ) {
			WARNING_2 fprintf(stderr, "*** glyph %s requires over %d hint subroutines, ignored them\n",
				g->name, NSTEMGRP);
			/* it's better to have no substituted hints at all than have only part */
			for (ge = g->entries; ge != 0; ge = ge->next)
				ge->stemid= -1;
			g->nsg=0; /* just to be safe, already is 0 by initialization */
			return;
		}

		/*
		 * handle the last vert/horiz line of the path specially,
		 * correct the hint for the first entry of the path
		 */
		if(ge->frwd != ge->next && (nextvsi != -2 || nexthsi != -2) ) {
			if( gssentry(ge->frwd, hs, hpairs, nhs, vs, vpairs, nvs, s, egp, &nextvsi, &nexthsi) ) {
				WARNING_2 fprintf(stderr, "*** glyph %s requires over %d hint subroutines, ignored them\n",
					g->name, NSTEMGRP);
				/* it's better to have no substituted hints at all than have only part */
				for (ge = g->entries; ge != 0; ge = ge->next)
					ge->stemid= -1;
				g->nsg=0; /* just to be safe, already is 0 by initialization */
				return;
			}
		}

	}

	/* find the index of the first empty group - same as the number of groups */
	if(egp[0]>0) {
		for(i=1; i<NSTEMGRP && egp[i]!=egp[i-1]; i++)
			{}
		g->nsg=i;
	} else
		g->nsg=0;

	if(ISDBG(SUBSTEMS)) {
		fprintf(pfa_file, "%% %d substem groups (%d %d %d)\n", g->nsg,
			g->nsg>1 ? egp[g->nsg-2] : -1,
			g->nsg>0 ? egp[g->nsg-1] : -1,
			g->nsg<NSTEMGRP ? egp[g->nsg] : -1 );
		j=0;
		for(i=0; i<g->nsg; i++) {
			fprintf(pfa_file, "%% grp %3d:      ", i);
			for(; j<egp[i]; j++) {
				fprintf(pfa_file, " %4d...%-4d %c  ", s[j].low, s[j].high,
					s[j].isvert ? 'v' : 'h');
			}
			fprintf(pfa_file, "\n");
		}
	}

	if(g->nsg==1) { /* it would be the same as the main stems */
		/* so erase it */
		for (ge = g->entries; ge != 0; ge = ge->next)
			ge->stemid= -1;
		g->nsg=0;
	}

	if(g->nsg>0) {
		if( (g->nsbs=malloc(g->nsg * sizeof (egp[0]))) == 0 ) {
			fprintf(stderr, "**** not enough memory for substituted hints ****\n");
			exit(255);
		}
		memmove(g->nsbs, egp, g->nsg * sizeof(short));
		if( (g->sbstems=malloc(egp[g->nsg-1] * sizeof (s[0]))) == 0 ) {
			fprintf(stderr, "**** not enough memory for substituted hints ****\n");
			exit(255);
		}
		memmove(g->sbstems, s, egp[g->nsg-1] * sizeof(s[0]));
	}
}

void
buildstems(
	   GLYPH * g
)
{
	STEM            hs[MAX_STEMS], vs[MAX_STEMS];	/* temporary working
							 * storage */
	short	hs_pairs[MAX_STEMS], vs_pairs[MAX_STEMS]; /* best pairs for these stems */
	STEM           *sp;
	GENTRY         *ge, *nge, *pge;
	int             nx, ny;
	int ovalue;
	int totals, grp, lastgrp;

	assertisint(g, "buildstems int");

	g->nhs = g->nvs = 0;
	memset(hs, 0, sizeof hs);
	memset(vs, 0, sizeof vs);

	/* first search the whole character for possible stem points */

	for (ge = g->entries; ge != 0; ge = ge->next) {
		if (ge->type == GE_CURVE) {

			/*
			 * SURPRISE! 
			 * We consider the stems bound by the
			 * H/V ends of the curves as flat ones.
			 *
			 * But we don't include the point on the
			 * other end into the range.
			 */

			/* first check the beginning of curve */
			/* if it is horizontal, add a hstem */
			if (ge->iy1 == ge->prev->iy3) {
				hs[g->nhs].value = ge->iy1;

				if (ge->ix1 < ge->prev->ix3)
					hs[g->nhs].flags = ST_FLAT | ST_UP;
				else
					hs[g->nhs].flags = ST_FLAT;

				hs[g->nhs].origin = ge->prev->ix3;
				hs[g->nhs].ge = ge;

				if (ge->ix1 < ge->prev->ix3) {
					hs[g->nhs].from = ge->ix1+1;
					hs[g->nhs].to = ge->prev->ix3;
					if(hs[g->nhs].from > hs[g->nhs].to)
						hs[g->nhs].from--;
				} else {
					hs[g->nhs].from = ge->prev->ix3;
					hs[g->nhs].to = ge->ix1-1;
					if(hs[g->nhs].from > hs[g->nhs].to)
						hs[g->nhs].to++;
				}
				if (ge->ix1 != ge->prev->ix3)
					g->nhs++;
			}
			/* if it is vertical, add a vstem */
			else if (ge->ix1 == ge->prev->ix3) {
				vs[g->nvs].value = ge->ix1;

				if (ge->iy1 > ge->prev->iy3)
					vs[g->nvs].flags = ST_FLAT | ST_UP;
				else
					vs[g->nvs].flags = ST_FLAT;

				vs[g->nvs].origin = ge->prev->iy3;
				vs[g->nvs].ge = ge;

				if (ge->iy1 < ge->prev->iy3) {
					vs[g->nvs].from = ge->iy1+1;
					vs[g->nvs].to = ge->prev->iy3;
					if(vs[g->nvs].from > vs[g->nvs].to)
						vs[g->nvs].from--;
				} else {
					vs[g->nvs].from = ge->prev->iy3;
					vs[g->nvs].to = ge->iy1-1;
					if(vs[g->nvs].from > vs[g->nvs].to)
						vs[g->nvs].to++;
				}

				if (ge->iy1 != ge->prev->iy3)
					g->nvs++;
			}
			/* then check the end of curve */
			/* if it is horizontal, add a hstem */
			if (ge->iy3 == ge->iy2) {
				hs[g->nhs].value = ge->iy3;

				if (ge->ix3 < ge->ix2)
					hs[g->nhs].flags = ST_FLAT | ST_UP;
				else
					hs[g->nhs].flags = ST_FLAT;

				hs[g->nhs].origin = ge->ix3;
				hs[g->nhs].ge = ge->frwd;

				if (ge->ix3 < ge->ix2) {
					hs[g->nhs].from = ge->ix3;
					hs[g->nhs].to = ge->ix2-1;
					if( hs[g->nhs].from > hs[g->nhs].to )
						hs[g->nhs].to++;
				} else {
					hs[g->nhs].from = ge->ix2+1;
					hs[g->nhs].to = ge->ix3;
					if( hs[g->nhs].from > hs[g->nhs].to )
						hs[g->nhs].from--;
				}

				if (ge->ix3 != ge->ix2)
					g->nhs++;
			}
			/* if it is vertical, add a vstem */
			else if (ge->ix3 == ge->ix2) {
				vs[g->nvs].value = ge->ix3;

				if (ge->iy3 > ge->iy2)
					vs[g->nvs].flags = ST_FLAT | ST_UP;
				else
					vs[g->nvs].flags = ST_FLAT;

				vs[g->nvs].origin = ge->iy3;
				vs[g->nvs].ge = ge->frwd;

				if (ge->iy3 < ge->iy2) {
					vs[g->nvs].from = ge->iy3;
					vs[g->nvs].to = ge->iy2-1;
					if( vs[g->nvs].from > vs[g->nvs].to )
						vs[g->nvs].to++;
				} else {
					vs[g->nvs].from = ge->iy2+1;
					vs[g->nvs].to = ge->iy3;
					if( vs[g->nvs].from > vs[g->nvs].to )
						vs[g->nvs].from--;
				}

				if (ge->iy3 != ge->iy2)
					g->nvs++;
			} else {

				/*
				 * check the end of curve for a not smooth
				 * local extremum
				 */
				nge = ge->frwd;

				if (nge == 0)
					continue;
				else if (nge->type == GE_LINE) {
					nx = nge->ix3;
					ny = nge->iy3;
				} else if (nge->type == GE_CURVE) {
					nx = nge->ix1;
					ny = nge->iy1;
				} else
					continue;

				/* check for vertical extremums */
				if (ge->iy3 > ge->iy2 && ge->iy3 > ny
				|| ge->iy3 < ge->iy2 && ge->iy3 < ny) {
					hs[g->nhs].value = ge->iy3;
					hs[g->nhs].from
						= hs[g->nhs].to
						= hs[g->nhs].origin = ge->ix3;
					hs[g->nhs].ge = ge->frwd;

					if (ge->ix3 < ge->ix2
					    || nx < ge->ix3)
						hs[g->nhs].flags = ST_UP;
					else
						hs[g->nhs].flags = 0;

					if (ge->ix3 != ge->ix2 || nx != ge->ix3)
						g->nhs++;
				}
				/*
				 * the same point may be both horizontal and
				 * vertical extremum
				 */
				/* check for horizontal extremums */
				if (ge->ix3 > ge->ix2 && ge->ix3 > nx
				|| ge->ix3 < ge->ix2 && ge->ix3 < nx) {
					vs[g->nvs].value = ge->ix3;
					vs[g->nvs].from
						= vs[g->nvs].to
						= vs[g->nvs].origin = ge->iy3;
					vs[g->nvs].ge = ge->frwd;

					if (ge->iy3 > ge->iy2
					    || ny > ge->iy3)
						vs[g->nvs].flags = ST_UP;
					else
						vs[g->nvs].flags = 0;

					if (ge->iy3 != ge->iy2 || ny != ge->iy3)
						g->nvs++;
				}
			}

		} else if (ge->type == GE_LINE) {
			nge = ge->frwd;

			/* if it is horizontal, add a hstem */
			/* and the ends as vstems if they brace the line */
			if (ge->iy3 == ge->prev->iy3
			&& ge->ix3 != ge->prev->ix3) {
				hs[g->nhs].value = ge->iy3;
				if (ge->ix3 < ge->prev->ix3) {
					hs[g->nhs].flags = ST_FLAT | ST_UP;
					hs[g->nhs].from = ge->ix3;
					hs[g->nhs].to = ge->prev->ix3;
				} else {
					hs[g->nhs].flags = ST_FLAT;
					hs[g->nhs].from = ge->prev->ix3;
					hs[g->nhs].to = ge->ix3;
				}
				hs[g->nhs].origin = ge->ix3;
				hs[g->nhs].ge = ge->frwd;

				pge = ge->bkwd;

				/* add beginning as vstem */
				vs[g->nvs].value = pge->ix3;
				vs[g->nvs].origin
					= vs[g->nvs].from
					= vs[g->nvs].to = pge->iy3;
				vs[g->nvs].ge = ge;

				if(pge->type==GE_CURVE)
					ovalue=pge->iy2;
				else
					ovalue=pge->prev->iy3;

				if (pge->iy3 > ovalue)
					vs[g->nvs].flags = ST_UP | ST_EN<se {
					<	r[nr].stem[not bo(pge->typ	<	r[nr].steg->nvs].ois			xbstem[nsg-1] : -1,roups
 */

static int3ihs */
				g)m		g)m
			W.flags =frwd1rs[si[i]]); */
				nge = ng as vstem */
						/*
			ue = pge-o;
						 = ge->iy3;
		gin
					= vs[g->nvs].from
					= vs[g->nvs].to o;
				<	 = ge->iy3;
		gin
					= vs[g->nvs].e->type==GE_CURVE)
					ovalue=pge->iy2;
				else
					ovalue=pge->prev->iy3;

				if (pge->iy			hs[g->nhs].to++;
				} else {
					hs[g->nhs].from = ge
						vs[g->nvs].fhags = 0;

					if (ge->iy3 !=om = ge->ix2+1;
					hs[g->nhs]ix3 < ge- ->nvs++;
			y}
			}

		} elseyx1-1;
					if(hs[g->nhs].from > hs= ge->frwd;

			x
				|| 

				if (ge->iy1 > ge->prev->			/* and the ends as vstems >nvs].ge = ge;

				if (ge->iy1 < ge->prev->iy3) {
					vs[g	&& ge->ix3 != ge->pr	g->nhs++;
			}
			/* if it tems >nvs].ge = ge;

				ifiy1 < ge->prev->iy3) {
					vs (ge->iy1 < ge-}
					<	r[nr].stem[not[nsg-1] : -1,roups
 */

static int3ihs */
				g= ge->prev->ix3;
				} else {
					hs[g->P;
					elsetype == GE_LINE) {
	.origin = ge->LAT | ST_UP;
				eg->nvs]ny = nge->iy1;
				} lse
					contin[g->nhs].from = grev->iy3) {
				hs[g->nhs].->frwd;

				pge = ge->bkwd;

				/* addxbeginning as vstem */
				vs[g->nvs]xvalue = pge->ix3;
xiy3;
				vs[g->nv
					hs[g->nhs].value =om
					= vs[g->nvs].to = pge-x			vs[g->nvs].ori
					hs[g->nhs].valuee->type==GE_CURVE)
g->nhs].from
						= hs[g->[g->nhs].from = pge->prev->iy3;

				hf (pge->iy3 > ovalue)
		P;
					elsetype == GE_LINE) {
	origin = ge->LAT | ST_UP;
				eg->nvs]ny = nge->iy1;
				} lse
					contin[g-stem */
			if (ge->iy3 == ge->iy2) {
				hs[g-		g)m
			W.flags =frwd1rs[si[i]]); */
		x	nge = ng as vstem */
						/*x			ue = pge-o;
				& ge->iy3 < ny) 
					hs[g->nhs].value =om
					= vs[g->nvs].to o;
						 = gey3 < ny) 
					hs[g->nhs].valuee->type==GE_CURVE)
g->nhs].from
						= hs[g->[g->nhs].from = pge->prev->iy3;

				hf (pge->iyvs].from--;
				} el		} 				vs[g->nvs].from y3 !=iy2+1;
					vs[gto = g		} 			hs[g->nhs].f			else    || ny > ge->iy3)s].to )
						vs[g>nvs].from--;				}

				if (ge->iy3 != ge->iy2)
				g->nvs++;
			} ele {

				/*
				 *check the end of curve for a not smooth
			 * local extremu
				 */
				nge =ge->frwd;

			if (nge == )
					continue;
				else if (nge->typrwd;

			x
				|| 

				if x = nge->ix3;
					n = nge->iy3;
				

				if x = nge->ix3>type == GE_ype == GE_LINE) {
	origin = ge->LAT | ST_UPy1;
				} lse
					contin				} lse
					cont, add a hstem */
			if (ge->iy3 == ge->iy2) {
				hs[g->nhs].value = geg->nvs]xv		hs[ ge->iy2 && ge->iy3 < ny) 
					hs[g->nhs].value = ge->iGE_CURVE)
g->nhs].from
						= hs[g->[g].to
						= hs[gix3 < ge- s].origin = ge->ix3;
					hs[g->nhs].to++;
		} 							if (ge->ix3 < ge->ix2
					    || nx nue;
						} 			hs[g->nhs].f			else_UP;
					else
						hs[g->nhs].flags = ;

					if (ge->ixix3 < ge-  ge->ix2 || nx != g->ix3)
						g->nix3 < ge-  ge->ix2 ||	/*
				 * t.flags = ST_UP | ST_EN<se {
					<	r[nr].st].steg->nvs].ois			xbstemeg->nvs].ois			xbst a vstem */
			else if (ge->ix3 == ge->ix2) {
				vs[g->nvs].valu			|| 

				if 		hs[ ge->iy2 && ge->ix3 < nx) 
					vs[g->nvs].value = ge->iGE_CURVE)
					ovalue=pge->iy2;
				els].to
						= vs[g

				if xs].origin = ge->iy3;
		vs].from--;
				}) {
						hs[= ovlast)p[g->for 			hs[*/
	l be)p[g->for 			hs[*/
	l be)p[g->vor 			hGENTRY ls].turn;
	h=r[nr].li    )p[g->			h-2) )for 			hs[ert/ho			hGENTRY ed hints at _STEMS], w=sp[ hs[ entry), T_TOPZONE))
			marklast)p[g->for 			hs[*/
			}
subts **ildstems i	r[nr].high=r[nr].low+20;
					else
						%s: 2)
	 hs[stitup;
	return 0;
}

as the nu-2)g->nsg)
		printf("ndle g->sbstr 			hs[errev->	me value get ndle g->sbstr 			hs[)[i] < 0 i	r[nr].high=r[nr].low+20;
					else
						%s: 2)
	 hs[stitup* Each group was the nu-2)g->nsg)
		printf("t/horg->sbstr 			h     )[i] <	}

	ge->stemighandle g->sbstr 			hs[ert/horg->sbstr 			h   prevbes 0 i	r[nr]MAINgh=r[nr].lw+20;
					else
						%s: 2)
	 hs[or(; ;
	return 0;
}

as the nu-2)g->n			hs[>iy2)
	or(;)p[g->for 			hs[errev-> 0 i	r[nr]MAINgh=r[nr].lw+20;
					else
						%s: 2)
	 hs[or(; * Each group was the nu-2)g->n			h  >iy2)
	or(;)p[g->vtr 			h     )[i]  0 i	r[nr]MAINgh=r[nr].li    )p[g->			h-2) )for 			hs[ert/ho			hGENTRY 	}
			fs[>	r[j].alr 0 i(sroups=mallot));
		gh=r,	/*			hs[)= 0 ) 
			fprintf(stderr, "**** not enough memory for subts ****\n");
			exit(255);
		}
		mem			hags = = nhs, sorycpy(beste */
	);
		gh=r,	/*			hs[);y initializatihags = = 0TRY 	}
			fv[>	r[j].alr 0 i(sroups=mallot));
		gh=r,	/*			hv[)= 0 ) 
			fprintf(stderr, "**** not enough memory for subts ****\n");
			exit(255);
		}
		mem			vags = = nhs, sorycpy(bestv */
	);
		gh=r,	/*			hv[);y initializativags = = 0TRY 			}
		or(j=si[i]-1; j>=0;s wor (ge->ffle efficient 

	nt 'rr, 
		stacka gap  in cient 

	nt s (t *paX11) push		else
			pan nhs,
ch|
	 *
		i gap  tack nx npoplevantvsi,       e, *pge;
	 pathselse        d	 * ends king
	 = 
			fs[+			hv[)		a - 			mincouvaluge;
	 egp, g enohalvE))
			stem group-1;	int totals, grp, lastgrp;

	assertisint(g, "buildsteb ) t(g,	s[j].;
g->nsggro= -1b ) /* c	asstem gr) 
			retur]);

		y3;
	king
	 +STEMS]sbif( om--;				y3;
	king
	 +STEMS]sbif

	r -TEMS]sbif

	 now y3;
egp[NSTEMGRP-1]-igh >= lb )bee != 0;n",
	 o=%d,P;
					els= - g eno> ge = geking
	 >ups=x_	s[jdept<SI_ rp]-1; /* wd<pdeer[j].hihint for t		fprintf(stderr, "***War	 hs:e path
		 ze os != ge-tack dept<m[i++]=x			h-2) )king
	d %d)\nntf(stderr, "***  (t mibest):|---|    c unsigned char ts ***ge;

it++]=xs=x_	s[jdept<S	}
		mem	}
			fpr
						c +=) ) {
			WARNING_2 fprintf(stderr, "*** glyph %s requires ov d hint sufre->nsbs, egp,); nsbs, egp,  s,
	  ufre->nsb]sbi); nsb]sbi  s,
	  u			fpr
 s,
	  utc('0'+j%10, r[nr].lowalue  elsewd<prevwdor(; j<egp[i]; king
	 = 
			fs[+			hv[)		a - 			mincouvaluge;
	 egp, g enohalvE))
			 geking
	 >ups=x_	s[jdept<SI_ 
se_UPd > 0wor].higd<prE /*o<noln-];
		for(i=0; i<nrj].hihint for t		fprintf(stderr, "***War	 hs:e path
		 ue)
%d[or(; ;s **++]=x			h-2) )king
	d %d)\nntf(stderr, "***  (t mibest):|---|    c unts ***ge;

it++]=xs=x_	s[jdept<S	}
		mem	}
			vags =			c +=)re->nsbv egp,); nsbvags = = 0TTEMS]; /* best		mem	}
			hags =			c +=)re->nsbh egp,); nsbhags = = 0TTEMS]hs
 s,
	  utc('=abs(s			 ? egweird characti[i]-elsecloZONE ), nhs,
		if, nhs.
endss=malfstraighten>nsg-1] * sizeof (s[0YPH * g
)
{
	STEM    pM          i hs[Mdou ny;;;;;;;;;;d+si[AX_STEMS], vs[MAdomly dou ny;;;;;;;;;;iln, olnsi[AX_STEMS], vs[MAsvd}

	i, o;	int toti
			WARNING_2 fpriintf(stdei
			Wit(g, "buildste 0 iid of curv! for a not 
;

			if (nge ==
			Wit(
	  = ge->prev->ix3;se    || ny > ge->iy3df
 s,.;ave novalueontinue;
				ee {
	;
	return 0.high >= SDBG(SU2)) {
		fprinn[g-!pairs, it looxir[nr].hi	iln[g-fnt)s ny > ovalu
			2r -Tp ny > ovalu
			2rd %d)\oln[g-fnt)s ny > ovalu
o		2r -Tp ny > ovalu
o		2rd %d)\;
		} 			im = gectio= ge->ALLYl.higha* and the same,orizont		} 			st
	S][MA
			xpan].fr;
	return i, (				vs[g

		/ "bu		} 			y3 !=st
	S][M2)
				vs[gi, ?)s].f			else[g->oln[< 1.!= g->ix3)
> ovalu
o		2r g->nhs]> ovalu
o		1] != g->ix3)
> ovalu
o		0r g->p ny > ovalu
o		2r!= g->iiln[> 2.!= g->iiln[> 1. b ) iln/oln[> 0.1 		vs[g>nvs].from>iy3)s].turn;
	hRAIGHTEN)t==isvenntf(stderr, "***  straightenLYl.high%*++]=x(i? ";
	return ":" and the")	prevprdf
 s ny > ovalu
			2r -Tp ny > ovalu
			2r %d)\].flagfgin)s ny > ovalu
o		2r -Tp ny > ovalu
o		2rd %d)\d of curve3 != ge-ge == )
		} 			sur].ln */
		elseequence=s[i]; /*Yl.higheach li} 			ifferent Blue Zones */
			f= the enodevi]=x;
		} 				d<pfar*ge;

ue;
						} 		/.hi	iln[g-fnt)sn ny > ovalu
			2r -T ny > ovalu
			2rd %d)\oln[g-n ny > ovalu
o		2r -T ny > ovalu
o		2rge == =pair (fnt)sdf)].al5b ) nd of curve for a not ==  ) ].flaagfgin)soln)*/
			vs, sso giractoln[prev- group */iln[.al2.!= g				iiln[.al1. b->iiln/fnt)soln)*<= 0.1 	rect the  ny >hs[g-n ny >e {
				 ny >ys[g-n ny >
			ue = pg.turn;
	hRAIGHTEN)ty3;
		nntf(stderr, "***  straightenLcol-|
	fere%*++]=x(i? ";
	return ":" and the")	pr	 +=)re-roupgesn n	pr	 +=)ix].fid= ( n	pr	 +== ge->prev->ix3;seg->nvs].from > vs[g->nvdf
 s ny > ovalu
			2r -Tp ny > ovalu
			2r %ue = pln[g-fnt)sn ny > ovalu
			2r -T ny > ovalu
			2rd %d)\\oln[g-n ny > ovalu
o		2r -T ny > ovalu
o		2rge					}
					10, r[nr].w	vs, {
					if( sb, isvert/ "bug past the em	}
	rv! fpo the ue = pg. pd of curve for )
		egp[p ny > ovalu
			2r g->p ny 

				> ovalu
			2rue = gp[fnt)sp ny > ovalu
o		2rv! fpo y 

				> ovalu
o		2rd				break; /*turn;
	hRAIGHTEN)t=nntf(stderr, "***  straightenL2)
		 entr, isvert  && si].value origin) 
			cop != origin) 
			co n	pr	 +=				j=i-1;
	r, isvert  past entr= gectiob=s[i].hp ny >hs[g- ny >e {
				hp ny >ys[g- ny >
			ue = 	i
			W)re-roupges n	y 

		airs,keer[ffici w=sttinualidob=s[i].hg {
	.or{
				h)ix].fid= ( n	pr	 +=== ge->prev->ix3;seg-;
					}
			}
	rv! fno the ue = pg				if (ge->iy3 != ge-b ) nd of> ovalu
			2r g->d of> ovalu
			2rue = gp[fnt)sn ny > ovalu
o		2r !->nhs]> ovalu
o		2rd				break; /*turn;
	hRAIGHTEN)t=nntf(stderr, "***  straightenL2)
		 entr "bug && si].value origin) 
			co != origin) 
			con n	pr	 +=				j=i-1;
	r "bug past entr= gectiob=s[i].h ny >hs[g-n ny >e {
					 ny >ys[g-n ny >
			ue = =)re-roupgesn n	pr	 +=h)ix].fid= ( n	pr	 +=== ge->prev->ix3;seg-->nvs].from > vs[g->nv;
					}
			}
	rv! fpo the ue = /
		

		ifalign for each  j<noeces id by valu			}
df
prev.ty3;
		ncloZOgapup fog	pairsdf, NULL)			 *check t{ue = /
	>nvsour	memses */
st PAINFUL same,oEMS)rifrom iiob=s[i].i
			W)re-roupges n	airs,keer[ffici w=sttinualidob=s[i].y=1; )
					*/
			ALLw);
			fs at >nvsour	w; hb=s[ir to have 	i
			Wit(g,

		a
					}
		RP-1]; i++EMS][MAX_STEMaluex;
	}

	if( it looxir[nr]  utc('=abs(ssolif(  squelseequ	/* i,vpri && prevg->entries; gesoluy;


	t(%d,high; soluy;


P; i++ets ** 
			shor.w	is,
	hrp %3e->ix3	ifa /* horitw ) {u nyn),
 i; /*				riort mibe=y) { ear subsoluy;


P; rn prevbest;
}fsqequ	/* i(y dou ny;a,y dou ny;b,y dou ny;c,y dou ny;*hor,y dou ny;mx in dou ny;maxf (s[0dou ny;Dsi[AX_Sn
				return;
	QEQ)t=nntf(stderr, "* "sqeq(%g,%g,%g) [%g;%g]alue a,;b,;c,t 
 * finNTRY 	}
fnt)sa)rray.00000_file, "%f(  (prevbeequ	/* i[nr]  n=0;

		}
fnt)sb)rray.00000_fi,
	sho*		eequ	/* i[vs, s,  it's betters,
	  horairs,
-c/b;

		}
turn;
	QEQ)t=nntf(stderr, "* "sqeq: (prevbet=%galue horairsg>0) {
horairs>ups /*s grorairs<ups=xty3;
nom--;
bettersnprevbesDs,
b*b -T4.0*a*c;			return;
	QEQ)t=nntf(stderr, "* "sqeq: D=%galue Dev-> 0(Dpossib
		} else ifDs,
sqrt(DNTRY n=0;

horairs,
(-b+D)		a(2*a);			return;
	QEQ)t=nntf(stderr, "* "sqeq: t1=%galue horairsg>0 {
horairs>ups /*s grorairs<ups=xty3;n (pge-roranrs,
(-b-D)		a(2*a);			return;
	QEQ)t=nntf(stderr, "* "sqeq: t2=%galue horanrsg>0 {
horanrs>ups /*s groranrs<ups=xty3;n (pge-/ri && pr 2tem iluy;

t PAIN			} 'ste directiough mem
			 gen==++;
	fnt)srorair-rora1])<y.00000_f]  n=1pge-rottersnpr=abs(s	r(j=si[i]-1; jcharactEMS][Mcross qu	drl line */d by vas(s(float); rn ]; i Hue  	else {
		si[SI_VP1; jchara=st
		sho*>nvs].fr*hpai i ;
	return 0tinue;
				else if (n.lue, al stems, soovalue{ e i explapree en
	int nhsovalue{ ei];
	nalogy.
 i ue, al stems, soovalue{ e.w	ert i, j,eriv	/*ve i dy/dx>ALLequ	l			co.ts */y), Tezier character j,efpreei]; i  glyph rbesvaluus a i  x=fx(t) i  y=fy(t) i sif(ISD< max */
,eriv	/*veelse     nt   d	   Asso d > 0			wet stem in 3e->ix3(x,y) s  nt=x;
	}

	ilse/

	/* elsefar*xpectbsvert.ge, tun   AINminc		eint dy/dt
 s, (;)p[ad,vpgroup ?eing toa =st=%d o=     squelseequ	/* i, -1);  nt=x;

 [vs,  kn...%_UP | oritelseo=    .
 i ue, valuus ater :
 i 				A*(1-t)^3 + 3*B*(1-t)^2*t + 3*C*(1-t)*t^2 + D*t^3 i 				(-A+3*B-3*C+D)*t^3 + (3*A-6*B+3*C)*t^2 + (-3*A+3*B)*t + A i dy/dt
 s3*(-A+3*B-3*C+D)*t^2 + 2*(3*A-6*B+3*C)*t + (-3*A+3*B)P; rn s=malf)ixqu	drl lmid = gssentf (s[0YPH * g
)
{
	STEM    n hs[MAX_	/ sizenp, oldnply dou ny	sp[5p[g->n;  ntsoovalu	 * stNFUL part *MS))
ntaldir[5p[g->n subi    gx;
,es */
			f= y.w	is,
	  ntshappereeiMS))dou ny;a,;b,;*ptx;
	inoovalueof(  om = ge->int totals, grp, lastgrp;

	assertisint(g, "buildstems int");

	g! for a not 
;

			if (nge		))doagapr:]  nroup */
	ss, n  ntsoovalu%d)[%d,%d		return;
QUAD)
			fprintf(stderr, "***%s: 	

x;
	 && s(%g %g) (%g %g) (%g %g) (%g %g)\negp[g			h-2) ave 	origin) 
			co !=  vs[g

				f->ix3==x

				foth casesx1h casesy1h casesx2h casesy2, the  ny >hsh casesy3S	}
		mem >= SDBG(SU2)) {
		f ) {

			/t toxee {
	t toby valu	ed hints at col sdn   ueof(			irolt ovalue;
	lu	a					vs (ge->> ovalu
			2r %d)\ptx			&d of> ovalu
			0r %ue =oldnp[g-n-1]-i nro+agfgqequ	/* i(y    3.0*(-a + 3.0*ptxairs- 3.0*ptxa1] + ptxa2rd, the 6.0*(as- 2.0*ptxairs+ ptxa1rd, the 3.0*(-a + ptxaird, the &sp[np = ((s[y.0, 1.0	airs,XXXe->typelse[0;(shothe em	}
np[g= oldnp		vs[g>nvs].from>	d		return;
QUAD)
=isvenntf(stderr, "***%s:  && :
%d[ptx(%c):gp[g
					 		h-2) )origin) 
			co != np-oldnppai? 'y':'x')ge == )
	---|  t ovaluei[i]-else	d<pcloZONE )vs[g->nvs		} 			p;
	int al inting->nvs]lsepermibtee e sso		} 			im gh; s  ntsoovalelseVE* gcloZONE )vs[g->nv		} 			pthe enoexactlyee {
	ored for tenLs, snts[j].lowgapre == GE_C			else
 = oldnpRP-1)p	g->nsg>1 ? edir[jrs,
		if(wd	return;
QUAD)
=isveenntf(stderr, "***%ggp[g-he f)	if(wd	re-he frray.03		f ) {
ront>nvs].from = ge->pre	->nsg=0;  ovalu
			0r		= vs[g

				> ovalu
			2rdpairs[ sig=0;  ovalu
			0r					vs (ge->> ovalu
			2r %d)\(wd	return;
QUAD)
=nntf(stderr, "* "for ten1;
	t{
ront);
			exi sigot ) {wgapr		exi s}>pre	->ns>d of> ovalu
			1r !->nhs]> ovalu
			0r>pre	-;
	fgin)s ny > ovalu
			2r -T ny > ovalu
			1rd	exi si	!agfgin)s ny > ovalu
			1r -T ny > ovalu
			0rd				break;ig=0;  ovalu
			1]
 s ny > ovalu
			0r %d)\(wd	return;
QUAD)
=nntf(stderr, "* "for ten1;
zigzag
	t{
ront);
			exi sigot ) {wgapr		exi s}>pre	--he fr=g-he +to bnp--T_ZON;
)\(wd	return;
QUAD)
=nntf(stderr, "* "(
ront>for )egp		if(prery.
	 * O-he fr> 0.97		f ) {revbeevs].from = ge->pre	->nsg=0;  ovalu
			1r !->nhs]> ovalu
			2rdpairs[ sig=0;  ovalu
			1]
 s ny > ovalu
			2r %d)\(wd	return;
QUAD)
=nntf(stderr, "* "for ten1;
	t{revb);
			exi sigot ) {wgapr		exi s}>pre	->ns>d of> ovalu
			0r !->nhs]> ovalu
			1r>pre	-;
	fgin)s ny  (ge->> ovalu
			2r -T ny > ovalu
			0rd	exi si	!agfgin)s ny > ovalu
			0r -T ny > ovalu
			1rd				break;ig=0;  ovalu
			0]
 s ny > ovalu
			1r %d)\(wd	return;
QUAD)
=nntf(stderr, "* "for ten1;
zigzag
	t{revb);
			exi sigot ) {wgapr		exi s}>pre	--he fr=g-he +to bnp--T_ZON;
)\(wd	return;
QUAD)
=nntf(stderr, "* "(revbefor )egp		if(prer
i s}>pre	return;
QUAD)
=nntf(stderr, "* "nsg; i++) 
em	}
np{
			
	ss, n  ntsoovaluairs, nvs, si[SI_VP]);relevant bounds *turn;
QUAD)
			fprintf(stderr, "***%s: s  nt=x;
	 && s(%g %g) (%g %g) (%g %g) (%g %g)
	t{%%3e->ixs\negp[g			h-2) ave 	origin) 
			co !=  vs[g

				f->ix3==x

				foth casesx1h casesy1h casesx2h casesy2, the  ny >hsh casesy3= npd %d)\n", eturn 1;p be safe, enntf(stderr, "***%g(%c)gp[g-he				dir[i] ? 'y':'x')ge, enntf(stderr, "***nsg; i++) 
ems(ssortentries; gvs].ceSD< ma.high >= SDBG(SU;p be safe,  NSTEMii]==paipict=0; /* chec-he		-pixel
				break;ar=g-he			g-he		-=g-he 		g-he fr=ga3;seg-;

					10, hinn i,  */
	ifn  ntsan nhs,
of the lin< NSTEMGRP-1)p	g->nsg>1 ? dou ny;k1h k2h cge == k1-=g-he 		 == k2 ; j!-;k1om>	d		return;
QUAD)
=nntf(stderr, "* "	ST && s%g/%galue origin) 
			co != k1h k2)ge == >nvs].newg	}

		GEF_FLOAT)ge, e(*no th		(* n	pr
#,efpre SPLIT(pt1h pt2)	( (pt1) + k1*((pt2)-(pt1))		lb=s		 * de */emortl l!GE_C			elseSDBG(SU2)) {
		f ) {
 toxesntsby valu		a
 s ny > ovalu
			0r  ) {gt egp[Nmidted  ovalue;
	lu		b
 s ny > ovalu
			1r %ue = /
	>alc handlt neient nalt ovalue;
	lu		c.valPLIT(a,;b)pge->iyv=0;  ovalu
			0]
 slPLIT( ny  (ge->> ovalu
			2r e );e->iyv=0;  ovalu
			1]
 slPLIT( ny   ovalu
			0]h c)pge->iynd of> ovalu
			1]
 slPLIT(b,;nd of> ovalu
			2r);e->iynd of> ovalu
			0]
 slPLIT(c,;nd of> ovalu
			1])pge->iyv=0;  ovalu
			2]
 slPLIT( ny   ovalu
			1 = ((s[	+;nd of> ovalu
			irsg>0)-;
#un,efslPLITge->iaddge     up fon n	pr == )
	go[j].low <= hb the dadored ---a
	 hs[ ovalue;
	lu	nvs].nor{
			elseSDj; j<nr;p be safe, e-he		-=gc-he		-k_fi, k2
	  utc('0=abs(s	r(j=sif(  om = gALLY
zigzag
 rn prevbest;
}iiszigzag( array.
 */

) (s[0dou ny;;;;;;;;;;k= k1h k2si[AX_STEMS], vs[MAa,;b[i]  0 int");

	g! for a not 
;

		} else ifa
 s ny ->nv-s ny ->int b
 s ny hs++-s ny - extr	rea 0 ) 
			fp	reb 0 ) 
			fprbetters,
	  ge->frwd;
k
 sFBIGVAL;y initializk[g-fnt)s(dou ny) b		a(dou ny) a)e ifa
 s ny ->1+-s ny  (ge->iy1 < b
 s ny hs1+-s ny  (ge->ie {
		rea 0 ) 
			fp	reb 0 ) 
			fprbetters,
	  ge->frwd;
k1
 sFBIGVAL;y initializk1[g-fnt)s(dou ny) b		a(dou ny) a)e ifa
 s ny ->3v-s ny ->2 < b
 s ny hs3v-s ny -xbegi	rea 0 ) 
			fp	reb 0 ) 
			fprbetters,
	  ge->frwd;
k2
 sFBIGVAL;y initializk2[g-fnt)s(dou ny) b		a(dou ny) a)e if/		im gh; om = gALLsho*	
zigzag
 rn  0 ik1+y.0001s>upk+;
	k2[<upk+y.0001s|| k1[<upk+y.0001s;
	k2+y.0001s>upk 
;

		} else ;				y3;
		}
	}

	=abs(s	r(j=sif(  om = gALLY
zigzag
- float< ma.hi prevbest;
}fiszigzag( array.
 */

) (s[0dou ny;;;;;;;;;;k= k1h k2si[dou ny;;;;;;;;;;a,;b[i]  0 int");

	g! for a not 
;

		} else ifa
 sfnt)s ny >>nv-s ny sy1) < b
 sfnt)s ny >s++-s ny sx1)egi	rea < FEPS
			fp	reb < FEPS
			fprbetters,
	  ge->frwd;
k
 sFBIGVAL;y initializk[g-b		aae ifa
 sfnt)s ny >>1+-s ny  (ge->sy3S	}
b
 sfnt)s ny >s1+-s ny  (ge->sx3)egi	rea < FEPS
			fp	reb < FEPS
			fprbetters,
	  ge->frwd;
k1
 sFBIGVAL;y initializk1[g-b		aae ifa
 sfnt)s ny >>3v-s ny sy2S	}
b
 sfnt)s ny >s3v-s ny sx2)egi	rea < FEPS
			fp	reb < FEPS
			fprbetters,
	  ge->frwd;
k2
 sFBIGVAL;y initializk2[g-b		aae if/		im gh; om = gALLsho*	
zigzag
 rn  0 ik1+y.0001s>upk+;
	k2[<upk+y.0001s|| k1[<upk+y.0001s;
	k2+y.0001s>upk 
;

		} else ;				y3;
		}
	}

	=abs(sn  ntsgh; zigzag-t *pacharacti		if wob thes; rn s=malfn  ntzigzag->nsg-1-1] * sizeof (s[0YPH * g
)
{
	STEM    n hs[Mdou ny;;;;;;;;;;a,;b,;c,tdge */
	shortfloat_pairs  nt=x;
	zigzag-g; i+t totals, grp, lastgrp;

	assertisint(g, "buildstems int");

	g! for a not 
;

			if (nge
	f/		im gh; om = gALLsho*	
zigzag
 rn ems i !fiszigzag(o th
			fprrp = 0; /* reset theturn;
FCONCISE)sg>1 ? dou ny;maxsc1,;maxsc2))e, enntf(stderr, "***n  nts	
zigzag
p		if(pfnorm
			eges n	a>	d		re fcrossraypges nfog	pa&maxsc1,;&maxsc2, NULL)				breaknntf(stderr, "***nc1=%g sc2=%galue maxsc1,;maxsc2)			 *check t{ue = nntf(stderr, "* "(rayptEMS][Mcross));
			exi			}) {	s(sn  ntsgh; om = g

	/=0.5[nr]  nnvs].newg	}

		GEF_FLOAT)ge, (*no th		(* n	priynd of curve3 !=a notge
	fa					vs (ge->>e {
		b
 s ny > extrec
 s ny > 2
	  d[g- ny >e {
		n ny >e [g-d{
		n ny >e2[g-(c + d)		a .{
		n ny >e1[g-eb +a .				 + d)		a4.{
		 ny >e [g-(a + b			3. + c			3. + d)		a8.{
		 ny >e2[g-(a +  .			b +ac)		a4.{
		 ny >e1[g-(a + b)		a .{

	fa					vs (ge->>y {
		b
 s ny >yextrec
 s ny >y2
	  d[g- ny >y {
		n ny >y [g-d{
		n ny >y2[g-(c + d)		a .{
		n ny >y1[g-eb +a .				 + d)		a4.{
		 ny >y [g-(a + b			3. + c			3. + d)		a8.{
		 ny >y2[g-(a +  .			b +ac)		a4.{
		 ny >y1[g-(a + b)		a .{

	faddge     up fon n	pr ==theturn;
FCONCISE)sg>1 ? dumpid= mighap fon n	pr  utc('=abs(s)re-group YPH * ,i && prevw	vs,w);
t(g, "bu,
 italsmred b| oritcurv != ge-b toor a not 

 ir su	pan ix2
	floatorizonnt)
			stgP; rn prevbesrray.
 *
)re-roupges array.
 */

) * array.
 *xhs[g->ms int")->ix		= vs[g

		sg>1 ?3 > tURPRISE! 
			  at covsour	w; 1 ?x ge->prev->ix3;sethex )
			o the 			m);
			f PAINlrp+1; i>nvsour	w; hb=)
	---|  t at covsour	        lby valu	ed 

		 up YP_MOVEshort  up YP_PATH,	---|  t atm, s,  italu	ed  < ge->have only covsour,ee {
	")->ix	 ovalueio>prev
			stg			else[g-		vs (ge->

		 						vs[g*(rray.
 **)-		vs (ge->->ix)sint(g, "bug, "bu		exi				y3;
			vs (ge->

		g, "busint(g, "bug, "bu		else[g-		vs "bug, "buect the  ny  "bug, "bu->

		 	 		vs (ge->

		; the  ny  "bug, "bu->->ix		 		vs (ge->->ix3;seg		}
		xtisint(g, "bug, "bu		exi)re->ns[g

		s; )re->ns[g "bue; )re->ns			exi
		}
	}xg /* reset ed  |  t at prertsoovale		  at covsour	w; 	->nsg=0; 			btypGEF_FLOAT)ct the		vs (ge->>e sinx ny >e {
					vs (ge->>y sinx ny >y {
		check t{ue = ny  (ge->ie sinx ny ie {
					vs (ge->iy sinx ny 		else }
rery.
	 * O ny >/* just to be ssg>1 ?3 > tUevs].fr at covsour	w; 1 ?x ge->prev>/* ->

		; thed  |  t at prertsoovale		  at covsour	w; 	->nsg=0; 			btypGEF_FLOAT)ct thex ny >e e->prev->ixy >e {
			x ny >y e->prev->ixy >y {
		check t{ue =x ny ie e->prev->ixy ie {
			x ny iy e->prev->ixy 		else }
re

			vs (ge-> "busint(g, "bu;
  ny  "bug,

		 	 		vs (ge;
  ny ->ixy >rix		 		vs > vs[	prev>/* ->->ix		 		vs->ix3;
	xtisint(g, "bu i+tre->ns			e
		}
	}xg /*=abs(s) {
		LLY
t nex
				g( ge-b toa not s      an it lo(MOVE

 i to ge-b toa not 
->entries;s>have only YP_MOVE j<noeces id b	egp[i]+=rexpand;
addge     u array.
 *op fo3 >      e,ir[nr] rray.
 *nnvsi++) {
			e,ir[nr]) * a>nsod of curve= YP_MOVEsg>1 ?3 >) {
			bet tw <= hbw; 	->nso ny  "bug, curve= YP_PATH)ct the) {

			/rizo PAINrray.
 ; i */
			else   y >rix		 nnt")->ix	].nor{
		check t{ue =   y >rix		 ot(g, "bu i+ =   y ->ix	].o ny  "bug,->ix3;sego ny  "bug,->ixy >rix		 nnt3;sego ny  "bug,->ix	].nor{
		c
	check t{ue    y >rix		 ot(g, > vs[	=   y ->ix	].o ns[	=oprev>/* ->->ix		 n ns[	=oprev>/* 		 n ns[	e

	n ny  "bu		 ot(g, "bu i+n		vs (ge	].o ns[	o ny  "bug,

		 	 n ns[	o ny  "bu 	 n ns[
[g-		g)m
>/* ->

		of curve= YP_MOVEsg>1 ?3 >fix ur[fficYP_MOVE 
				gw; 	->nsng=0; 			btypGEF_FLOAT)ct the	g)m
>/* ->

		of>hs[g-n ny >e {
				g)m
>/* ->

		of>ys[g-n ny >
					check t{ue =   y >rixy  (ge->ie sinnvs++;
			} e   y >rixy  (ge->iys[g-n ny 		else }
re
grp]; i--)[nr].lowalup YPH * shappers them\nairs,
	int 		 id= - 						fix have only MOVETO acntrD< mlb	egtituteds ix2
	vale				float	egp[i]+=rexpand;
)ix].fid= ( array.
 */

) * array.
 *m ns[
[m ge->prev>/* ->

		; t>nsmd of curve= YP_MOVEsg>1 ?>nsg=0; 			btypGEF_FLOAT)ct them ny >e e->prev>e {
			m ny >y e->prev>
					check t{ue =m ny ie e->previe {
			m ny iy e->prev		else }
re
grp]; i--Tlup fun
			f=adoreds>haverg-1]		 id=  (stemidrt{
rom..tin[up NOT
ch|
	 d 
->ein[ce->fr
	ifn ecified gap;

	/* fn ecified oxir[(0 - X, j!-;Y)),
 iGap;lse  u]=r[i; is */
			f=(].f_of_in[-URPRISE! 
_of_
rom)),
 iR&& prev

	howprE /*i+rexap;m);
sho*>loZOd[(0.0				} em);
fu i, >loZOd)),
 iR&& covsr(;)v

	howprE /*i+re

			/rizo* stNoovalueof([
rom..tin]

 irert -|    chemr< max tm,; i>nvses ence=	if (ge-g-1]		 stemid= ),
 iIfi &&==NULLee {
	alup infogALLsho*
		}
	 d	  gp[i]+=rexpdou ny
ncloZOgapu array.
 *
rom, array.
 *toin the oxirin dou ny;gap,y dou ny;*hot
) * #,efpre TIMESLARGER 10.	grp;
wprevwdtimds larg>frmred b|   om = g	ifsho*>h|
	 *gd<prE /*MS))dou ny;rm	2r %ddou ny;oldpos	2r %ddou ny;timds,rt mibrsdf, dx;n the j, k; array.
 *xhs   pM          bge	2r %ue)
	---eries;			f lx	 ovalueio>>alc handlr)[%d,%doldpos	0]
 s;
			  (ge->> ovalu
oxir		2r %doldpos	1]
 sto->> ovalu
oxir		2r %	e
m	0]
 s
m	1]
 s ap;	a .  %	ebge	0]
 s;
		;*/
			ALLlse  nvenie0; ge =i w=st;


	d,%dbge	1]
 stoTRY         *	

		ifmodify larg>acharactpthe			hpairs,neee {
	settl!=iy2+sm s,  it'elsetimds g-(TIMESLARGER-1e; timds > 0.1; timds /al2. nvs = 0 {
hm	0]+
m	1]
 rev.ty3;
RP-1];e
	f/		i w=st+1; iix2
	s */
			fs,rbackwardsee {
	t twardse lin< NSTEoup */jU2))->nsg>1else[g-
m	j]
 rev.t /		im gh*/
, */
			f=ALLexharededob=s[i].>nvs].from>	d	t mibe sfnt)s
m	j],	/*(1.+timds	pr ==  NSTxtisinbge	j]->c			e 		gx;

	asbge	! 		gx;

inx ny c			e 	sg>1 ? edxsinx ny > ovalu
oxir		2r[-Ux		vs (ge->> ovalu
oxir		2r %d	nvdf
 sfnt)sdx)[-Ut mib %d	nv	re df
<= FEPS		lb=som = gALLgd<psm s, io>>h|
	 *e->pre	-			if (nge == 0	re df
> sfnt)s
m	j],	d	exi sdf
 s
m	j] %d	nveck t	exi sdf
*agfgin)s
m	j],- 			min < gce->fr
	lse/drt{		 rm  italu		
m	j]
-=;d+si[	d	t mibe sfnt)s
m	j],	/*(1.+timds	pr == ethex )of curve for a not smlb=sotries; ient nalt ovalue;
	lu		ddou ny;s>al

in(sdx+df)]/ dx)[-U1.;	lu		ddou ny;basnge == 0ethejd	exi sibasnsinx ny > ovalu
oxir		2r;	lu		d3;
					vs[basnsinx ny  (ge->> ovalu
oxir		2r %				vs NSTkoup */kU2))k safe, e		x ny > ovalu
oxir		k]o+ags>al

*t	exi s		(x ny > ovalu
oxir		k]o-;basn		if(pre%ue = /
	 |  t*/
		elsient medist+1each  b=s[i].y=1j			break;df
 s-d+so3 > b iluynes */
			f=b=s[i].hp nsinbge	1]ev->ix3;seg-->nvs].xprev->ix3;see->ix3 != ge->prx ny > ovalu
oxir		2r[+=;d+si[	d	hp nsinbge	0r %d)\(w>nvs].xprev > vs[	= s}>pre	=pairto )
! fpo the == 0ethend of curve for a not smooth
	ynd of> ovalu
oxir		irs+=d+si[	d	hynd of> ovalu
oxir		1rs+=d+si[	d	h}
	d	hynd of> ovalu
oxir		2r[+=;d+si[	d	hthend of "bu !g-n ny >rix)smlb=s* stN
				ge->>nvsour	w; hb=s[		g)m
>/* ->

		of> ovalu
oxir		2r[+=;d+si[	d	h}%d)\(w>nvs].n ny c			e!j] %d	nvs[g->nvs]-
m	j]
 rev.t%d)\(wRP-1];e	
				}) {
			ed hints at e directce%d,%doldpos	0]
- s;
			  (ge->> ovalu
oxir		2r %doldpos	1]
- sto->> ovalu
oxir		2r %	e {
hossg>1 ?hos	0]
 soldpos	0]
-s;
			  (ge->> ovalu
oxir		2r %d?hos	1]
 soldpos	1r -Tto->> ovalu
oxir		2r %{
		#im 0	e {
 hm	0]+
m	1]
! s ap;-soldpos	1r +soldpos	0]
	}

	/* find err, "**** s ap=%g hm	0]=%g hm	1]=%g o	0]=%g o	1]=%g rg=%g og=%galue
				ap, hm	0], hm	1],soldpos	0],soldpos	1r, hm	0]+
m	1][g
			 ap;-soldpos	1r +soldpos	0]
 %{
	#eSD<fge-rottershm	0]+
m	1];
#un,efsTIMESLARGER*=abs(s---|  t at each  or charactsm s,es; rLequ	l			c/* fnizert mibegp[i]+=rexpand;
)dx3 m s,id = gssent,y dou ny;mx lenf (s[0YPH * g
EM            h, *xhs    "bu i+valel, k; adou ny;dx, dy, d2, d2m;y dou ny;mx len2; #,efpre TIMESLARGER 10.	grp;
wprE /*larg>frmred b|   om = g	ifsho*>h|
	 *gd<prE /*MS)
[mx len2 =;mx len*mx len;	int totals, grp, lastgrp;

	assertisinbe ssg>1 ? "busint(g, "bu;

tems int");

	g! for a not  ge->ix;

	g! for  ge->
e	-			if (nge ==d2m  s,
	  elseSD int");

	.flags =fr? 0: 2)j<nr3)) {
		fprindxsinprev>ene		--s ny  (ge->sx3;e	
	dye->prev>
ne		--s ny  (ge->s	else id2 =;dx*dxs+ dy*dy;else[g-d2m < d2t%d)\(d2m  sd2/* reset 	re d2->iymx len2 )smlb=s*rp+1;LLsho*gd<psm s,  valu	ed XXXe ovam tw <orm
				/* i,	ert VP]);relevant bo reset ed im gh; *rp+1;LLgd<psm s,  va
se_UP;
					elwardse			wet		if( luge;
	 equence=s[ix tm,nr]  nnvs]. ns[	= NSTxtisinprev > vsgx;

	as nsgx;

inx ny >rix)sm
	==d2m  s,
	   elseSD ixnt");

	.flags =fr? 0: 2)j<nr3)) {
		fprinedxsinx ny >ene		--sx ny  (ge->sx3;e	
		dye->xprev>
ne		--sx ny  (ge->s	else iid2 =;dx*dxs+ dy*dy;elsee[g-d2m < d2t%d)\((d2m  sd2/* rs}>pre	re d2->iymx len2 )sb=s*rp+1;LLsho*gd<psm s,  valu	wRP-1];e	
	>nvs].xpr;else[g- "busi fno thed  |  t at  "busedep*hpair
	lse equence=( vs[g->"bu 	 n"bug, "bu		ex}a
se_UP;
				backwardse			wet		if( luge;
	 equence=s[ix tm,nr]  pnvs]. ns[	= NSTxtisinprev->ix3gx;

	as nsgx;

inx ny ->ix)sm
	==d2m  s,
	   elseSD ixnt");

	.flags =fr? 0: 2)j<nr3)) {
		fprinedxsinx ny >ene		--sx ny  (ge->sx3;e	
		dye->xprev>
ne		--sx ny  (ge->s	else iid2 =;dx*dxs+ dy*dy;elsee[g-d2m < d2t%d)\((d2m  sd2/* rs}>pre	re d2->iymx len2 )sb=s*rp+1;LLsho*gd<psm s,  valu	wRP-1];e	
	pnvs].xpr;els;

					10, wet		if( leequence=s[i]m s, fragmealue; i ge...>nvs(e = gsive)  va
setheturn;
FCONCISE)sg			fprintf(stderr, "*** path
		 ue)
->fyi]m s, fragmealu(%x..%x..%x)alue 
			 		h-2) )origin) 
			cop != origin) 
			co n= origin) 
			con n	pr	 +dumpid= mighapp fon n	pr  ut
b=)
	--duceluge;
	 equence=	if,nee/drt{rizo---eries;			fmidted  ovalgw; 	->nsp	rv! fno the
re	=pairt1		fprinexg {
	.orev > vs[	= sthex )
			no the == 0ep ny >h1{
	.orev e2[g-p ny >hs; == 0ep ny >hs[g-n ny >e {
					p ny >y1{
	.orev y2[g-p ny >y {
					p ny >ys[g-n ny >
								p ny  curve3 !=a notge					)re-roupgesn n	pr	 +=hRP-1];e	
	g->nhs].fex )
			no y ->ix)sm
	==0ep ny >h1{
	.orev e2[g-(p ny >hs+x ny >e )/2.; == 0ep ny >hs[g-n ny >e {
					p ny >y1{
	.orev y2[g-(p ny >ys+x ny >y )/2.; == 0ep ny >ys[g-n ny >
								p ny  curve3 !=a notge					)re-roupgesn n	pr	 +=h)re-roupgesx n	pr	 +=hRP-1];e	
	g->nhs])re-roupgesp n	aipnvs].xpr;elsnexg {
	no y ->ix; )re-roupgesn n	p >nvs].xpr;else			}) {	g {
	.or{

se_UP;
				im gh; uge;
	 equence=ispsm s,  valudxsinprev>e3--s ny  (ge->sx3;e	
dye->prev>
3--s ny  (ge->s	else d2 =;dx*dxs+ dy*dy;eet 	re d2>iymx len2 )smlb=sno,	} elsesho* valu	dou ny;b, vs[g->nhint for3=nntf(stderr, "* " path
		 ued( leequence=s[ifragmealue< %s[ ovaluenhs,,	--duced=	if,neeom = alue
				 		h-2) )mx len	pr == )
		r(j=si[i]-wt e dfsho*>P-1tf( lmonstrosityi]paSE! 
	qu	drl lm			else[g-fgin)s ny >s1+-s ny  (ge->sx1,	/*fgin)s ny >s3+-s ny sx1)rrayelse||*fgin)s ny >>1+-s ny  (ge->sy1,	/*fgin)s ny >>3v-s ny sy1)rray the ue = /
	yds,rwt e d;e{ ei]x2
	 thes;om gh*/
gh* 
	bigough mem?  valu	wdxsinprev>e1+-s ny  (ge->sx3;e	
		dye-> ny >>1+-s ny  (ge->syelse iid2 =;dx*dxs+ dy*dy;ealu	wdxsinprev>e3+-s ny sx1;e	
		dye-> ny >>3v-s ny sy1lse iid2m =;dx*dxs+ dy*dy;ealu	w[g-d2>iymx len2  ) ]2->iymx len2)smlb=sse {
 wobstraightue;
	lu		d>nvs].newg	}

		GEF_FLOAT)ge, e		*>nvs].*or{
				hr	 +=h)>= SDBG(SU2)) {
		fprin	iyv=0;  ovalu
			2]
 sv=0;  ovalu
			0r %d)\(wdb[g-n ny > ovalu
			0r %d)\(wdd[g-n ny > ovalu
			2r[-Ubsi[	d	hynd of> ovalu
			0]
 sb +a0.1*dsi[	d	hynd of> ovalu
			1]
 sb +a0.9*dsi[	d	h}e	
	g->nhs])lseSDBG(SU2)) {
		f ) {se {
,neestraight; rL     *oritw )straightue;
	lu		db
 s ny  (ge->> ovalu
			2r %d)\(wd
 sv=0;  ovalu
			2r[-Ubsi[	d	hd of> ovalu
			0]
 sb +a0.1*dsi[	d	hd of> ovalu
			1]
 sb +a0.9*dsi[	d	}* rs}>preelevant b * reset 	reprev>/* 				o the 			 ovalueio>itself, ored ---|  t at id=          lby valu	hint for3=nntf(stderr, "* " path
		 ued( lid=  made=s[ifragmealue< %s[ ovaluenhs,,	---|   alue
				 		h-2) )mx len	pr == >"bu 	 )re-roupges n	a]);relevant bo re 

					10, cloZONE+rexap;byoxesntsby valu)>= SDBG(SU2)) {
		fprindou ny;gappr == xap; sv=0;  ovalu
			2r[-U ny  (ge->> ovalu
			2r %d)\	re fcloZOgapup fog	pairs	ap, NULL)	prev.0				breakdou ny;s>al
,;basnge == 0,
	sho*gooe e ;
			fs at resorteored s>al

;
	r "bug past;
	lu		xap; sv=0;  ovalu
			2r[-U ny  (ge->> ovalu
			2r %alu	w[g-turn;
FCONCISE)sgr	 +=h)ntf(stderr, "* "	STfs at resorte i,%c: cloZ* 
	 "bugbyo%galue
					 SD=0 ? 'x' : 'y')rs	ap)pge->iynd 		 		vs > vs[		s[basnsinn ny > ovalu
			2r;alu	wdxsinprev> ovalu
			2r[-Ubasngelu	w[g-fnt)sdx)[< FEPS

								if (nge == 0s>al

in(sdx-	ap)]/ dx)				hs[g-		g)m
			Wve for a not r	 +=h)>= koup */kU2))k safe, e		n ny > ovalu
			k]
 sbasns+t	exi s		s>al

*tsn ny > ovalu
			k]o-;basn		i
n	iyv=0;  ovalu
			2]
-=;gappr	se			}) 
					OK,NE+rexap;lse loZOd[- ---|  t alseuselesp YPH * s valu)re-roupges n	a])}
#un,efsTIMESLARGER*=abs(shints at  ovalgw	ert iw )raypt			if (* 
	vectorsMcrossvpri && prev1 0;

				cross, 0 0;

				EMS][,
 iIfi
				cross op/* in i, (im gh;  ovalt s atw <ot NULL)	 && prev
							maxim gro>al
s=iy2+]x2
	vectorsMsnts sso op/* in i,  at  ovalg

 ir	ert i, jraypt	ross (twice)),
 iExpes;s>hai]-1; jcharactatw <orm
			 d	  g,
 iFore  nvenie0 (ge->e  else2{
ront-int fun
			fs>hakx;

  i++gumealue; ie directiovaluatgP; rn prructjray		brdou ny;x1h y1h x2h y2si[AX_Sisntin;y dou ny;k,;b[sb=s*rp+ctatw re (gse]=r[i ;
ye->k*x + b		S))dou ny;*maxppr};i]+=rexpprructjray	ray[3r %a/						back-int do< max t actu	l	r su
							raypter j,efpreeint Blue +=rexpa /* hray[]P; rn prevbest;
}fcrossraypxx(y dou ny;crossdot	2]	2ru (s[0dou ny;xh y,;maxsi[AX_Si;	int t SDBG(SU2)) {
		fpri {
hay[i].h1{
= hay[i].h2sgr	 +hay[i].isntine->1lse x3 != ge->hay[i].isntine->,
	   hay[i].koup
hay[i].>nv-shay[i].>_fi, 
hay[i].hnv-shay[i].x1)egi  hay[i].b
 shay[i].>nv-shay[i].kpri ay[i].hnpr  utevbes 0
hay[0].isntines gray[1].isntin		fpri {
turn;
FCONCISE)sg)ntf(stderr, "* "crossrayp:+]x2
	ve	int n);
			ex
		} elsesb=s]x2
	ve	int n,tEMS][Mcross 	S))vbes 0
hay[1].isntin		fprihay[2]
 shay[0]esb=sex>h|
	 *g tm,nr]  hay[0]
 shay[1r %d)hay[1r
 shay[2r %{
		s 0
hay[0].isntin		fprix
 shay[0].x1;e	>ix3 != ge-	re fnt)s
ay[0].kv-shay[1].k) < FEPS
			fpr {
turn;
FCONCISE)sg)ntf(stderr, "* "crossrayp:+ glyllee sames, koup%g,o%galue
				
ay[0].k,shay[1].k)egi  h		} elsesb=s glyllee sames[nr]  utcix
 s
hay[1].bv-shay[0].bfi, 
hay[0].kv-shay[1].k)  %{
		y
 shay[1r.kprix + hay[1].b;	int t SDBG(SU2)) {
		fpri {
hay[i].isntin	gi  rior s
yv-shay[i].>_fi, 
hay[i].>nv-shay[i].>_flse x3 !gi  rior s
xv-shay[i].x1)i, 
hay[i].hnv-shay[i].x1)egi _UP;
				im wrong o=%ds;om raypt	ross w; 	->ns	riorray the	fpr {
turn;
FCONCISE)sg)ntf(stderr, "* "crossrayp:+%cro>al
=%g @(%g,%g) (%g,%g)<-(%g,%g)alue
				(i?'Y':'X')rsrio,;xh y,;hay[i].hn,shay[i].>n,;hay[i].h1,shay[i].>_flse rbetters,
	  gpri {
hay[i].maxp	gi  *hay[i].maxp =;maxsi[}	s 0
crossdot	prevthe	fpcrossdot	0		0]
 scrossdot	1		0]
 sxsi[pcrossdot	0		1]
 scrossdot	1		1]
 sysi[}	s
		}
	}

	=abs(si+re
ront-int get=x;
	=y) { gumealuege;

4tEMtsj,efprx;

  i+som = gAt Blue Zonevaluati ;
iy2+fapproxom = ():
pri aypter j,efpreei ;
{
					hs[gndUevs].fr at cm = ,
							crossdot	up in{
		eei ;
				iw )midted EMtsj.fr at cm = P; rn t;
}fcrossraypcv(y dou ny;cm = [4]	2sb=X,Y*/],))dou ny;*max1,))dou ny;*max2u (s[0hay[0].x1
 scm = [0		Xr %{hay[0].y1
 scm = [0		Yr %{hay[0].e2[g-cm = [1		Xr %{hay[0].y2[g-cm = [1		Yr %{hay[0].maxp =;max1pge-ray[1].x1
 scm = [2		Xr %{hay[1].y1
 scm = [2		Yr %{hay[1].e2[g-cm = [3		Xr %{hay[1].y2[g-cm = [3		Yr %{hay[1].maxp =;max2pge-rottersfcrossraypxx(&cm = [1	)
	=abs(si+re
ront-int get=x;
	=y) { gumealuege;

g, lastg:
pri aypter j,efpreei ;
{
					hs[.from = 1[gndUevs].from = g2P; rn t;
}fcrossraypges array.
 */
1, array.
 */
2,))dou ny;*max1,))dou ny;*max2,y dou ny;crossdot	2]	2ru (s[0hay[0].x1
 s/
1y  (ge->sx3;e	hay[0].y1
 s/
1y  (ge->sy3 %{hay[0].e2[g-/
1y   ovalu
X][/
1y  tgr %{hay[0].y2[g-/
1y   ovalu
Y][/
1y  tgr %{hay[0].maxp =;max1pge-ray[1].x1
 s/
2->sx3;e	hay[1].y1
 s/
2->sy3 %{	repr2->rtgrray		fprihay[1].e2[g-/
2y  (ge->sx3;e	
hay[1].y2[g-/
2y  (ge->sy3 %{>ix3 != ge-hay[1].e2[g-/
2y   ovalu
X][/
2->rtg];e	
hay[1].y2[g-/
2y   ovalu
Y][/
2->rtg];e	}%{hay[1].maxp =;max2pge-rottersfcrossraypxx(crossdot)
	=abs(si    gx;
 ntf(sout fun
			fs> rn #im ,efpree(DEBUG_DOTSEG)s|| ,efpree(DEBUG_DOTa not s|| ,efpree(DEBUG_APPROXCV)abs(shsubi    gx;
> rnprevbe
ntf(sdot(y dou ny;dot	2]u (s[0nntf(stderr, "* "(%g,%g)", dot	0	, dot	1	)
	=abprevbe
ntf(sseg(y dou ny;seg	2]	2ru (s[0putc('[', err, "flsentf(sdot(seg	0]
 %{putc(' ', err, "flsentf(sdot(seg	1]
 %{putc(']', err, "fls
		#eSD<fsb=sDEBUG_*; rn ]; i iFstem quelst dipre0 (gge;

a dotg toa  pastsegmealP; rn dou ny
nEMtsegdipr2(y dou ny;seg	2]	2sb=X,Y*/],))dou ny;dot	2sb=X,Y*/]
) * #,efpre x1	seg	0]
X] #,efpre y1	seg	0]
Y] #,efpre x2	seg	1]
X] #,efpre y2	seg	1]
Y] #,efpre xdot	dot	X] #,efpre ydot	dot	Y]  adou ny;dx, dy[g->n;egmeal dimeas;


	d,%ddou ny;ksame,obsame[g->n;egmeal y3 !=iy2uus 	up y=k*x+b		S))dou ny;kperp,obperpesb=s erpeSD<c har*ge;

 at eotg togh; *rp+1	S))dou ny;xcross, ycross- 			m	ert i, j erpeSD<c har*crosses		elseegmeal  rn ];titutedc/* fnitu	/* i,m	ert i, jrevbestsoovale		  at eegmeal up iluenndob=s#,efpre HANDLr  gMITS(lesp12airssscr1airssscr2)	\	e {
 lesp12 the \ 	->ns	rssscr1 the \ 	-	xcross
 sx1; \ 	-	ycross
 sy1; \ 	-ery.
	 * O !(rssscr2) the \ 	-	xcross
 sx2; \ 	-	ycross
 sy2; \ 	-er\%{>ix3 !=  \ 	->ns	!(rssscr1) the \ 	-	xcross
 sx1; \ 	-	ycross
 sy1; \ 	-ery.
	 * O rssscr2 the \ 	-	xcross
 sx2; \ 	-	ycross
 sy2; \ 	-er\%{>i\		ed evs].frmacro  rn 
edxsinxnv-sx1;e	dye->>nv-sy1TRY 	}
fnt)sdx)[< FEPS
g>1 ?3 >n ecial casns-* and the sameob=s#if,efsDEBUG_DOTSEG1 ?ntf(std" and the same!);
			#eSD<fg-	xcross
 sx1;
-	ycross
 syeot;
-	HANDLr  gMITS(sy1[< >n,;ycross
< y1h ycross
< y2);y initia 	}
fnt)sdy)[< FEPS
g>1 ?3 >n ecial casns-*al stems, ssameob=s#if,efsDEBUG_DOTSEG1 ?ntf(std"al stems, ssame!);
			#eSD<fg-	xcross
 sxeot;
-	ycross
 sy1;
-	HANDLr  gMITS(sx1[< hn,sxcross
< h1,sxcross
< h2t%d>ix3 != ge-ksame =;dy/dx;
-	bsame =;>1+-sx1*ksame;
-	kperp d hi./ksame;
-	bperp d yeot+-sxeot*kperp	i
n	xcross
 s(bsame-bperp)i, 
kperp-ksame);
-	ycross
 sksame*xcross
+obsame[

-	HANDLr  gMITS(sx1[< hn,sxcross
< h1,sxcross
< h2t%d>s#if,efsDEBUG_DOTSEG1 ntf(std"crosse->frati(%g,%g)alue;xcross, ycross			#eSD<fg
edxsinxeot-xcross;e	dye->>eot-ycross;e	rottersdx*dx+dy*dy;e#un,efsx1e#un,efsy1e#un,efsx2u#un,efsy2u#un,efsxeotu#un,efsyeotu#un,efsHANDLr  gMITS*=abs(shints at weighted	qu	drlrexpa->fag!=iy2+ at e pre0 (gof(  se[,
 iof(EMtsjge;

 at om = ;s sso fillsj. */y), ISD<vidu	l	e pre0 (svpriiy2+nhs,
eot;	im maxp!=NULLee {
	 && prevg->emaxim groquelstvprie pre0 (gAt BlureP; rn dou ny
nEMtom =dipr2(y dou ny;cm = [4]	2sb=X,Y*/ ],))prructjEMt_dipr *EMtsin the nEMtsilb=sntries; ge
			stg	; ieots		S))dou ny;*maxpu (s[0/*(  om = gALLYpproxim teei];t alserevwdstraight;eegmealsob=s#,efpre NAPSECT	16[0/*(  om = gALLD<vid 
			cot alserevwds/
			fst entrequ	l	weight+nhs,
b=s#,efpre NWSECT	4[0/*(ta ny;o->>nefficiealueg rL  SD< max d EMtsj.nsgh; om = g	S))/*(ts	0]
lseleft unusedob=s[]+=rexpdou ny(ts	NAPSECT][4];s[]+=rexpthe 		iftne->,
 ) {
lag:(ts	up initi
			 dg	S))/*(EMtsj.nsgh; om = g	S))dou ny;cvd	NAPSECT+1]	2sb=X,Y*/];))/*(sum)v

	s/
			fst	S))dou ny;sum[NWSECT];))/*(  u]=)v

	s/
			fst	S))dou ny;  u]=[NWSECT];))the dpairsjsi[AX_Sid1,sid2si[dou ny;dipr1,;dipr2,;dipr3,;dx, dy, xh ysi[dou ny;rior s,.;ave	}
!		iftn
g>1 ?dou ny(t, nt, r2,;nr2,;edep[

-			iftnom--;
edep*al1. / NAPSECT--;
ne->,
	  t t SD j<nrNAPSECT-) {
		fprinto+agsdep[
e		nne->1 -Tt[
e		t2[g-t*u i+ = t2[g-nt*nt[
e		tt
			0]
 s t2*nt[ ) {(1-t)^3 ;
	lu	tt
			1]
 s3* t2*t[ ) {3*(1-t)^2*t ;
	lu	tt
			2]
 s3* t*t2[ ) {3*(1-t)*t^2 ;
	lu	tt
			3]
 st2*t[ ) {t^3 ;
	luutevbest t SDBG(SUNWSECT-) {
		fprisum[		-=g0.; ==  u]=[		-=g0; {
			ed n  ntsgh; om = g		coteegmealsob=sst t dDBG(dU2))d{
		f ) {X[gndU s valucvd	0]
d]
 scm = [0		d]esb=send ovalue;
	lucvd	NAPSECT]
d]
 scm = [3		d]e	  t t SD j<nrNAPSECT-) {
		fprincvd	i]
d]
 scm = [0		d] *(ts				0r>pre	+-cm = [1		d] *(ts				1r>pre	+-cm = [2		d] *(ts				2r>pre	+-cm = [3		d] *(ts				3];	luutevbest t dDBG(dUnEMts))d{
		fs#if,efsDEBUG_DOTa not ==ntf(std"eot+%dgp[gd	aiptf(sdot(EMts	d].p	aiptf(std":);
			1 ?3 >hsubi    gx;
> rnlu)>= SDBG(SU NAPSECT-) {
		fprindipr1 	 )EMtsegdipr2(&cvd	i], dots	d].p	aprinptf(std" teeg+%dgp[i	aiptf(sseg(&cvd	i]	aiptf(std";dipr=%galue sqrt(dipr1)	pr  ut#eSD<fg
eix
 sdots	d].p	Xr %{	y
 sdots	d].p	Y]		1 ?3 >hints at revbestseot+.nsgh; om = 
} 					ert  < ge->ur[fo 2 lothe minif (n -Ts{
			prertsge;

 at
} 			->nvs.from = ggndUgo[j].low ce]=rr
= GE_C 	->d1e->,
	  dxsinx -Tcvd	0]
Xr %{	dye->> -Tcvd	0]
Yr %{	dipr1 	 dx*dxs+ dy*dy;e#if,efsDEBUG_DOTa not ==ntf(std" seot+0
p		iptf(sdot(cvd	id1]	aiptf(std";dipr=%galue sqrt(dipr1)	pr#eSD<fg-	)>= Se->1l(SU=NAPSECT-) {
		fprindxsinx -Tcvd	i]
Xr %{		dye->> -Tcvd	i]
Yr %{		dipr3 	 dx*dxs+ dy*dy;e#if,efsDEBUG_DOTa not ===ntf(std" seot+%dgp[i	aiptf(sdot(cvd	i]	aiptf(std";dipr=%galue sqrt(dipr3)	pr#eSD<fg-	w[g-dipr3 <;dipr1sg>1 ? edipr1 	 dipr3gelu	w[d1e->		if(wge->frwd;
hRP-1];e	
eset 	re[d1eU NAPSECT-1sg>1 ? id2 =;NAPSECT--;
ndxsinx -Tcvd	NAPSECT]
Xr %{		dye->> -Tcvd	NAPSECT]
Yr %{		dipr2 =;dx*dxs+ dy*dy;e#if,efsDEBUG_DOTa not ===ntf(std" s+eot+%dgp[gid2		iptf(sdot(cvd	id2]	aiptf(std";dipr=%galue sqrt(dipr2)	pr#eSD<fg-	w)>= Se->NAPSECT-1-) >[d1; j<n--		fprinedxsinx -Tcvd	i]
Xr %{			dye->> -Tcvd	i]
Yr %{			dipr3 	 dx*dxs+ dy*dy;e#if,efsDEBUG_DOTa not ====ntf(std" seot+%dgp[i	aiptf(sdot(cvd	i]	aiptf(std";dipr=%galue sqrt(dipr3)	pr#eSD<fg-	ww[g-dipr3 <;dipr2			break;dipr2 =;dipr3gelu	w id2 =;		if(wdge->frwd;
hwRP-1];e	
			
						10, hintsw	is,
		  at lothe minif (n ictsm s,es;		else[g-dipr2 <;dipr1sg>1 ? e[d1e->	d2/* rs}>pr) 
					 at revbestseegmeal mred e = gdes at revbestseot+w; 	->ns[d1{
			fprindots	d].eeg+->,
	   dots	d].dipr2 =;)EMtsegdipr2(&cvd	0], dots	d].p	apriinitia 	}
[d1{
NAPSECT		fprindots	d].eeg+->NAPSECT-1-	   dots	d].dipr2 =;)EMtsegdipr2(&cvd	NAPSECT-1], dots	d].p	apriinitia fprindipr1 	 )EMtsegdipr2(&cvd	id1], dots	d].p	apri	dipr2 =;)EMtsegdipr2(&cvd	id1-1], dots	d].p	aprie[g-dipr2 <;dipr1sg>1 ? edots	d].eeg+->id1-1;1 ? edots	d].dipr2 =;dipr2	if(wge->frg>1 ? edots	d].eeg+->id1;1 ? edots	d].dipr2 =;dipr1/* rs}>pr) 
		i
 sdots	d].eeg+% NWSECT;prisum[		-+ sdots	d].dipr2	if([g-dots	d].dipr2 >ps=xty3;
rior sdots	d].dipr2	if(  u]=[		om--#if,efsDEBUG_DOTa not ==ntf(std" bestseeg+%dgs/
	+%dgdipr=%galue dots	d].eegpairssqrt(dots	d].dipr2)	pr#eSD<fg-
			ed >alc handl at weighted	a->fag!= rn  d1{,
	 dipr1=0.; =t t SDBG(SUNWSECT-) {
		fpri 0
c u]=[		{
		
	;relevant bo r[d1;+ %{	dipr1 +agsum[		/c u]=[		si[}	s 0
maxp	gi *maxp =;maxsi[>ns[d1{
			
	ss, EMtsilstra
	 *e->prbetters,.; =eck t	exrottersdipr1/id1; ) {to{gt egp[Na->fag!=e pre0 (gYpplyssqrt()  va}	s ]; i iApproxim te(  om = gm tch< max d g<ving oe1]		 is; gvs]ntswi= - 		midted reirectce%is; gvsgo< masi[Smax d g<v{
	segmealso(]ntss, fert	er
					ansgh;st eegmeals).P; rn s=malfapproxom = ())dou ny;cv[4]	2sb=X,Y*/ ], 			 ovalue0-3s]lsep/
	s
			,	 ovalue1,nv-s. */b=s[]+ructjEMt_dipr *EMtsi 			 at EMtsj toapproxim te(-	e pre0 (s*
		}
	 dt	ex				ert  < ge->inualidob=s[the nEMtsu (s[0/*(b snts[-else			fmidted 			irolt ovalue;
	#,efpre	B	0	#,efpre	C	1
	ed  <xim grntries; ges/
			fstan nhs,
oxir[- usedoiy2+ at      *edep*b=s#,efpre MAXSECT	2
	ed ntries; ges/
			fstusedoiy2+ at  it loedepsob=s#,efpre NORMSECT 2
	ed w {
	aleoedepsobecin 3lesp 		ansghlserevwdoovaluai} 'sttimdj tostop*b=s#,efpre STEPEPS	1.))dou ny;ge;
	2sb=B,C*/],j t	2sb=B,C*/]si[dou ny;ridtf	2sb=B,C*/]	2sb=X,Y*/],;d+si[dou ny;  ef	2sb=B,C*/]	MAXSECT]b * dou ny;res	MAXSECT]	MAXSECT],sghlshor, besthor, gooehorsi[AX_Sn  ef	2sb=B,C*/], best	2sb=B,C*/], gooe	2sb=B,C*/]si[valel, j, k,,keersym;y 
ntalbc[]="BC";y 
ntalxy[]="XY";
-#if,efsDEBUG_APPROXCV[0nntf(stderr, "* "Cm = goovalu:g; i+t t SDBG(SU4-) {
		fpri)ntf(stderr, "* "	
			exptf(sdot(cv	i]	aii[}	snntf(stderr, "***nsDolu:g; i+t t SDBG(SUnEMts)) {
		fpri)ntf(stderr, "* "	
			exptf(sdot(dots	i].p	aii[}	snntf(stderr, "***ns"			#eSD<fg
eb=s*oadrs,
	intis; gvs]nts>alc handle directcesob=sst t SDBG(SU2)) {
		fpried i ictX,U s valuridtf	B][		-=gcv	1][		-cv	0][		si[uridtf	C][		-=gcv	2][		-cv	3][		sipried i ictB, Cs valu)rom[		-=g0.; == t			-=g1.;	lun  ef			-=gMAXSECT; {
			=pairto  ef	B]
! s1s|| o  ef	C]
! s1		fpried prepelse			f_UP |s;o->>nefficiealue valu)>= SDBG(SU2)) {
		fsb=B,C*/-#if,efsDEBUG_APPROXCV[0ri)ntf(stderr, "* "Cnefficiealuebyo%c(%g,%g):ue bc[i], )rom[		,j t	i]	ar#eSD<fg-	wdf
 s( t	i]-)rom[		)i, 
n  ef			*2d %d)\n", EMGRP-1)  ef				g->nsg>1 ? e  ef			e fr=g)rom[		-+ df*(2*j+_fls#if,efsDEBUG_APPROXCV[0rii)ntf(stderr, "* "	%gue   ef			e f	ar#eSD<fg-	w}-#if,efsDEBUG_APPROXCV[0ri)ntf(stderr, "* ");
			#eSD<fg-	}>prbesthor  sFBIGVAL;y rbest	B]
= best	C	-=g0; {ied i i w=st+uebyoo  ef	B], j i w=st+uebyoo  ef	C]a.high >= SDBG(SU;  ef	B]-) {
		fprinn", EMGRP-1)  ef	C		g->nsg>1 ? e)>= k= */kU2))k sa	fsb=X,U e->pre	-	v	1][k	-=gcv	0		k]o+ ridtf	B][k]*  ef	B][		si[ue	-	v	2][k	-=gcv	3		k]o+ ridtf	C][k]*  ef	C][j] %d	nvs[				
es			e fr=gghlshor =;)EMtom =dipr2(cv, EMtsilnEMtsilNULL);g-	ww[g-ghlshor < besthor			break;gooehor
= besthorsi[eak;gooe	B]
= best	B]si[eak;gooe	C]
= best	C	si[eak;besthor  sghlshorsi[eak;best	B]
= isi[eak;best	C]
= j	if(wdge->fr [g-ghlshor < gooehor			break;gooehor
= ghlshorsi[eak;gooe	B]
= isi[eak;gooe	C]
= j	if(wdgs#if,efsDEBUG_APPROXCV[0rii)ntf(stderr, "* "	ati(%g,%g)gdipr=%g %salue   ef	B][		e   ef	C][j]rssqrt(ghlshor)e
					 best	B]==ies gbest	C]==j)? "(BEST)":""	ar#eSD<fg-	w}-wdgs#if,efsDEBUG_APPROXCV[0r)ntf(stderr, "* "	best:	ati(%g, %g)gdipr=%galue
			  ef	B][best	B]	e   ef	C][best	C]]rssqrt(besthor	);g-	)ntf(stderr, "* "	B:%d,%dgC:%d,%dg-- 2tembest:	ati(%g, %g)gdipr=%galue
			best	B], gooe	B], best	C], gooe	C]e   ef	B][gooe	B]	e   ef	C][gooe	C]]rssqrt(gooehor				#eSD<fg
ep	rebesthor <[(0.1*0.1) smlb=sotno=%d =i  cloZONugh mem
					ed >alc handl at col din   ue torottersE_C			elsek= */kU2))k sa	fsb=X,U e->pre		v	1][k	-=gcv	0		k]o+ ridtf	B][k]*  ef	B][best	B]	;>pre		v	2][k	-=gcv	3		k]o+ ridtf	C][k]*  ef	C][best	C]];g-	w}-#if,efsDEBUG_APPROXCV[0ri)ntf(stderr, "* "qui.lowpproxim teeimidted  ovaluep		iptf(sdot(cv	1]
 )e, enntf(stderr, "***ep		iptf(sdot(cv	2]	ai)ntf(stderr, "* ");
			#eSD<fg-	xrotter;	luute	keersym-=g0; {i	rebest	B]
! sbest	C]
s gbest	B]-best	C]
== gooe	C]-gooe	B]			breakeersym-=g1ls#if,efsDEBUG_APPROXCV[0ri)ntf(stderr, "* "keering oymmetry!);
			#eSD<fg-		mem >= SDBG(SU2)) {
		f ) B,C*/-	ww[g-)  ef			==1)1 ? e  evant bo rw[g-keersym			break			 

		ifkeer	aleoeymmetry b=s[i].y=1best	i] < gooe[		)i	break;)rom[		-=g  ef			ebest	i]	si[eak; t			-=g  ef			egooe[		]	if(wdge->fr 	break;)rom[		-=g  ef			egooe[		]	if(wd; t			-=g  ef			ebest	i]	si[eak}if(wge->frg>1 ? edf
 s( t	i]-)rom[		)i, )  ef				
eak;)rom[		-+=;d+*best	i]	
eak; t			-=g)rom[		-+ df/* rs}>pr-	re fnt)sd+*ridtf				0rd	< STEPEPS
s gfnt)sd+*ridtf				1rd	< STEPEPS			break			 	lse =%d ue)
  nvergedob=s[i].)rom[		-=g t			-=g()rom[		+ t	i]			a .{
		lun  ef			-=g1	if(wge->frg
		lun  ef			-=gNORMSECT;e	
eset}		ed >alc handl at col din   ue torottersE_C	elsek= */kU2))k sa	fsb=X,U e->pr	v	1][k	-=gcv	0		k]o+ ridtf	B][k]*)rom[B]si[e	v	2][k	-=gcv	3		k]o+ ridtf	C][k]*)rom[C	si[}	#if,efsDEBUG_APPROXCV[0nntf(stderr, "* "wpproxim teeimidted  ovaluep		iptf(sdot(cv	1]
 )e,nntf(stderr, "***ep		iptf(sdot(cv	2]	ai)ntf(stderr, "* ");
			#eSD<fg#un,efsBg#un,efsCg#un,efsMAXSECTg#un,efsNORMSECT
#un,efslTEPEPS
grp]; i--Fints at  quelst _UP |e		  at eantsj.fr at angny;betwe{
	ale
 d evs].frg 1[gndU				b
					hs[.frge2 i--Tl; om = gmred b| <orm
			 d	  gp[i]+=rexpdou ny
njovaluin2s array.
 */
1, array.
 */
2u (s[0dou ny;d	3		2sb=X,Y*/];))dou ny;s>al
1,;s>al
2airsn1airsn2si[AX_Soxirsi[%{	repr1->rtgrray		fprid	1]
X] g-/
1y  e3+-s n1y  (ge->sx3;e	
d	1]
Y] g-/
1y  y3+-s n1y  (ge->sy3 %{>ix3 != ge-d	1]
X] g-/
1y  e3+-s n1y   ovalu
X][/
1y rtg];e	
d	1]
Y] g-/
1y  y3+-s n1y   ovalu
Y][/
1y rtg];e	}%{d[2		Xr[g-/
2y   ovalu
X][/
2-> tgr+-s n2y  (ge->sx3;e	d[2		Yr[g-/
2y   ovalu
Y][/
2-> tgr+-s n2y  (ge->sy3 %
	rsn1[g-sqrt( d	1]
X]*d	1]
X] + d	1]
Y]*d	1]
Y] );g-len2 =;sqrt( d	2]
X]*d	2]
X] + d	2]
Y]*d	2]
Y] );g-ed n>al

;
	r2temeegmeal  togh; *engt,
		 1
	 							ifme {
sulse		i]-1; j1stseegmeal lselong>frn>al

ntsgo
 					e *engt,
		 2[gndUexte				ifBlue Zonee pre0 (gbackwards
	/b=s[]>al
1 al2./rsn1;s[]>al
2 ; j./rsn2;	int t oxir= */oxir[U2))oxir>nsg>1 ?d	0]
oxir	 d h( d	1]
oxir	 *ags>al
1 );g-	d[2		oxir	 *ags>al
2;i[}	s
		}
	})EMtsegdipr2(d, d	2]fls
		#im 0	3 >hints at elsagce->feei];t at cm = P;  (t mibeei];t at proj/
			fst	ifBlueX)oxir)  gp[i]+=rexpdou ny
ncvelsa( array.
 */

) * adou ny;Ly, My, Ny, Py, Qx, Rx, Sx;))dou ny;elsaTRY    ye->Ly*t^3 + My*t^2 + Ny*t + Py b=s[Lye->- ny  (ge->sye + 3*s ny >>1+-s ny sy2S +  ny >
				My
 s3* ny  (ge->sye - 6* ny >>1++s3* ny >y2
	 Ny
 s3*(- ny  (ge->sye +  ny sy1)
	 Pye-> ny  (ge->sy3 %
	/*(Ex/dne->Qx*t^2 + Rx*t + Sx b=s[Qx
 s3*(- ny  (ge->sxe + 3*s ny >e1+-s ny sx2) +  ny sx3)egiRx
 s6*( ny  (ge->sxe - 2* ny >e1++s ny sx2)egiSx
 s3*(- ny  (ge->sxe +  ny sx1) %
	/*(elsagup integral[
rom 0t	if1]( y(t,	/*dx(t,/dne*dt)  va	elsag; j./6.*(Ly*Qx) + j./5.*(Ly*Rx + My*Qx) 
e	+-j./4.*(Ly*Sx + My*Rx + Ny*Qx) + j./3.*(My*Sx + Ny*Rx + Py*Qx)
e	+-j./2.*(Ny*Sx + Py*Rx) + Py*Sx;)	s
		}
	}elsaTRut#eSD<fg
3 >hints at _UP |e		 oovale	nsgh; om = gi]-1; jg<v{
	 glymetes;	,
			si[Smax d g<v{
	oxir[(0 - X, j!-;Y)),
 p[i]+=rexpdou ny
ncv_UP( array.
 */
in the oxirin dou ny;t
) * adou ny;r2,;mt,;mt2 %
	/*(_UPg; A*(1-t)^3 + 3*B*(1-t)^2*t + 3*C*(1-t)*t^2 + D*t^3 ;
	lt2[g-t*u i+mne->1-u i+mn2 =;mt*mtsi[%{
		}
	} ny  (ge->> ovalu
oxir		2r*mt2*mt 
e	+-3*s ny > ovalu
oxir		ir*mt2*t +  ny s ovalu
oxir		1r*mt*t2)
e	+-d of> ovalu
oxir		2r*t*t2[
grp]; i--FintsnEMtsrequ	llyi]paced=EMtsj.ns  om = gorssameo				fillv
						ir col din   ue		cot at EMtsja /* 	egp[i]+=rexpand;
) ZopleEMts( array.
 */
i * dou ny;dots			2r e			 at EMtsj tofillvb=s[the nEMtsu (s[0valel, oxirsi[dou ny(t, nf,;dx, d	2r %alnf
 snEMts+extr	red of curve for a not smoott t SDBG(SUnEMts)) {
		fpri
ne->(i+1)/nf %d)\n", oxir= */oxirU2))oxir>ns1 ? edots	i]
oxir	 d ncv_UP(/
i oxiri t	pr  utc(ix3 !=  b=s*rp+1 valud	0]
 sprev>e3--s ny  (ge->sx3;e	
d	1]
 s rev>
3--s ny  (ge->s	else t t SDBG(SUnEMts)) {
		fpri
ne->(i+1)/nf %d)\n", oxir= */oxirU2))oxir>ns1 ? edots	i]
oxir	 d  ny  (ge->> ovalu
oxir		2rt	exi s+-t*d
oxir	pr  utc(
grp]; i--Allothte(  ]+ructulsegex_  n	egp[i]+=rexpand;
allot_gex_  n( array.
 */

) * a ny "bu 	 (and;*)callot(1,;s		 of(GEX_CON))xtr	red of"busi f0		fpri)ntf(st  err, "**** **mallotgfnileE
		 *rp+1% alue __FILE__e __ ge-__flse xxit(255	a])}
grp]; i--Norm
			 (  x
				gg rL g rce  ncise() :shints at  ovals>hai]
->enange->used=	if>alc handl at ta
	 als.	egp[i]+=rexpand;
)norm
			eges array.
 */

) * avalemids-2) )
ronts-2) )lsars-2);ave	}
d of curve for  ge->	fpri rev>tg+->2	if( revrtg+->-1;e	>ix3 != o3 > ssumei} 'sta om = g	S))	mids-2)-=g()nt)s ny >s1- ny sx2)<FEPS
s gfnt)s ny sy1- ny sy2S<FEPS);g-	)ronts-2)-=g()nt)s ny >s1- ny  (ge->sx3)<FEPS
s gfnt)s ny sy1- ny  (ge->sy3S<FEPS);g-	lsars-2)-=g()nt)s ny >s3- ny sx2)<FEPS
s gfnt)s ny sy3- ny sy2S<FEPS);g {i	remids-2)-s g()ronts-2)-||)lsars-2))				breab=sesse]=i	llyiag past;
	lu	 rev>tg+->2	if(( revrtg+->-1;e		>ix3 != o>pr-	re)ronts-2)ect the  ny >tg+->1	if(wge->frgt the  ny >tg+->0/* rs}>pr-	relsars-2))	t the  ny rtg+->0/* rs}e->frgt the  ny rtg+->1	if(wgr  utc(
grp];(_Uriousj,efprx/* i,iy2+ at proes i	hs[.froutsames[nr]
ed  <xim gra->fag!=qu	drlrexpdipre0 (gge;

 at  ri			al cm = P;  (; ieots)ein[ceno=%d = at jovaed=om = ggooe
*b=s#,efpre CVEPS	1.5s#,efpre CVEPS2	(CVEPS*CVEPS)bs(snquelst eantsj.fr at  <xim grangny;i[i]-wt ceno=%d =  ]mox2
	jovalgw; #,efpre SMOOTHSIN2 0.25o3 >0.25==ean(30j,egrees)^2 ;
	s(snquelst  past*engt,
i[i]-wt ceno=%d =sm s,  va#,efpre SMALL  ge-2 (15.*15.)bs(s;
wprevwdtimds a om = gmred b| biggd = aaniag pastin[jova,snquelst  va#,efpre TIMES  ge-2 (3.*3.)rp]; i--Norm
			 ( nts 	alys (  x
				gg rL g rce  ncise() 				fillv. */y), gex_  n	eg ]+ructuls	egp[i]+=rexpand;
) 	aly	eges array.
 */

) * avalel, ix, iysi[dou ny;avsd2, dots	3		2sb=X,Y*/];))GEX_CON */
x;)	s/
x+->X_CONs n	a])memsets nx, 0,;s		 of */
x);)	s/
x->len2 =;0;sst t SDBG(SU2)) {
		fpriavsd2 d  nx->d			-=gv=0;  ovalu
			2r[-U ny  (ge->> ovalu
			2r %d)/
x->len2 +=;avsd2*avsd2;i[}	s/
x->uin2 d njovaluin2sp fog	vs > v)xtr	red of curve for a not smootd ofdir d ngetcvdirs n	a]);)>= SDBG(SU2)) {
		fprindots	0][		 d  ny  (ge->> ovalu
			2r;alu	dots	1]			-=gv=0;  ovalu
			2r;alu	dots	2]			-=gncv_UP(/
i l, 0.5	pr  utciavsd2 d )EMtsegdipr2(dMtsildots	2]); {i	reavsd2 <= CVEPS2)ct the		x-> 			bt| forXF_FLATpr  utc(ix3 != ootd ofdir d CVDIR_FEQUAL|CVDIR_REQUAL %d)/
x-> 			bt| forXF_FLATpr }tr	red x-> 			bt&forXF_FLAT		fpri 0
gfnt)s nx->d	X]) > FEPS
s gfnt)s nx->d	Yrd	< 5.pris gfnt)s nx->d	Yr /  nx->d	X]) <>0.2) the		x-> 			bt| forXF_HORlse x.
	 * O fnt)s nx->d	Yrd	> FEPS
s gfnt)s nx->d	Xrd	< 5.pris gfnt)s nx->d	Xr /  nx->d	Y]) <>0.2) the		x-> 			bt| forXF_VERTpr }tr	x d  nx->isd	Xr[g-fgin)s nx->d	Xrdxtr	y d  nx->isd	Yr[g-fgin)s nx->d	Y])xtr	re	x < f0		fpri	re	y < f0		 the		x-> 			bt| forXF_QDL;pri	re	y > f0		 the		x-> 			bt| forXF_QUL;pri	red x-> 			bt&forXF_HOR) the		x-> 			bt| forXF_IDQ_Lpr }tr	re	x > f0		fpri	re	y < f0		 the		x-> 			bt| forXF_QDR;pri	re	y > f0		 the		x-> 			bt| forXF_QUR;pri	red x-> 			bt&forXF_HOR) the		x-> 			bt| forXF_IDQ_Rpr }tr	red x-> 			bt&forXF_VERT		fpri	re	y < f0		t the		x-> 			bt| forXF_IDQ_U;e		>ix3 != o/*(suppoZOdi,  atr+1;LLsh 0-s		 dg
				gw; 	-e		x-> 			bt| forXF_IDQ_Dpr  utc(
grp]; i--A	alys (  jovalgbetwe{
	alivs]ntsfollow	hs[x
				gg rL g rce  ncise() - 						fillv. */y), otriespoSD< ma thes;om gh, gex_  n ]+ructuls	eg Bos,
	in		stg	mred b|  	aly	ed      .	egp[i]+=rexpand;
) 	aly	ejoval( array.
 */

) * array.
 *nd 		 		vs > vs[	rray.
 tor{
	GEX_CON */
x      x;))dou ny;evsd2, dots	3		2sb=X,Y*/];))AX_Si;	in/
x+->X_CONs n	ann nx+->X_CONsn n	pr =b=s*ook 0;

				cange->jovaed=homestlby va
 ed im evwdup fhan,

				should>jova ]mox2
lby val* O ed x-> 			bt&forXF_FLATs|| od x-> 			bt&forXF_FLAT	
	 ge->x->uin2 > SMOOTHSIN2) thgocot ry_fhan]x2
;ave	}
d of curve for  ge->	fprig-		g)m
			Wve for  ge->	fprir	red x->len2 > SMALL  ge-2 || od x->len2 > SMALL  ge-2s1 ? egocot ry_fhan]x2
;ars}e->frgt the	red x->len2*TIMES  ge-2 > od x->len2s1 ? egocot ry_fhan]x2
;ars}y initia 	}
	g)m
			Wve for  ge->	fpri	}
	g)x->len2*TIMES  ge-2 > d x->len2s1 ? gocot ry_fhan]x2
;ar}a
 ed im om = g>h|
	 /
, */
			f= val* O  nx->isd	Xr*n nx->isd	Xr<0 ||  nx->isd	Yr*n nx->isd	Yr<0) thgocot ry_=%dsi[Se;a
 ed im would>>P-1tf( lzigzagy val* O e(d ofdir&CVDIR_FRONT)-CVDIR_FEQUAL,	/*(
	g)m
dir&CVDIR_REAR)-CVDIR_REQUAL,	ray t thgocot ry_fhan[Se;a
 	re fcrossraypgesp fon nilNULLilNULLilNULL,	d	ex		x-> 			bt| forXF_JGOODpr
 ry_fhan[Se: =b=s*ook 0;

				cange->jovaed=by fhan=x;
	. */,neeom gh, in		stg	 va
 ed air
	lse ovalgwe k10, 		i]-1; jx
	>fal
, */
			f=om gh,
 			g
			stg	;s OK
 GE_C 	* O  nx-> 			bt&forXF_FLATs>	fpritnvs].*or{
		tnv.>h1{
	tnv.>h3{
		tnv.>y1{
	tnv.>	else tnorm
			eges&t n	a]);	re fcrossraypges&t nfon nilNULLilNULLilNULL,	d	exx		x-> 			bt| forXF_JFLAT|orXF_JFLAT1pr }tr	re od x-> 			bt&forXF_FLATs>	fpritnvs].*nor{
		tnv.>h2
 sprev>e3{
		tnv.>y2
 sprev>	else tnorm
			eges&t n	a]);	re fcrossraypges nil&t nfoNULLilNULLilNULL,	d	exx		x-> 			bt| forXF_JFLAT|orXF_JFLAT2;i[}	
 ry_=%dsi[Se: =b=s*ook 0;
,neeom gh, in		stg	cange->brh metg toan =%dsi		 d
 			al stems, s rL and the posit		f=ants atn>jovaed
	/b=s[* O  nx-> 			bt&forXF_HOR  ge->x->isd	Xr*n nx->isd	Xr>=0s>	fpritnvs].*or{
		tnv.>h1{
	tnv.>h3{
		tnv.>y1{
	 ny  (ge->s	el 3 >hsuce	al stems, s.high norm
			eges&t n	a]);	re fcrossraypges&t nfon nilNULLilNULLilNULL,	d	exx		x-> 			bt| forXF_JID|orXF_JID1;e	>ix3 !=* O  nx-> 			bt&forXF_VERT  ge->x->isd	Yr*n nx->isd	Yr>=0s>	fpritnvs].*or{
		tnv.>h1{
	 ny  (ge->sx3; 3 >hsuce	 and the .hightnv.>y1{
	tnv.>	else tnorm
			eges&t n	a]);	re fcrossraypges&t nfon nilNULLilNULLilNULL,	d	exx		x-> 			bt| forXF_JID|orXF_JID1;e	>tr	re od x-> 			bt&forXF_HOR  ge->x->isd	Xr*n nx->isd	Xr>=0s>	fpritnvs].*nor{
		tnv.>h2
 sprev>e3{
		tnv.>y2
 sn ny >
		 3 >hsuce	al stems, s.high norm
			eges&t n	a]);	re fcrossraypges nil&t nfoNULLilNULLilNULL,	d	exx		x-> 			bt| forXF_JID|orXF_JID2;e	>ix3 !=* O od x-> 			bt&forXF_VERT  ge->x->isd	Yr*n nx->isd	Yr>=0s>	fpritnvs].*nor{
		tnv.>h2
 sn ny >e { 3 >hsuce	 and the .hightnv.>y2
 sprev>	else tnorm
			eges&t n	a]);	re fcrossraypges nil&t nfoNULLilNULLilNULL,	d	exx		x-> 			bt| forXF_JID|orXF_JID2;e	>r
 ry_fhan]x2
: =b=s*ook 0;
wt can >h|
	 *g tm,	if,nee past;
	l	red x-> 			bt&forXF_FLAT  geod x-> 			bt&forXF_FLAT	smoott t SDBG(SU2)) {
		fprindots	0][		 d  ny  (ge->> ovalu
			2r;alu	dots	1]			-=gn ny > ovalu
			2r;alu	dots	2]			-=g ny > ovalu
			2r;alu}]);	re fEMtsegdipr2(dMtsildots	2]) <= CVEPS2)	exx		x-> 			bt| forXF_J ge-a])}
grp]; i--Fsuce	  ncisenesp o;
,nee>nvsour	At Blue path,
							cnvsour	As ISD<c teei];t,nee
				gge;

i .	egp[i]+=rexpand;
)  ncisecnvsourid = gssent,y rray.
 *prert/

) * ed initi
	  <xim grntries; geEMtsj toe->used=as reirectce%b=s#,efpre MAXDOTS	((NREFDOTS+1)*12)	 array.
 */
i  pM          ior{
	GEX_CON */
x   p/
x      x       x;))rray.
 tpM   tnor{
	valgqu	d, qq,el, j, nEMtsil <xEMts)
	valgfound	2r % the jovamask, p 			, nf			;s[]+ructjEMt_dipr *EMts;))dou ny;evsd2,  <xE2, eps2si[dou ny;apcv[4]	2r %	e {
prert/
si f0		fpri)ntf(st err, "***hint fo:> ssand 	f=An
		 *rp+1% , pleasnsreporteil  togh; ttf2pt1 proj/
	alue
			__FILE__e __ ge-__flse )ntf(st err, "***Stra
	 *>nvsour	At  path
		alue  		h-2));g-	dumpid= mighaNULLilNULL,;g-	lstter;	l}%	e {
prert/
");

	g! for a not  geprert/
");

	g! for  ge->
e	lstter; 			 robablyiagdex
	>fat *>nvsour	E_C 	* Oturn;
FCONCISE)sse )ntf(st err, "***proes i	hs[>nvsour	0x%p[.frgpath
		alue prert/
e  		h-2));g
	 <xEMts-=gMAXDOTSsi[dots-=g(]+ructjEMt_dipr *)mallot(s		 of(*EMts)* <xEMts)xtr	redots-==lNULL,	fpri)ntf(st  err, "**** **mallotgfnileE
		 *rp+1% alue __FILE__e __ ge-__flse xxit(255	a])}

	g {
	prert/
a])jovamask  forXF_JGOODpr	=pairt1		fprbestert:	ex		x+->X_CONs n	a])r	reed x-> 			bt&forXF_JMASKd	> ((jovamask<<1)-1) sm the	return;
FCONCISE)sse e )ntf(st err, "***found higt lo 			 (%x>%x) air0x%palue 
			xx		x-> 			bt&forXF_JMASK, ((jovamask<<1)-1)fog	);g-	wjovamask <<->1	if(wprert/
sis nsg];tit= g	ifredtogh; p/
	 VP]);relevant bo res)r	ree  nx-> 			bt&fjovamask ){
		
	;rgocot "bu;

teed im wd uepp{
	aoge->ine			fmidted of(  s		shs[.f
} 			jovaa ny;in		stg,shintsilueb
					hs
= GE_C	[* O  nx-> 			bt&f(orXF_JCVMASK^orXF_JID,	d	exxqu	d d  nx-> 			bt&fX_CON_Feprev>/* )t&forXF_QMASKlse x.
	 * O 		x-> 			bt&forXF_JID2	d	exxqu	d d  nx-> 			bt&forXF_QFROM_IDEAL(X_CON_Feprev>/* ))t&forXF_QMASKlse x.
	 ed  red b| orXF_JID1 VP]);rqu	d d orXF_QFROM_IDEAL( nx-> 			b)t&fX_CON_Feprev>/* )t&forXF_QMASKls
  pnvs]. ns[	=p		x+->X_CONspo y ->ix);g {i	return;
FCONCISE)sse enntf(stderr, "* " +1%p prev ->	0x%p["fog	pap n	pr =	=pairtp		x-> 			bt&forXF_JCVMASK sm the	re !tp		x-> 			bt&f((orXF_JCVMASK^orXF_JID,|orXF_JID2),	d	exx	qq d orXF_QFROM_IDEAL(p		x-> 			b);g-	w->frg
		luqq d p		x-> 			bt&forXF_QMASKls
  e	return;
FCONCISE)sse e )ntf(st err, "***(%x?%x)"foqu	d, qq)ls
  e	re !tqu	d & qq)				break	re !tX_CON_Fepo th&f(orXF_JCVMASK^orXF_JID,sse e  gep nx-> 			bt&f(orXF_JCVMASK^orXF_JID,	d 	break;			 at previose
				gisj,efprx/elyiagbettes;m tche;
	lu		d>nsp	rv			o the	lu		de	return;
FCONCISE)sse e  e )ntf(st err, "***\nprev ivs]gbettes;m tcheair%palue p n	pr	 +=hwprert/
sis nsr	 +=hwgocot "bu;
 +=hwge->frwd;
hw pnvs]..orev > vs[	= ss[				RP-1];e	
			
			qu	d &= qq;e	
	pnvs]..orev->ix;e	
	pnvx+->X_CONspo y ->ix);g  e	return;
FCONCISE)sse e )ntf(st err, "***0x%p["fop n	pr  ut
b=)
	coll/
	+aserevwdin		stg	g rLjova< masse o i	 ny;*r]  nnvs]. nev > vs[	=n nx+->X_CONsn n	pg
		nn nx+->X_CONsn nvs > v)x g {i	return;
FCONCISE)sse enntf(stderr, "* ":	0x%x\n "bug->	0x%p["foorigin) 
			cop != n n	pr =	=pairtod x-> 			bt&forXF_JCVMASK sm the	re !tn		x-> 			bt&f((orXF_JCVMASK^orXF_JID,|orXF_JID1),	d	exx	qq d orXF_QFROM_IDEAL(nn		x-> 			b);g-	w->frg
		luqq d nod x-> 			bt&forXF_QMASKls
  e	return;
FCONCISE)sse e )ntf(st err, "***(%x?%x)"foqu	d, qq)ls  e	re !tqu	d & qq)				break	re !tX_CON_Feno y ->ix)s&f(orXF_JCVMASK^orXF_JID,sse e  gen nx-> 			bt&f(orXF_JCVMASK^orXF_JID,	d 	break;			 at n"bug "bug
				gisj,efprx/elyiagbettes;m tche;
	lu		d>nsn	rv			o - >rix)sm
	==	de	return;
FCONCISE)sse e  e )ntf(st err, "***\n "bug%x ivs]gbettes;m tche aani%x air%p (jmask %x)alue 
								od x-> 			bt&forXF_JCVMASK, 		x-> 			bt&forXF_JCVMASK,      jovamask)sr	 +=hwgocot "bu;
 +=hwge->frwd;
hw ng {
	no y ->ix;[	= ss[				RP-1];e	
			
			qu	d &= qq;e	
	ng {
	no y  > vs[	= n nx+->    x; 
			nn nx+->X_CONsn nvs > v)xg  e	return;
FCONCISE)sse e )ntf(st err, "***0x%p["fon n	pr  ut
b=	return;
FCONCISE)sse enntf(stderr, "* ":	0x%x\n"foorigin) 
			con n	pr =	) {XXX add n  ntt	hs[.frs at 
			stg	;ft "ces iary  va
se_UPme {
sulse		i]- s, 				reirectce%EMtsja t _UPidob=s[tt t Sg {
	.or{ i	rv! fno y  > vs Sg {
	io - >rix)sm
	==nn nx+->X_CONsi n	pr	 +	re !tnod x-> 			bt&forXF_VDOTS,	d 	break) ZopleEMts(i != nod x->EMtsilNREFDOTS)sr	 +=nod x-> 			bt| forXF_VDOTSsi[rs}>pr) 
					dtogh; actu	l	jova< mab=s[t=pairt1		fprinpnvx+->X_CONspo )s[	= n nx+->X_CONsn nvs->ix);g  e			10,  at eegmealsj toe->jovaed=]lsepge...>nvs va
se	ndots-=g,
	   elseSg {
	.or{ i	rv! fno y  > vs Sg {
	io - >rix)sm
	==s 0
maxdots-<snEMts+(NREFDOTS+1))sm
	==	dmaxdots-+=gMAXDOTSsi[[[[[dots-=g(]+ructjEMt_dipr *)P-1llot((and; *)EMtsils		 of(*EMts)* <xEMts)xtr	==s 0
dots-==lNULL,	fprie e )ntf(st  err, "**** **mallotgfnileE
		 *rp+1% alue __FILE__e __ ge-__flse     xxit(255	a])	= ss[				}r	 +=nod x+->X_CONsi n	pr	 +=t t SDBG(SUNREFDOTS)) {
		fprin	in", EMGRP-12	g->nsse     dots	nEMts].p	 fr=gnod x->EMts			e fa])	= snEMts++;[	= ss[				n", EMGRP-12	g->nsse    dots	nEMts].p	 fr=gi ny > ovalu
j		2r;alu	wnEMts++;[	= }
se	ndots--;e			 at s at  ovalglsesho*intebest< mab=s
se	tpnvs].*p nsr	 +p 			 d p		x-> 			bpr	 +	rep 			 &f(orXF_JGOOD|orXF_JFLAT2|orXF_JID2),	fprin	,
	shoh< mab=s[t	>ix3 !=* Op 			 &forXF_JFLAT,	fprin	tpnv.>h1{
	tpnv.>h3{
		n	tpnv.>y1{
	tpnv.>yelse i>ix3 !=* Op 			 &forXF_JID,	m
	==s 0
p 			 &forXF_HOR) then	tpnv.>y1{
	tpnv.->ix->syelse ii->frwd;
hwtpnv.>h1{
	tpnv.->ix->sh3{
		n		
			tnnvs].*nor{
			n 			 d n		x-> 			bpr	 +	ren 			 &f(orXF_JGOOD|orXF_JFLAT1|orXF_JID) the ge!en 			 &forXF_JID2),	fprin	,
	shoh< mab=s[t	>ix3 !=* On 			 &forXF_JFLAT,	fprin	tnnv.>h2
 stnnv.->ix->sh3{
		n	tnnv.>y2
 stnnv.->ix->syelse i>ix3 !=* On 			 &forXF_JID,	m
	==s 0
X_CON_Feno ) &forXF_HOR) then	tnnv.>y2
 stnnv.syelse ii->frwd;
hwtnnv.>h2
 stnnv.sh3{
		n		
			tnorm
			eges&tpo )s[	= tnorm
			eges&tn n	pr	 +	re fcrossraypges&tp nil&tn nilNULLilNULLil&apcv[1rd	,	m
	==sapcv[0		Xr[g-tpnv.->ix->sh3{
		nsapcv[0		Yr[g-tpnv.->ix->syelse iied apcv[1r( nts pcv	2] wtr+1filled=by fcrossraypges)e;
	lu		 pcv	3		Xr[g-tnnv.sh3{
		n	 pcv	3		Y]
 stnnv.syelsse iied >alc handl at precis;

j,epeSD<hs[.
	aleoem s,es;dimeas;

j.fr at cm = e;
	lu		 <xE2
 s pcv	3		Xr-apcv[0		Xr;	lu		 <xE2
*=  <xE2lse ii-ps2
 s pcv	3		Yr-apcv[0		Yr %{			-ps2
*= eps2si[==s 0
maxd2 <;eps2) then	-ps2
 s <xE2lse ii-ps2
*= (CVEPS2*4.)i, 
400.*400.);g-	ww[g--ps2
< CVEPS2)	exxn	-ps2
 sCVEPS2lse ii->fr [g--ps2
> CVEPS2*4.)	exxn	-ps2
 sCVEPS2*4.lsse iifapproxom = (apcv, EMtsilnEMts		i
n	iyavsd2 d )EMtom =dipr2(apcv, EMtsilnEMtsil& <xE2
 )e, ee	return;
FCONCISE)sse e  nntf(stderr, "* "wvsd up%g,o <xE up%g,oue sqrt(avsd2)e sqrt( <xE2
);g-	ww[g-avsd2 <= -ps2
 gemaxd2 <= -ps2*2.d 	break;			we'= ggue
	s
	a om = g		i]-lse loZONugh mem
					hwggooecv++; ggooecvdots-+=gnEMts)
tr	==s 0
turn;
FCONCISE)sgfprie e )ntf(stderr, "* "An
		 jovaed=%p-%r[fo ue  		h-2)fop nfon n	pr  				n", SDBG(SU4-) {
		fpriie e )ntf(stderr, "* "i(%g, %g)ue apcv[i]
Xre apcv[i]
Y])xtrrrrrr}prie e )ntf(stderr, "* "gge;
);
			exxxxxdumpid= mighap nfon n	pr  			}
 				n", SDBG(SU3-) {
		fpriie e.orev xn			-=gapcv[i+1		Xr;	lu		 e.orev yn			-=gapcv[i+1		Yr %{				}
 				pg)m
			Wvefor a not %{				g {
	.or{
 				n", Snvs]..orev > vs s Sg {
	po - >rix)sm
	==	de	rei	rv			po the	lu		dei)ntf(st err, "***hint fo:> ssand 	f=An
		 *rp+1% , pleasnsreporteil  togh; ttf2pt1 proj/
	alue
								__FILE__e __ ge-__flse     u)re-(EMts)xtr	==s	xrotter;	lurrrr}prie e  {
prert/
si fi n	tr	==s	xprert/
sis.or{
 				u)re-(id of"bu){
 				u)re-roupgesi n	pr  					rei	rv			n n	tr	==s	xRP-1];e	
			}
 				nnorm
			eges n	pr  			 0
turn;
FCONCISE)sgfprie e )ntf(stderr, "* "<orm
			 d "	pr  				n", SDBG(SU3-) {
		fpriie e )ntf(stderr, "* "i(%g, %g)ue  ny > ovalu
X][		e  ny > ovalu
Y]	i]	arrrrrrr}prie e )ntf(stderr, "* ");
			exxxx}
 				n 	aly	eges n	pr  			) 	aly	ejoval( n	pr  			) 	aly	eges nvs->ix);g  e		) 	aly	ejoval( ny ->ix);g {i	k;			 at besules;om ghi	 jova willvit= g	ifbt beceno=%d edob=s[i].wprert/
sis ns]. nev > vs[	=	hwgocotbestert;[	= sse->fr 	break;gbaecv++; gbaecvdots-+=gnEMts)
xxxx}
 				
						im wd'r j,own[fo 2 
			stg	t {
	aleojova ue)
fnileE
*/-	ww[g-po - >rixv			n n	 	breakp nx-> 			bt&= ~jovamask;g-	ww[g-turn;
FCONCISE)sse e  nntf(stderr, "* "no;m tch);
			exxxgocot "bu;
 +=		
						 educes at rtries; ge
			stg	by dropp<hs[.
 gi]-sin 3eSDe
			eg ]hould>ne->frdrop
 at  ri			al g(gge;

 at ra
	 
			eg/s
  e	ren nvs->ixv			o )e, e||s.orv! fg)-s g(p		x-> 			bt&forXF_JCVMASK s<= tod x-> 			bt&forXF_JCVMASK s	 	breakp ns]..orev > vs[	= se->fr 	breakng {
	no y ->ix;[	= }>pr-	return;
FCONCISE)sse e )ntf(st err, "*** "bugtry: %r[fo %palue p nfon n	pr  ut
 "bu:	ex		s]. nev > vs[	=	red v			prert/
	 	breajovamask  f(jovamask >>s1		&forXF_JCVMASKpr	 +	rejovamask   f0	
=s	xRP-1];e	
}ar}a
 ed jova fhan eegmealsj		cotsames[nr] ];tielsege==prert/
snr] =pairt1		fpri		x+->X_CONs n	a])r	ree!ed x-> 			bt&forXF_J ge->		
	;rgocot "bu2 %
		ndots-=g,
	  dots	nEMts].p	X]
 sprev>e3
	  dots	nEMts].p	Y]
 s rev>
3;
	wnEMts++;[
  pnvs]. ny ->ix;[	=nnvs]. nev > vs[
b=	return;
FCONCISE)sse enntf(stderr, "* "jova< ma ge-gge;

%p-%ralue  != n n	pr =	=pairtpnv!=n n	 	breapnvx+->X_CONspo )s[	= n nx+->X_CONsn n
 )e, e	return;
FCONCISE)sse e )ntf(st err, "***(p=%p/%x n=0x%x/%x) ue p nfop		x-> 			bt&forXF_J ge-e 
					origin) 
			con n,eod x-> 			bt&forXF_J ge->pr	 +	re !t(p		x-> 			bt| od x-> 			b)t&forXF_J ge->			m
	==s 0
turn;
FCONCISE)sse e  nntf(stderr, "* "(e			p=%p n=%p) ue p nfon n	pr  		RP-1];e	
			
			 0
maxdots-<snEMts+2			breakmaxdots-+=gMAXDOTSsi[[[[dots-=g(]+ructjEMt_dipr *)P-1llot((and; *)EMtsils		 of(*EMts)* <xEMts)xtr	== 0
dots-==lNULL,	fprie e)ntf(st  err, "**** **mallotgfnileE
		 *rp+1% alue __FILE__e __ ge-__flse    xxit(255	a])	= }[	= }>pr-	reop		x-> 			bt&forXF_J ge-	d 	break) t SDBG(SU2)) {
		fprinnsapcv[0				-=gpo y ->ixy > ovalu
			2r;alu	nsapcv[1]			-=gn ny > ovalu
			2r;alu	  dots	nEMts].p			-=gpo y > ovalu
			2r;alu	 }r	 +=nEMts++;[	= st t SDBG(SUnEMts)) {
		fpri
ciavsd2 d )EMtsegdipr2(apcv, EMts	i].p	ar  			 0
avsd2 > CVEPS2)	exxn	xRP-1];e	
		}tr	== 0
SUnEMts smlb=sfnileE
in[jovae;
	lu		d>nsturn;
FCONCISE)sse e  e)ntf(st err, "***fnileE
in[jovaeprev %p["fop n	pr  	e	ndots--;
 				pg)x-> 			bt&= ~orXF_J ge-a])= sse->fr 	break;pnvs]..orev->ix;e	
		d>nsp	rv			no the	lu		de	return;
FCONCISE)sse e  e )ntf(st err, "***intebs/
	s
	ateprev %p["fop n	pr  	e	xRP-1];lb=soopri t	stE
in[self-intebs/
	e;
	lu		ds[				}r	 +>ix3 !=* Oturn;
FCONCISE)sse e )ntf(st err, "***(p=%p)["fop n	pr>pr-	reood x-> 			bt&forXF_J ge-	d 	break) t SDBG(SU2)) {
		fprinnsapcv[0				-=gpo y > ovalu
			2r; 			 gt  ovals>be) te-1; j1stseegmeal ;
	lu		dapcv[1]			-=gn ny >rixy > ovalu
			2r;alu	nsdots	nEMts].p			-=gn ny > ovalu
			2r;alu	 }r	 +=nEMts++;[	= st t SDBG(SUnEMts)) {
		fpri
ciavsd2 d )EMtsegdipr2(apcv, EMts	i].p	ar  			 0
avsd2 > CVEPS2)	exxn	xRP-1];e	
		}tr	== 0
SUnEMts smlb=sfnileE
in[jovae;
	lu		d>nsturn;
FCONCISE)sse e  e)ntf(st err, "***fnileE
in[jovae "bug%p["fon nvs > v)xg  ee	ndots--;
 				ng)x-> 			bt&= ~orXF_J ge-a])= sse->fr 	break;ng {
	no y  > vs[	= 	}r	 +>ix3 !=* Oturn;
FCONCISE)sse e )ntf(st err, "***(n=%p) ue n n	pr  ut
b=p ns]..orev > vs  			10,  at t mibs=]lsepge...>nvse = gsi= e;
	lu>nsp	rv			no th/*(  deeplysper->fsi= e>nvsour	E_Cn	xRP-1];e
b=	return;
FCONCISE)s	fprinnntf(stderr, "* ");An
		 jovaed= ge-	%p-%r[ge;
);
e  		h-2)fop nfon n	pr  	dumpid= mighap nfon n	pr  }
		pg)m
			Wvefor  ge-a])=) t SDBG(SU2)) {
		fprinpo y > ovalu
			2r-=gn ny > ovalu
			2r;alu	mem norm
			egesp n	pr  X_CON_Fepo th&= ~orXF_J ge-a]
		g {
	.or{
 	n", Snvs]..orev > vs s Sg {
	po - >rix)sm
	==	rei	rv			po the	lu		)ntf(st err, "***hint fo:> ssand 	f=An
		 *rp+1% , pleasnsreporteil  togh; ttf2pt1 proj/
	alue
					__FILE__e __ ge-__flse   )re-(EMts)xtr	==rotter;	lur}>pr-	reprert/
si fi n	tr	==prert/
sis.or{
 		)re-(id of"bu){
 		)re-roupgesi n	pr  		rei	rv			n n	tr	==RP-1];e	
}a "bu2:	ex		s]. nev > vs[	=	red v			prert/
	Cn	xRP-1];eevbestre-(EMts)xt=abs(shsuce	  ncisenesp: substitute 2 or m te-om = vsgo< maine			
**e Zonequ	drlalgwentr,nee>m = P*d in fhoat< ma oval
 rn s=malfg rce  ncise(
	     = gssen g
) * ))rray.
         *M          e		     xge;a
  ssand sfhoatigha"eng rc	hs[>nvcisenesp
			1 fdx3 malligha0.05	a]) ssandid= ( 		in		stg,s__FILE__e __ ge-__e  		h-2));g
	* Oturn;
FCONCISE)sse dumpid= mighaNULLilNULL,;g
=)
	coll/
	+m te-ing rm	/* i,ab. */nhs,
x
				gants atirLjovalsob=sst t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)[	=	r ed of curve for a not ||  nm
			Wve for  ge->
 		)norm
			eges n	prsst t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)[	=	r ed of curve for a not ||  nm
			Wve for  ge->he	lu	allot_gex_  n(o )s[	= t 	aly	eges n	pr  
			ed nee w[i]-wt ca ieo,ab. */jova< mab=s[t t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)[	=	r ed of curve for a not ||  nm
			Wve for  ge->
 		) 	aly	ejoval( n	pr
e			10, dtogh; jova< mab=s[t t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)[	=	red of curve for MOV->
 		)  ncisecnvsourig,. nev "bu)prsst t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)[	=	r ed of curve for a not ||  nm
			Wve for  ge->
 		)re-(d of"bu){
}n s=malntf(s_gpath(
	   valggpathno
) * ar gsse         *M;))rray.
         *M ;% the             or s,, ye->0;% the             i;% the             grp, s atgrp->-1;e
	* Oturn;
FCONCISE)  ge-pathnosi f0		fpri)ntf(st err, "***Gue
	s
	om = v: baE
	d/%dggooe
	d/%dalue
			gbaecv, gbaecvdots, ggooecv, ggooecvdots	a])}

	ge->&-path_lipr[-pathnor %	e)ntf(st pfa_file***/		 { alue  		h-2));g
=)
	cono=%d =wid= m >MAXLEGALWIDTHassebugs/b=s[* O  ->s>al
dwid= s<= MAXLEGALWIDTHa		fpri)ntf(st pfa_file***0+%dghsbwalue  		s>al
dwid= 	a])}e->fr 	bre)ntf(st pfa_file***0+1000ghsbwalu	pr  hint fo_2i)ntf(stderr, "* "gpath
		:=wid= +%dgs/emsj toe->   gy, oe1]	if1000alue
			g		h-2)fo 		s>al
dwid= 	a])}		#im 0	e)ntf(st pfa_file***%%e>nvsour	:=g; i+t t  Se->BG(S < g		h>nvsour	)) {
	bre)ntf(st pfa_file***%s(%d,%d) ue ( 		>nvsour		i]., */
			f=i fDIR_OUTER ? ". *" :**in")e
			g		>nvsour		i].xofmva,sg		>nvsour		i].ymva; i+tntf(st pfa_file***);
			1 	r ed->rymva	< 5000	bre)ntf(st pfa_file***%d lower		alue  		rymvae ( 		fhanymva	? "fhan" :**om = "))xtr	r ed->rymax > -5000	bre)ntf(st pfa_file***%d upper		alue  		rymaxe ( 		fhanymax ? "fhan" :**om = "))xt#eSD<fg
e	r ed->hstems)
 	n",  Se->BG(S < g		hh	)) -+=g2)sm
	==	r ed->hstems	i]. 			bt&fST_3the	lu		)ntf(st pfa_file***%d %d %d %d %d %d hstem3alue
					d->hstems	i]._UP |e
				d->hstems	i + j]._UP |[-U ->hstems	i]._UP |e
					d->hstems	i + 2]._UP |e
					d->hstems	i + 3]._UP |[-U ->hstems	i + 2]._UP |e
					d->hstems	i + 4]._UP |e
					d->hstems	i + 5]._UP |[-U ->hstems	i + 4]._UP |
					)xtr	== -+=g4s[	= se->fr 	break)ntf(st pfa_file***%d %d hstemalue  		hstems	i]._UP |e
				d->hstems	i + j]._UP |[-U ->hstems	i]._UP |);	lur}>pr}g
e	r ed->vstems)
 	n",  Se->BG(S < g		hv	)) -+=g2)sm
	==	r ed->vstems	i]. 			bt&fST_3the	lu		)ntf(st pfa_file***%d %d %d %d %d %d vstem3alue
					d->vstems	i]._UP |e
				d->vstems	i + j]._UP |[-U ->vstems	i]._UP |e
					d->vstems	i + 2]._UP |e
					d->vstems	i + 3]._UP |[-U ->vstems	i + 2]._UP |e
					d->vstems	i + 4]._UP |e
					d->vstems	i + 5]._UP |[-U ->vstems	i + 4]._UP |
					)xtr	== -+=g4s[	= se->fr 	break)ntf(st pfa_file***%d %d vstemalue  		vstems	i]._UP |e
				d->vstems	i + j]._UP |[-U ->vstems	i]._UP |);	lur}>pr}g
et t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)	fpri	}
g		hsg>0		t the	rp- nevstemidpr  		re	rp > f0  ge-rp ! fs atgrp)  	break)ntf(st pfa_file***%d 4 >allsubralue  rp+ 		f    subr)xtr	==s atgrp-grp;	lur}>pr}g
e	swens,
ed of cur		t thcasnsor MOV-:
	==	r eabsolute)break)ntf(st pfa_file***%d %d amovetoalue  !->ix3e  !->iy3);g-	w->frtr	==rmoveto( !->ix3[-Uxe  !->iy3[-Uy	pr  		r (0sse e )ntf(st err, "***Gpath
		:=ntf(s moveto(% , %d)alue
					d->h-2)fo !->ix3e  !->iy3);g-	wxs]. nevih3{
		nye-> ny iyelse iRP-1];e	
casnsor  ge-:
	==	r eabsolute)break)ntf(st pfa_file***%d %d a*rp+toalue  !->ix3e  !->iy3);g-	w->frtr	==r*rp+to( !->ix3[-Uxe  !->iy3[-Uy	pr  	xs]. nevih3{
		nye-> ny iyelse iRP-1];e	
casnsor a not:
	==	r eabsolute)break)ntf(st pfa_file***%d %d %d %d %d %d arom = toalue
					dnevih1e  !->iy1e  !->ix2e  !->iy2e  !->ix3e  !->iy3);g-	w->frtr	==rrom = to( !->ix1[-Uxe  !->iy1[-Uye
					   !->ix2[-U ny ih1e  !->iy2[-U ny iy1e
					   !->ix3[-U ny ih2e  !->iy3[-U !->iy2	pr  	xs]. nevih3{
		nye-> ny iyelse iRP-1];e	
casnsor PATH:
	== loZOid= ()lse iRP-1];e	
defaulu:	ex hint fo_1i)ntf(stderr, "* "* ** Gpath
		:=unk10,ng
				g			Wv'%c'alue
				d->h-2)fo !-> cur	lse iRP-1];e	
}ar}a
 )ntf(st pfa_file***eSD
ntal} ND);
			=abs(sntf(s aleoeubrh tames[iy2+ aise path,orotterss at rtries; geg tm,b=sval
ntf(s_gpath_subs(
	   valggpathno,
	   valgprertido/*(srert rtriesing oubrh tames[ie;

 aAs IE
*/-) * ar gsse*M;))valel, grp;	
	ge->&-path_lipr[-pathnor %	e	re!hvalso|| !oubhvalso|| g		hsg<1)1 ?betters,;	
	g		f    subr=prertid;		#im 0	e)ntf(st pfa_file***%%e		 % alue g		h-2)fo 		hsg)xt#eSD<fg	n", grp-0;s rp< 		hsg;s rp{
		fpri)ntf(st pfa_file***dup %d {alue prertid{
	a])=) t SD  grp-=0)?f0 :o 		hsbs[grp-1]-) < 		hsbs[grp])) {
	bre+tntf(st pfa_file***)t%d %d %cstemalue  		sbstems	i].lowe 
				 		sbstems	i].higt- 		sbstems	i].lowe
				 		sbstems	i].is and ? 'v' :o'h'flse )ntf(st pfa_file***)tbetter\n\t} NPalu	pr }a
 
		}
	} 		hsg;
}n s=malntf(s_gpath_metrics(
     FILE *afm_file*
	   valgcode*
	   valggpathno
) * ar gsse*M;)
	ge->&-path_lipr[-pathnor %	e	retra
sg rm)
	  )ntf(st afm_file* "C %d ; WX %d ; Ne		 ; G %d ; B %d %d %d %d ;alue
		 gcode*o 		s>al
dwid= e g		h-2)fo pathno,
		 gis>al

g		xMva;,gis>al

g		yMva;,gis>al

g		xMax;,gis>al

g		yMax;	pr ->frtr  )ntf(st afm_file* "C %d ; WX %d ; Ne		 ; G %d ; B %d %d %d %d ;alue
		 gcode*o 		s>al
dwid= e g		h-2)fo pathno,
		 gg		xMvae g		yMvae g		xMaxe g		yMax);)	}n s=malntf(s_gpath_metrics_ufm(
     FILE *ufm_file*
	   valgcode*
	   valggpathno
) * ar gsse*M;)
	ge->&-path_lipr[-pathnor %	  // MoD<fstE
in[h tput >h|ractes;spec<fsc bounding boxds asj		 AFM1files	e	retra
sg rm)
    )ntf(st ufm_file* "U %d ; WX %d ; Ne		 ; G %d ; B %d %d %d %d ;alue
	    code*o 		s>al
dwid= e g		h-2)fo pathno,
     gis>al

g		xMva;,gis>al

g		yMva;,gis>al

g		xMax;,gis>al

g		yMax;	p
  ->fr
    )ntf(st ufm_file* "U %d ; WX %d ; Ne		 ; G %d ; B %d %d %d %d ;alue
	    code*o 		s>al
dwid= e g		h-2)fo pathno,
     gg		xMvae g		yMvae g		xMaxe g		yMax);	}n]; iSB:
 An importlalgnotf( b. */y), BP |VUP |s.%	 Tl; Adob j,ocumeal	/* i,says 		i]-1; j <xim grwid= +of(  BP | zone
-lse onn/
	s
	 togh; _UP |e		 BP |S>al
, whis,
ig	by defaulua0.039625.	 Tl; BP |S>al
 _UP |e,efpres,	atewhis,
 ovalgs		 
 at  ->fshoot
(supprs i	onge->disa nyd.%	 Tl; g rmula[iy2+il  	i]-lseg<v{
	ine			fmanu	l	is:%	  BP |S>al
= oval_s		 /240,[iy2+a 300dpie,evice%	  	i]-me {stus won%d =w	i]-lse aAs 240 prending iy2. Incideal	lly
 240=72*1000/300, whelse72-lse ansrel	/* i,betwe{
	inchevs]ntsoovalua
+1000glse anss		 
om gh, gpath
matrixe ]nts300dpielse ansresolut;

j.f

 at   tput ,evice. Know	hs[t[i]-wt ca ire>alc handl at g rmula[iy2
l at g algs		 
vaepix->f ra atre aanioovalu:%	  BP |S>al
= ix->_s		 /1000%	 Tli]-*ookvs]glolgs	oplere aani at  ri			al g rmula, EMesesho*id ?
 And  at t mib	/* i,ab. */1; j <xim grwid= +of(z.
 gilso-*ookv
s]glolgs	oplereaftd = at tra
sg rm	/* i:%	   <x_wid= s<+1000/ ix->_s		 %	  	i]-ensulss 		i]-ev{
	o*/1; j <xim gr ix->gs		 
w {
	aleo ->fshoot
(supprs i	ongisj,isa nyd	aleoz.
 gwid= swillvbst*esse aani.
 g ix->.	 Tlig	;s importlal,sfnilulse	n[cemplys toghlsel mibswillvbesule
va
 P-1lly ugpa g als (be{
	alere, EMn g		i]). B */know	hs[t[t g rmula
,iy2+ at pix->gwid= e we nee  	i]-lnsfnc]-wt ca iuse/1; j <xim grwid= 

		 24,esho*23 asjspec<fs 
			e			fmanu	l.%	 rn #,efpre MAXBLUEWIDTHa(24)rp]; i--Fints at intexesj.fr at  ost[ieequeal _UP |s i--		e			fhystograme porteg tm,		easceSD<hs[.r%d e ]ntsst= gwhis,
one
-* wasU				b
s*/,nee(im esked)),
  Rotterss at rtries; ge_UP |s;found (mayvbst*esse aani <xim grbe>ause
-* wt ign te-1; jzeroe_UP |s)  gp[i#,efpre MAXHYST	(2000						s		 
om gh, hystogram%b=s#,efpre HYSTBASE 500[i]+=rexpval
b
s*hyst(
	 valg*hyst,k;			 at hystogram%b=s	 valgbasn,k;			 at basn oovale	m gh, hystogram%b=s	 valg*b
s*,k;			 at a /* [iy2+intexesj.frb
s*/_UP |s;b=s	 valgnb
s*,k;			ibs=]llothted	s		 
b=s	 valgwid= ese_UPminim grD<firectce%betwe{
	intexesjb=s	 valg*b
s*intp					 etters
	 tp oovale*/-) * arigin) 
	
ntal  hused[MAXHYST / 8 + j];% the             i,o <x, j, w, s ate->0;% the             nf
 s,;	
	wid= --;
])memsetshused,f0 ,;s		 of hused);g
	 <x ->1	ifn",  Se->BG(S < nb
s*
 gemaxv! f0;s {
		fpribest	i] =g,
	   <x ->0;
 	n",  j ->1	 j < MAXHYST ->1	 j{
		fprinw ->hyste fa]
	==	r ew >emaxvs g(hused[j>>3] &f(1 <<  j & 0x07)))si f0		fpriribest	i] =gj	if(wd <x ->w;	lur}>pr}g==	r emaxv! f0)sm
	==	r emaxv< s at/2			break			dtosho*pi.lo at too-*ow/_UP |s;b=s				RP-1];e	
				 	n",  j ->best	i] -gwid= 	 j <->best	i] +gwid= 	 j{
		fpri
c	r ej > f0  gej < MAXHYSTsse e  hused[j >>s3] |=f(1 <<  j & 0x07));e	
				 	s ate->maxlse iRest	i] -= basnlse inf
 si + j;e	
}ar}a
 	r eb
s*intpsse *b
s*intp ->best	0];g
=)
	porteg t	intexesj		easceSD<hs[.r%d ab=s[t t (Se->BG(S < nf;s {
		fprin",  j ->i + j;ej < nf;s->nsse  	r eb
s*	 fr<>best	i]		fpri
cw ->best	i];priribest	i] =gb
s*	 f;priribest	 fr=gw;	lur}>p}a
 
		}
	}nf %grp]; i--Fints at  "bugb
s*
BP | zone-		e			fhystogram),
  Rottere			fweimetg	m gh, found zone.	egp[i]+=rexpval
b
s*bP |(
	 shorte*zhyst,k;			 at zones hystogram%b=s	 shorte*physt,k;			 at  ovals>hystogram%b=s	 shorte*ozhyst,k;			 at o atrezones hystogram%b=s	 valg*bP |tabk;			whelse top */1; jfound zonee*/-) * athe             i,oj, w,  <x, int,      , s at;g
=)
	hints at higt at  ovalgln	 at zones hystogram%b=s	ed im wd ue= gi phandau, te {
ibs=ceStd ab=s[ed im wd ue= gmultiped  -1]s, te {
1; jf     onee*/-
	 <x ->-1;e	f     = s ate->-10	ifn",  Se->BG(S <= MAXHYST ->MAXBLUEWIDTH;s {
		fpriw ->zhyst	i];pri	r ew >emaxs	fprinn     = s ate->i;	lur <x ->w;	lu>ix3 !=*  ew ==emaxs	fprin*  es ate-->i ->1)tr	==s ate->i;	lu}e	>tr	nE up(n     + s at			a 		1 	r e <x - f0)n	,
	sh zones lefl ;
	lubetters,;	
				10, wnsreuse/`n    ' ]nts`s at' asj		= gsi= eb.r%d sj.fr at zonee*/-nn     = 	nE;	ls ate->ints+ (MAXBLUEWIDTHa->1);	
				our	 <xim grwid= +up ftaltoo-bige po wns			g	ifme {
ibsna /owersnr] =e->maxlsej ->ew &>1);iied a pseudo-ra
dom-bitsnr] =pair t1		fpri=pair tphyst[n    ]   f0	
=s	n    ++;[	==pair tphyst[s at]   f0	
=s	s at--;
 	*  es ate-jf     < (MAXBLUEWIDTHa* 2		a3)o|| e <x -gw,	/*10 >emaxsse iRP-1];e
 	*  ephyst[n    ] < physt[s at]
		 g o|| physt[n    ]   fphyst[s at]  gejs	fprin*  ephyst[n    ] * 20 >ew)[ed im wdimetgup >5%e
							eg ]+tp b=s				RP-1];e	
	w -= physt[n    ];
=s	n    ++;[	=ej ->0;	lu>ix3 !=fprin*  ephyst[s at] * 20 >ew)[ed im wdimetgup >5%e
							eg ]+tp b=s				RP-1];e	
	w -= physt[s at];
=s	s at--;
 		j ->1	if
}ar}a
 ed st= gour	zonee*/-nbP |tab	0]
 sf     - HYSTBASE;-nbP |tab	1]
 ss ate-jHYSTBASE;-s[ed in_UPid1tf( s, 				zones  ->flapp<hs[wentrghlseonee*/-n/						cnvstlalg		 2[isj,etd mvaed=by  at Eefaulua_UP |e		 BP |Fuzzab=s[t t (Se->f     - (MAXBLUEWIDTHa->1) - 2G(S <= s ate+ 2)) {
	bre*  ei > f0  gei < MAXHYSTs=fprinzhyst	i] ->0;	lu	ozhyst	i] ->0;	lu}	s
		}
	}w %grp]; i--T		g	ifhints at BP | VUP |s, bounding box ]ntsib	lexpangny	egp[is=malfintbP |s(and;) * a];tiystograms[iy2+upper ]ntslower	zones b=s[]horteeeeeeeeeeeiystl[MAXHYST];
=]horteeeeeeeeeeeiystu[MAXHYST];
=]horteeeeeeeeeeezuhyst	MAXHYST];
=]horteeeeeeeeeeezlhyst	MAXHYST];
=the             n
ntas;
=the             i,oj, k, w,  <x;))rray.
         *M ;% r gsse         *M;))dou ny;;;;;;;;;;ang;g
=)
	hints at loweateand higt at  ovals[.frgpaths[nr] ];tand by  at wayvbuilts at _UP |s[iy2+FontBBox[nr] ];tand builts at hystogram%iy2+ at Ib	lexAngny; va
 ed re-use/iystl%iy2+ at hystogram%.frib	lexpangny; va
 bbox	0]
 sbbox	1]
 s5000;
 bbox	2]
 sbbox	3	 d h5000;
s[t t (Se->BG(S < MAXHYST)) {
	breiystl[i] ->0;	
	n
ntas ->0;	
	t t (Se->B, ge->-path_liprG(S < numgpaths)) {
, g{
		fpri	r ed-> 			bt&foF_USED,	m
	==n
ntas++;[
  	d->rymva	 s5000;
  	d->rym<x ->-5000;
  	t t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)	fpri	=	r ed of curve for  ge->he	
					je-> ny iye[-U ny  (ge->iyelse i		ks]. nevih3[-U ny  (ge->ih3{
		n	c	r ej >f0	
=s	x		ang-=gatla2(-k, j,	/*180.0		aM_PI{
		n	c->frwd;
hw ang-=gatla2(k, -j,	/*180.0		aM_PI{
se i		ks/=+100;
					je/=+100;
						r eang-> -45.0  geang-< 45.0the	lu		de]; 						eg bt carefulg	ifsho* ->fflow 						eg 				cnuStd  						eg
	lu		deiystl[HYSTBASE + (; u)	eang-/*10.0t]-+=g(k-/*k + j			j			a4;
					}
						r e ny iye[==U ny  (ge->iyethe	lu		de	r e ny iye[<=  		rymva		fpriie e d->rymva	 s ny iyelse ie e d->fhanymva	->1	if(w			}
					e	r e ny iye[>=  		rymaxs	fprine e d->rymax	 s ny iyelse ie e d->fhanym<x ->1	if(w			}
					se->fr 	break;e	r e ny iye[<  		rymva		fpriie e d->rymva	 s ny iyelse ie e d->fhanymva	->0	if(w			}
					e	r e ny iye[>  		rymaxs	fprine e d->rymax	 s ny iyelse ie e d->fhanym<x ->0	if(w			}
					s[				}ix3 !=*  ed of curve for a nots	fprine 	r e ny iye[<  		rymva		fpriie ed->rymva	 s ny iyelse ie ed->fhanymva	->0	if(w		}
						r e ny iye[>  		rymaxs	fprine ed->rymax	 s ny iyelse ie ed->fhanym<x ->0	if(w		s[				}r	 +=	r ed of curve for  ge- ||  nm
			Wve for a nots	fprine 	r e ny ixe[< bbox	0])	exxn	xRbox	0]
 s nevih3{
		ne 	r e ny ixe[> bbox	2])	exxn	xRbox	2]
 s nevih3{
		ne 	r e ny iye[< bbox	1])	exxn	xRbox	1]
 s reviyelse ie 	r e ny iye[> bbox	3	)	exxn	xRbox	3]
 s reviyelse ie}[	= }>pr}ar}a
 ed getr at  ost[popularpangny; va  <x ->0;
 w =;0;sst t (Se->BG(S < MAXHYST)) {
		fpri	r eiystl[i] >ew)	fprinw ->hystl	i];prir <x ->i;	lu}e	>trang-=g(dou ny) e <x -gHYSTBASE			a10.0;	lhint fo_2i)ntf(stderr, "* "Gue
	s
	ib	lexpangny: %falue ang)xtr	r eib	lex_angny;  f0.0	
=sib	lex_angny; ;ang;g
=)
	builts at hystogram%.fr at lower	povalsob=sst t (Se->BG(S < MAXHYST)) {
	breiystl[i] ->0;	
	t t (Se->B, ge->-path_liprG(S < numgpaths)) {
, g{
		fpri	r eed-> 			bt&foF_USED,
		 g o ge-->rymva	+ HYSTBASE > f0  ge-->rymva	< MAXHYST ->HYSTBASE		fpriniystl[-->rymva	+ HYSTBASE]++;[	=}ar}a
 ed builts at hystogram%.fr at upper povalsob=sst t (Se->BG(S < MAXHYST)) {
	breiystu[i] ->0;	
	t t (Se->B, ge->-path_liprG(S < numgpaths)) {
, g{
		fpri	r eed-> 			bt&foF_USED,
		 g o ge-->rym<x + HYSTBASE > f0  ge-->rymaxv< MAXHYST ->HYSTBASE		fpriniystu[-->rym<x + HYSTBASE]++;[	=}ar}a
 ed builts at hystogram%.fr s, 				 o i	 ny;lower	zones wentrm<x wid= +b=sst t (Se->BG(S < MAXHYST)) {
	brezlhyst	i] ->0;	
	t t (Se->BG(S <= MAXHYST ->MAXBLUEWIDTH;s {
		fprin",  j ->0	 j < MAXBLUEWIDTH;s->nsse  zlhyst	i] +->hystl	i + j];ar}a
 ed builts at hystogram%.fr s, 				 o i	 ny;upper zones wentrm<x wid= +b=sst t (Se->BG(S < MAXHYST)) {
	brezuhyst	i] ->0;	
	t t (Se->BG(S <= MAXHYST ->MAXBLUEWIDTH;s {
		fprin",  j ->0	 j < MAXBLUEWIDTH;s->nsse  zuhyst	i] +->hystu	i + j];ar}a
 ed hints at basn past;
	lw ->bestbP |(zlhyst,>hystl,ezuhyst, &bP |_UP |s	0])xtr	r e0	bre)ntf(st err, "* "Basn pasBP | zone-%d%%e	d...% alue w-/*100		an
ntase
				bP |_UP |s	0], bP |_UP |s	1]			1 	r ew - f0)n	,
	sh basn pas,-sin oh< maweird ;
	lubetter;g
=)
	hints at upper zones b=sst t (nbP |s ->2))nbP |s < 14))nbP |s +=g2)sm
	=w ->bestbP |(zuhyst,>hystu, zlhyst,>&bP |_UP |s	nbP |s]);e
 	*  e0sse enntf(stderr, "* "BP | zone-%d%%e	d...% alue w-/*100		an
ntase 
				bP |_UP |s	nbP |s], bP |_UP |s	nbP |s+1]);e
 	*  ew * 20 <an
ntassse iRP-1];k			dtn't st= gghlsezonee*/-n}a
 ed hints at lower	zones b=s[t t (no atrb ->0	 no atrb <+10	 no atrb +=g2)sm
	=w ->bestbP |(zlhyst,>hystl,ezuhyst, &o atrbP |s	no atrb]);e
 	*  e0sse enntf(stderr, "* "O atrBP | zone-%d%%e	d...% alue w-/*100		an
ntase
				o atrbP |s	no atrb], o atrbP |s	no atrb+1]);e

 	*  ew * 20 <an
ntassse iRP-1];k			dtn't st= gghlsezonee*/-n}a
grp]; i--Fints at actu	l	wid= +of(gh, gpath
and moD<fy  at i--descrip/* i,cotbefl/
	+it. Nho*guarlales
	 todo- 				yggooe,  <yfme {
>h|ractes;spac	hs[too-wide.	egp[is=maldootriectwid= (and;) * athe             i;% rray.
         *M ;% r gsse         *M;))the             omvae x <x;))the              <xwid= e mvasp;g
=)
	eng rc gghlseminim grspac	hs,
 			wt t mibs at amnuSteom gh, ing rc d;spac	hs[to as=mal	eg ]pac	hs[tat boltswoalsj to-widely
	/b=s[mvasp =g(]+dhw>60 || ]+dhw<10)?f60 :o]+dhw;	
	t t (Se->B, ge->-path_liprG(S < numgpaths)) {
, g{
		fpri-->oltwid= = 		s>al
dwid= ; 			st= gghe oltswid= e willvnes
	t t AFM1g/s
  *  eotriectwid=   ge--> 			bt&foF_USED,	m
	==xmva	 s5000;
  	xm<x ->-5000;
  	t t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)	fpri	=	r ed of curv! for  ge-  ge->");

	g! for a not) 
					elevant bopri	=	r ed ofixe[<= omvas	fprine xmva	 s ny ixelse ie}[	=  	r e ny ixe[>= x <xs	fprine xmaxs]. nevih3{
		nx}
 				
			 <xwid= =xmax+mvasp;g		[* O  ->s>al
dwid= s<  <xwid= 	d 	break ->s>al
dwid= s=  <xwid= {
		nxhint fo_3i)ntf(stderr, "* "gpath
		:="buends
	te;

%
	 to%dalue
					g		h-2)fo 		oltwid= *o 		s>al
dwid=  );	lur}>pr}gn}a
grp]; i--T		g	ifhints at ;

 the stem=wid= m	egp[is=malstems+=restics(and;) * #,efpre MINDIST	10 _UPminim grD<stlace%betwe{
	 at wid= m b=s[*he             hyst	MAXHYST+MINDIST*2];
=the             best	12];
=the             i,oj, k, w;
=the             n
ntas;
=the             ns;
=STEM           *s;% r gsse         *M;)
 ed srert wentrg

 the stem=wid= 1g/s
 n
ntas=0;g
=)
	builts at hystogram%.fral stems, sstem=wid= m/b=s[memsetshyst, 0,;s		 of hyst);	
	t t (Se->B, ge->-path_liprG(S < numgpaths)) {
, g{
		fpri	r ed-> 			bt&foF_USED,	m
	==n
ntas++;[	==ss]. 		hstems;
  	t t (j ->0	 j < g		hh	))j-+=g2)sm
	==i	r eeu
j	. 			bt| u
j + j]. 			b)t&fST_END)
					elevant bo	rinw ->u
j + j]._UP |[-Uu
j	._UP |+1	if(w	* Ow==20th/*(n  ntsstems ]hould>nod b| cnuStddob=s[i].welevant bo	rin	r ew >e0  gew < MAXHYST ->1d 	break;		break;			aandny;sin 3fuzzaprs ealglnbreak;			ele ands
	t alsbreak;		=s[i].whyst	w+MINDIST] +->MINDIST-1	if(w		) t k=1; k<MINDIST-1	 k{
		fpri
c.whyst	w+MINDIST + k] +->MINDIST-1-];e	
			whyst	w+MINDIST - k] +->MINDIST-1-];e	
			s[				}r	 +>[	=}ar}a
 ed hints12  ost[ieequeal _UP |s		=s[ns ->besthyst(hyst+MINDIST, 0,;b
s*,s12, MINDIST, &]+dhw);)
 ed sr te-datagln	stemsnap +b=sst t (Se->BG(S < n	)) {
	brestemsnap 	i] =gb
s*	i];pr	r ens < 12	brestemsnap 	ns] ->0;	
	)
	builts at hystogram%.fr and the stem=wid= m/b=s[memsetshyst, 0,;s		 of hyst);	
	t t (Se->B, ge->-path_liprG(S < numgpaths)) {
, g{
		fpri	r ed-> 			bt&foF_USED,	m
	==ss]. 		vstems;
  	t t (j ->0	 j < g		hv	))j-+=g2)sm
	==i	r eeu
j	. 			bt| u
j + j]. 			b)t&fST_END)
					elevant bo	rinw ->u
j + j]._UP |[-Uu
j	._UP |+1	if(w	*  ew >e0  gew < MAXHYST ->1d 	break;		break;			aandny;sin 3fuzzaprs ealglnbreak;			ele ands
	t alsbreak;		=s[i].whyst	w+MINDIST] +->MINDIST-1	if(w		) t k=1; k<MINDIST-1	 k{
		fpri
c.whyst	w+MINDIST + k] +->MINDIST-1-];e	
			whyst	w+MINDIST - k] +->MINDIST-1-];e	
			s[				}r	 +>[	=}ar}a
 ed hints12  ost[ieequeal _UP |s		=s[ns ->besthyst(hyst+MINDIST, 0,;b
s*,s12, MINDIST, &]+dvw);)
 ed sr te-datagln	stemsnap +b=sst t (Se->BG(S < n	)) {
	brestemsnapv	i] =gb
s*	i];pr	r ens < 12	brestemsnapv	ns] ->0;	
#undsf MINDIST
grp]; i--SB i--A3funny  a	hs: TTF id= m=]lsego< mainere->fs->di*/
			f=cemp]lsd
				o T

	1. Soeaftd = s, (be>ausee ansresteom logiciuses TTF
			id= >di*/
			fb)twd ue= gcotbe->fs->gh; p/= m.	eg
			It wasUa-big headacat torD<sc ->f  	i].	egp[i			workseon ]x2
 valgand fhoat id= m=gp[is=malbe->fs-id= mte;
to(
		 g rray.
 *	te;
,
		 g rray.
 *	to
) * array.
         *M          por{
	GEay.
         *cur    "bu;
 valel, ae is at	2r;aldou ny;fs at	2r, fprsst t (		s].te;
; orv! f0  ge->v! fto;s ns]. nev "bu)	fpri	}
g of curve for  ge- ||  nm
			Wve for a nots	fprin	r eturn;
REVERSAL)sse e )ntf(st err, "***be->fs->id= >0x%x <->0x%x,	0x%x\n"foorigin) 
			co    origin) 
			co  y  (ge  origin) 
			co  y ->ix);g {i	)
	cut . */1; jid= >itself		=s[i]pnvs]. ny  (ge; 			or MOV-
*/-	ww[g sp	rv			0the	lu		)ntf(stderr, "* "* ! Nh MOV-
be) te- past!!! Fatal. * **);
			exxxxxit(1);e	
				 	nnvs]. nev->ixy  "bu; 			or PATH		=s[i]pnvy  "bu 		n n;		 	nnvy  (ge is.or{
 		 nev->ixy  "bue->BG(_UPmerk3eSDeom 
ntvae;
	 {i	)
	remembd = at prerti ma oval
*/-	ww[g- nev 			bt&forF_FLOAT,	fprin	fs at	0	-=gpo y >h3{
		nxfs at	1	-=gpo y >yelse i>ix3 !=m
	==i	s at	0	-=gpo y ih3{
		nxis at	1	-=gpo y iyelse i		
						t {
	revaserteg tm,		ebackwards[.r%d ab=s[		) t cur is nsgcur ! f0;scur is "bue,	fprin	 "bue->cury  "bu; 			y2+addgeaftd () willvscrew
ibsup b=s				[g-cury  			bt&forF_FLOAT,	fprin	k) t SDBG(SU2)) {
		fprinns	)
	re->fs->gh; di*/
			f=om id= >elemeal ;
	lu		d	fe->cury > ovalu
			0r;	lu		 ecury > ovalu
			0re->cury > ovalu
			1r;	lu		 ecury > ovalu
			1	-=gf;	lu		d	fe->fs at	ir;	lu		 efs at	ire->cury > ovalu
			2r;	lu		 ecury > ovalu
			2	-=gf;	lu		ds[				}ix3 !=fprin	k) t SDBG(SU2)) {
		fprinns	)
	re->fs->gh; di*/
			f=om id= >elemeal ;
	lu		d	ne->cury i ovalu
			0r;	lu		 ecury i ovalu
			0re->cury i ovalu
			1r;	lu		 ecury i ovalu
			1	-=gr;	lurrrrne->is at	ir;	lu		 eis at	ire->cury i ovalu
			2r;	lu		 ecury i ovalu
			2r-=gn	if(w		s[				}r	 +=addgeaftd (p nfocur)lse i		
						rest te-1; jprerti ma oval
*/-	ww[g- nev 			bt&forF_FLOAT,	fprin	po y >h3e->fs at	0r;	lu		po y >yee->fs at	1r;	lu	}ix3 !=fprin	po y ih3e->is at	0r;	lu		po y iye[= is at	1r;	lu	}[
  	de 		n n;		 }[
 }	}n s=malbe->fs-id= m(
	     = gssen g
) * 	be->fs-id= mte;
to(g		in		stg,sNULL,;g=abs(sadd a kera< mapair-ing rm	/* i,;s>al
sogh; _UP |egp[is=maladdkerapair( arigin) 
	id1e
	rigin) 
	id2,
 valerigc_UP
) * 	]+=rexprigin) 
	
ntal*bits-=g,
	 ]+=rexpval s atidpr r gsse*M ->&-path_lipr[id1];
=the l, a
	 ]+ructjkera  p %	e	rerigc_UPv			0 || id1[>= numgpaths || id2[>= numgpaths)1 ?better %	e	re (	path_lipr[id1]. 			bt&foF_USED,==0
e||s(	path_lipr[id2]. 			bt&foF_USED,==0 )1 ?better %	e	rebits-=		0the	lubits-=gc1llot( BITMAP_BYTES(numgpaths), 1	a])r	r ebits-=		NULL,	fprie)ntf(st  err, "**** **mallotgfnileE
		 *rp+1% alue __FILE__e __ ge-__flse  xxit(255	a])	}r	 s atid[= id1;ar}a
 	r(s atid[!= id1,	fpri			refill[tat bitmapgc1cat */-	wmemsetsbits, 0,BITMAP_BYTES(numgpaths)	a])	ps]. 		keraa])	) t SD 		keracnuSt)) >BG(S--,	m
	==n =g(p{
	y idpr  	SET_BITMAPsbits, n	a])	}r	 s atid[= id1;ar}a
 	r(IS_BITMAPsbits, iE2
)1 ?better  			duplithtee;
	 {	}
g		keracnuSt[<=  		keraallot		fpri-->keraallot +->8a])	ps].P-1llot(-->kerails		 of(]+ructjkera,	/* 		keraallot	a])r	r(pv			0the	lu	)ntf(st  err, "**** .P-1llotgfnileE, kera< madatagwillvbstincemplete);
			ex}pri-->kera-=gp;ar}a
 SET_BITMAPsbits, iE2
;arp ->&-->kera[g		keracnuSt];
=py id[= id2;
=py _UPv	gis>al

rigc_UP) - ( 		s>al
dwid=  -o 		oltwid= 
;arg		keracnuSt++;[	kera< m_pairs++;[=abs(sntf(s . */1; jkera< maing rm	/* i,gp[is=malntf(s_kera< m( aFILE *afm_file-) * athe	i,oj, n; ar gsse*M;))]+ructjkera  p %	e	re kera< m_pairsv			0 ) 
		better %	e)ntf(st afm_file* "SrertKeraData);
			e)ntf(st afm_file* "SrertKeraPairsv%h alue kera< m_pairs);	
	t t SDBG(SUnumgpaths)) {
)  	breM ->&-path_lipr[i];pri	r( ed-> 			bt&foF_USED,	-=0)	lu	elevant bo	rps]. 		keraa])	) t jD 		keracnuSt))j>BG(j--, p{
		fprie)ntf(st afm_file* "KPXe		 %	 % alue g		h-2)fo	lu		-path_lipr[ py id[].h-2)fopy _UPv			ex}pr}%	e)ntf(st afm_file* "EndKeraPairs);
			e)ntf(st afm_file* "EndKeraData);
			}%		#im 0	p]; * .Tlig	fun
			f=lse ommealeE
. */be>ausee ansing rm	/* i * .coll/
	ed=by ilglsesho*u	s
	anywhelsex3 !=yet. NhwP*d i  only.coll/
	s>gh; di*/
			fs[.fr>nvsour	. And  atP*d di*/
			f=om >nvsour	 getg	fixs
	alP-1dy,		edraw_gpaf().P*d
***********************************************P*d
** Helsewsexxp/
	+		i]-1; jid= m=]lsealP-1dy, loZOd.P*d W gilso-xxp/
	+		i]-1; j>nvsour	 dtosho*intebs/
	P*d ants ai]-om = vsEMesn't cross			ygb.r%d =om qu	drlal.P*d
**-Fintswhis,
>nvsour	 go*ino=%dswhis,
antswhi]-ls
**- atirLpropes;di*/
			f. Tl;n	fix>gh; di*/
			f
**- ifme {
ibsrimet.P*d
*p[i#,efpre MAXCONT	1000[is=malfix>nvsour	(
	    = gssen g
) * 	CONTOUR         >nvs[MAXCONT];
=]horteeeeeeeeeeeym<x[MAXCONT];;			 at higt at  ovalgb=s[]horteeeeeeeeeeexofm<x[MAXCONT];;			X-co.r%inhtee.fr 	yg oval
lu		 e 			teym<xgb=s[]horteeeeeeeeeeeymva[MAXCONT];;			 at loweate ovalgb=s[]horteeeeeeeeeeexofmva[MAXCONT];;			X-co.r%inhtee.fr 	yg oval
lu		 e 			teymvae;
	l]horteeeeeeeeeeecnuSt[MAXCONT];;			cnuSteom sames[nr] 
ntal           di*[MAXCONT];;			va whis,
di*/
			f= aty muatego*nr] GEay.
         *prert[MAXCONT], *mvaptr[MAXCONT], *maxptr[MAXCONT];
=the             n
nvs;
=the             i;
=the             dh1e dy1e dh2e dy2{
	GEay.
         *M       ;g
=)
	hints at >nvsour	 ants atirL ost[upper/lower	povalsob=ssn
nvs-=g,
	 ym<x[0	 d h5000;
	ymva[0]
 s5000;
 t t (		s]. 		in		stg; orv! f0;s ns]. nev "bu)	fpri	} ed of curve for  ge- ||  nm
			Wve for a nots	fprin	r e ny iye[> ym<x[n
nvs]		fpri
cym<x[n
nvs]
 s reviyelse iexofm<x[n
nvs]
 s revih3{
		nxmaxptr[n
nvs]
 s r;e	
				 		r e ny iye[< ymva[n
nvs]		fpri
cymva[n
nvs]
 s reviyelse iexofmva[n
nvs]
 s revih3{
		nxmvaptr[n
nvs]
 s r;e	
				 }pri	} ed of>rixv!]. nev "bu)	fpri	prert[n
nvs++]
 s rev>> vs[	= ym<x[n
nvs]
 s-5000;
  	ymva[n
nvs]
 s5000;
  }ar}a
 ed ,etd mvae>gh; di*/
			fs[.fr>nvsour	+b=sst t (Se->BG(S < n
nvs;) {
		fpri ns].mvaptr[i];prinnvs]. nev > vs[
b=	r ed of curve for a nots	fprindh1{
	 !->ix3[-U ny ih2;
  	dy1
 s reviye[-U !->iy2a]
	==	r edh1{
 f0  gedy1
 		0theied a pd= ologicUPvcasns;
	lu		dh1{
	 !->ix3[-U ny ih1	if(w	dy1
 s reviye[-U !->iy1;e	
				 		r edh1{
 f0  gedy1
 		0theied a m te-pd= ologicUP
lu		 e;			easns;
	lu		dh1{
	 !->ix3[-U ny  (ge->ih3{
		n	dy1
 s reviye[-U !-> (ge->iyelse i			 }ix3 !=fprindh1{
	 !->ix3[-U ny  (ge->ih3{
		ndy1
 s reviye[-U !-> (ge->iyelse }pri	} end of curve for a nots	fprindh2{
	 !->ix3[-Un ny ih1	if(wdy2
 s reviye[-Un !->iy1;e	
		r edh1{
 f0  gedy1
 		0theied a pd= ologicUPvcasns;
	lu		dh2{
	 !->ix3[-Un ny ih2{
		n	dy2
 s reviye[-Un !->iy2;e	
				 		r edh1{
 f0  gedy1
 		0theied a m te-pd= ologicUP
lu		 e;			easns;
	lu		dh2{
	 !->ix3[-Un ny ih3{
		n	dy2
 s reviye[-Un !->iyelse i			 }ix3 !=fprindh2{
	 !->ix3[-Un ny ih3{
		ndy2
 s reviye[-Un !->iyelse }[
  			cnmp]lspangnys;b=s		>nvs[i]., */
			f=ifDIR_INNERa])r	r edy1
 		0the		 		r edh1{<f0	
=s	x>nvs[i]., */
			f=ifDIR_OUTER;		 }ix3 !=	r edy2
 		0the		 		r edh2 >f0	
=s	x>nvs[i]., */
			f=ifDIR_OUTER;		 }ix3 !=	r edh2 *edy1
< dh1 *edy2)	lu	elev[i]., */
			f=ifDIR_OUTER;	s		>nvs[i].ymva	->ymva[i];pri>nvs[i].xofmva	->xofmva[i];ar}a
 ed st= gghe ing rm	/* i, 	i]-meyvbstnes
s
	tur atreb=s	g		h>nvsour	 		n
nvs;
=t} en
nvs->	0the		 g		>nvsour	s=  <llot(s		 of(CONTOUR,	/*n
nvs	a])r	r eg		>nvsour	s=		0the	lu	)ntf(st err, "**** *** Mem ty=]llotht* i,, " t ** **);
			exxxxit(255	a])	}r	 memcpyeg		>nvsour	,r>nvsils		 of(CONTOUR,	/*n
nvs	a])}	}n #eSD<fg
]; i-	egp[i                                                                                                                                                                                                             