### RE-ACCREDITATION ###
/* SQL for HEQC-online planning spreadsheet: HEQC-online planning v4 yyyy-mm-dd.xlsx
	This spreadsheet summarises number of open processes per process, letters loaded and calculates age of processes.
    2. Open and Save report to new date.
	1. Update base date in SQL.  Run SQL
    3. Copy and paste results to Data worksheet table.  Make sure it is part of the table.  
    4. Go to the Data worksheet.  Sort by HEQC_start_date. Set all blank values to format Short date (they will be on format General).
		This is so that the 'Group' fields e.g. Age category are calculated correctly and don't defalt to full date values.
    4. Refresh all graphs and pivot tables
    5. Open last HEQC-online planning and letters loaded.docx and save to new date
    6. Search and replace dates to new dates. Copy and paste tables to the report.
/* Data for PLANNING, post AND age report - NEW */
/* Data for PLANNING, post AND age report - NEW */

SELECT '2023-06-09' AS base_date, Institutions_application_reaccreditation.reacc_submission_date, 
	ia_proceedings.submission_date AS proc_submission_date, screened_date,
	DATEDIFF('2023-06-09', Institutions_application_reaccreditation.reacc_submission_date) AS diff_orig_submission, 
	IF (DATEDIFF('2023-06-09', Institutions_application_reaccreditation.reacc_submission_date) < 91, 'Current',
	IF (DATEDIFF('2023-06-09', Institutions_application_reaccreditation.reacc_submission_date) BETWEEN 92 AND 182, '3-6 months',
	IF (DATEDIFF('2023-06-09', Institutions_application_reaccreditation.reacc_submission_date) BETWEEN 183 AND 273, '7-9 months',
	IF (DATEDIFF('2023-06-09', Institutions_application_reaccreditation.reacc_submission_date) BETWEEN 274 AND 365, '10-12 months',
	IF (DATEDIFF('2023-06-09', Institutions_application_reaccreditation.reacc_submission_date) BETWEEN 366 AND 457, '13-15 months',
	IF (DATEDIFF('2023-06-09', Institutions_application_reaccreditation.reacc_submission_date) > 457, '> 15 months', 'Undefined')))))) AS age_orig_submission,
    (SELECT count(*) FROM ia_proceedings WHERE reaccreditation_application_ref = Institutions_application_reaccreditation.reacc_submission_date) AS nr_proceedings,
	IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date) AS calc_submission_date, 
      DATEDIFF('2023-06-09', IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
			IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date), 
                ia_proceedings.screened_date)) AS diff_screening, 
			IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) < 91, 'Current', 
		IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 92 AND 182, '4-6 months',	 
		IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 183 AND 273, '7-9 months',	 
		IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 274 AND 365, '10-12 months',	 
		IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 366 AND 457, '13-15 months',	 
		IF(DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date), 
                ia_proceedings.screened_date)) > 457, '> 15 months', 'Undefined')))))) AS age_screening,
	lkp_proceedings_desc,  
	users.name, users.email, processes.processes_desc, IF(processes.processes_id = 170, 'Wait response', 'In process') AS in_process_status,
    CONCAT(LPAD(CAST(processes_id AS CHAR),4,'0'),' ',processes.processes_desc) AS processes_com, 
	HEI_name, 	IF(priv_publ = 1, 'Private', 
		IF(hei_code='H01' OR hei_code='H03' OR hei_code='H04' OR hei_code='H25' OR hei_code='H18' OR hei_code='H16', 'UoT', 
			IF(hei_code='H07' OR hei_code='H10' OR hei_code='H17' OR hei_code='H19' OR hei_code='H22','Comprehensive',
				IF(hei_code='H14','UNISA','Research')))) AS inst_catg, 
	Institutions_application_reaccreditation.referenceNumber, programme_name, processes.processes_id, 
    is_reg_saqa_nqf, saqa_appl_date, saqa_reg_date, saqa_reg_nr, saqa_registration_certificate_doc,
    recomm_user_ref, recomm_doc, recomm_access_end_date,  
    AC_Meeting.ac_start_date, ac_decision.lkp_title AS ac_outcome, heqc_start_date, 
	heqc_decision.lkp_title as heqc_outcome, heqc_outcome_approved_date, ia_proceedings.decision_doc, heqc_decision_due_date,
	conditions_submission_date, ia_proceedings.condition_doc, 
	ia_proceedings.condition_prior_due_date, ia_proceedings.condition_short_due_date, ia_proceedings.condition_long_due_date, 
	ia_proceedings.representation_doc, ia_proceedings.deferral_doc, 
	finind_complete_25, finind_complete_50, finind_complete_75, finind_complete_100, 
    tmp_aps.active_processes_id, tmp_aps.last_updated
FROM (tmp_aps, processes)
LEFT JOIN users ON users.user_id = tmp_aps.user_ref
LEFT JOIN ia_proceedings ON ia_proceedings.ia_proceedings_id = tmp_aps.ia_proceedings_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN Institutions_application_reaccreditation ON Institutions_application_reaccreditation_id = tmp_aps.reacc_applic_id
LEFT JOIN HEInstitution ON Institutions_application_reaccreditation.institution_ref = HEInstitution.HEI_id
LEFT JOIN AC_Meeting ON ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id
LEFT JOIN HEQC_Meeting ON ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id
LEFT JOIN lkp_desicion AS ac_decision ON  ac_decision.lkp_id = ia_proceedings.ac_decision_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
WHERE processes.processes_id = tmp_aps.processes_ref
AND tmp_aps.status = 0
AND users.institution_ref = 2
AND lkp_proceedings_ref > 4 
AND processes_id NOT IN (4, 9, 10, 41, 52, 57, 92, 100, 103, 105, 107, 120, 145, 146, 147, 150, 153, 157, 158, 164,  109, 102, 166, 154, 69, 183, 95, 19, 197, 172,
175, 176, 177, 178, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 202, 204, 208 )
ORDER BY active_processes_id;


-- Monitoring report proceedings v9
-- Open and save proceedings xlsx
-- Run SQL. Copy and paste to Proceedings Data Worksheet
-- 

SELECT IF(lkp_proceedings_desc IS NULL, IF(referenceNumber LIKE '%HEQSF%', 'Application for HEQSF-alignment','Application for programme accreditation'), lkp_proceedings_desc) AS proceeding_type, 
		HEI_name, IF(priv_publ = 1, 'Private','Public') AS inst_type,
		IF(priv_publ = 1, 'Private', 
		IF(hei_code='H01' OR hei_code='H03' OR hei_code='H04' OR hei_code='H25' OR hei_code='H18' OR hei_code='H16', 'UoT', 
			IF(hei_code='H07' OR hei_code='H10' OR hei_code='H17' OR hei_code='H19' OR hei_code='H22','Comprehensive',
				IF(hei_code='H14','UNISA','Research')))) AS inst_catg, 
	IF(ia_proceedings.submission_date IS NULL, Institutions_application_reaccreditation.reacc_submission_date, ia_proceedings.submission_date) AS submission_date, 
    Institutions_application_reaccreditation.referenceNumber, programme_name, screened_date, 
    CONCAT(recomm.name," ", recomm.surname) AS recomm_writer, recomm_doc, recomm_access_end_date, 
    AC_Meeting.ac_start_date, ac_decision.lkp_title AS ac_decision, heqc_start_date, 
	heqc_decision.lkp_title as heqc_decision, heqc_outcome_approved_date, ia_proceedings.decision_doc, saqa_reg_date, saqa_reg_nr, heqc_decision_due_date,
	conditions_submission_date, ia_proceedings.condition_doc, 
	ia_proceedings.condition_prior_due_date, ia_proceedings.condition_short_due_date, ia_proceedings.condition_long_due_date, 
	ia_proceedings.representation_doc, ia_proceedings.deferral_doc, 
	finind_complete_25, finind_complete_50, finind_complete_75, finind_complete_100, proceeding_status_date, 
    IF(referenceNumber LIKE '%HEQSF%', 'HEQSF application','HEQC application') AS heqc_heqsf, 
    HEI_id, Institutions_application_reaccreditation_id, ia_proceedings_id, recomm_user_ref
FROM Institutions_application_reaccreditation
LEFT JOIN ia_proceedings ON ia_proceedings.reaccreditation_application_ref = Institutions_application_reaccreditation_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN HEInstitution ON Institutions_application_reaccreditation.institution_ref = HEInstitution.HEI_id
LEFT JOIN users AS recomm ON user_id = recomm_user_ref
LEFT JOIN AC_Meeting ON ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id
LEFT JOIN HEQC_Meeting ON ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id
LEFT JOIN lkp_desicion AS ac_decision ON  ac_decision.lkp_id = ia_proceedings.ac_decision_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
WHERE (lkp_proceedings.lkp_proceedings_id IN (5,6,7,8,9))
ORDER BY HEI_name, programme_name;

#WHERE Institutions_application.submission_date > '1000-01-01'


#. Reaccreditation Recommendation writer's report


SELECT IF(lkp_proceedings_desc IS NULL, IF(Institutions_application.CHE_reference_code LIKE '%HEQSF%', 'Application for HEQSF-alignment','Application for programme accreditation'), 
lkp_proceedings_desc) AS Proceeding_Type, 
IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date) AS submission_date, HEI_name, Program_name,
    Institutions_application.CHE_reference_code, 
    IF(priv_publ = 1, 'Private','Public') AS inst_type , lkp_qualification_type_desc, 
    recomm_user_ref, CONCAT(recomm.name," ", recomm.surname) AS recomm_writer, email,recomm_doc, portal_sent_date, recomm_access_end_date, recomm_approve_comment, recomm_complete_ind ,screened_date, 
     AC_Meeting.ac_start_date, heqc_start_date, proceeding_status_date, processes_desc, tmp_aps.name AS who_currently_has_the_process , tmp_aps.last_updated , status
FROM Institutions_application
LEFT JOIN ia_proceedings ON ia_proceedings.application_ref = Institutions_application.application_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = qualification_type_ref
LEFT JOIN users AS recomm ON user_id = recomm_user_ref
LEFT JOIN AC_Meeting ON ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id
LEFT JOIN HEQC_Meeting ON ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id
LEFT JOIN lkp_desicion AS ac_decision ON  ac_decision.lkp_id = ia_proceedings.ac_decision_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
LEFT JOIN SpecialisationCESM_code1 ON SpecialisationCESM_code1.CESM_code1 = Institutions_application.CESM_code1
LEFT JOIN tmp_aps ON Institutions_application.application_id = tmp_aps.application_id 
WHERE Institutions_application.submission_date > '2009-01-01'
AND (lkp_proceedings.lkp_proceedings_id IS NULL OR lkp_proceedings.lkp_proceedings_id NOT IN (1,2,3,4))
AND Institutions_application.CHE_reference_code NOT LIKE '%HEQSF%'
AND recomm_user_ref > 1
AND status = 1
ORDER BY submission_date DESC;


