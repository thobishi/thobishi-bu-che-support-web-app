
# Site visits 


SELECT HEI_code, HEI_name, site_application_no, 
 (SELECT GROUP_CONCAT(processes.processes_desc,'') FROM processes, tmp_aps 
		WHERE status = 0 AND processes.processes_id = tmp_aps.processes_ref AND inst_site_application.inst_site_app_id = tmp_aps.inst_site_app_id
		GROUP BY tmp_aps.inst_site_app_id
		) AS in_process,
 (SELECT GROUP_CONCAT(users.email,'') FROM users, tmp_aps 
		WHERE status = 0 AND users.user_id = tmp_aps.user_ref AND inst_site_application.inst_site_app_id = tmp_aps.inst_site_app_id
		GROUP BY tmp_aps.inst_site_app_id
		) AS in_process_user,
 (SELECT GROUP_CONCAT(last_updated,'') FROM tmp_aps 
		WHERE status = 0 AND inst_site_application.inst_site_app_id = tmp_aps.inst_site_app_id
		GROUP BY tmp_aps.inst_site_app_id
		) AS in_process_last_updated,
recomm_users.email AS recomm_email, lop_isSent_date, portal_sent_date, recomm_access_end_date, 
applic_background, eval_report_summary, recomm_approve_comment, recomm_doc, AC_Meeting.ac_start_date, HEQC_Meeting.heqc_start_date, 
applic_background_ac, eval_report_summary_ac, applic_background_heqc, eval_report_summary_heqc, minutes_discussion, heqc_minutes_discussion, 
decision_doc, heqc_decision_due_date, evaluator_access_end_date, eval_complete_ind, manager_evalreport_comment, 
inst_site_app_id, inst_site_app_proc_id
FROM (inst_site_application, HEInstitution)
LEFT JOIN inst_site_app_proceedings ON inst_site_app_ref = inst_site_application.inst_site_app_id
LEFT JOIN users AS recomm_users ON recomm_users.user_id = inst_site_app_proceedings.recomm_user_ref
LEFT JOIN AC_Meeting ON ac_id = inst_site_app_proceedings.ac_meeting_ref
LEFT JOIN HEQC_Meeting ON heqc_id = inst_site_app_proceedings.heqc_meeting_ref
WHERE inst_site_application.institution_ref = HEInstitution.HEI_id
AND (siteapp_doc IS NULL)
ORDER BY HEI_name;


# Site Extensions and relocations


SELECT HEI_code, HEI_name, siteapp_doc, submition_date, app_type, site_application_no,  
(SELECT GROUP_CONCAT(processes.processes_desc,'') FROM processes, tmp_aps 
		WHERE status = 0 AND processes.processes_id = tmp_aps.processes_ref AND inst_site_application.inst_site_app_id = tmp_aps.inst_site_app_id
		GROUP BY tmp_aps.inst_site_app_id
		) AS in_process,
 (SELECT GROUP_CONCAT(users.email,'') FROM users, tmp_aps 
		WHERE status = 0 AND users.user_id = tmp_aps.user_ref AND inst_site_application.inst_site_app_id = tmp_aps.inst_site_app_id
		GROUP BY tmp_aps.inst_site_app_id
		) AS in_process_user,
 (SELECT GROUP_CONCAT(last_updated,'') FROM tmp_aps 
		WHERE status = 0 AND inst_site_application.inst_site_app_id = tmp_aps.inst_site_app_id
		GROUP BY tmp_aps.inst_site_app_id
		) AS in_process_last_updated,
recomm_users.email AS recomm_email, lop_isSent_date, portal_sent_date, recomm_access_end_date, 
applic_background, eval_report_summary, recomm_approve_comment, recomm_doc, AC_Meeting.ac_start_date, HEQC_Meeting.heqc_start_date, 
applic_background_ac, eval_report_summary_ac, applic_background_heqc, eval_report_summary_heqc, minutes_discussion, heqc_minutes_discussion, 
decision_doc, heqc_decision_due_date, evaluator_access_end_date, eval_complete_ind, manager_evalreport_comment, 
inst_site_app_id, inst_site_app_proc_id
FROM (inst_site_application, HEInstitution)
LEFT JOIN inst_site_app_proceedings ON inst_site_app_ref = inst_site_application.inst_site_app_id
LEFT JOIN users AS recomm_users ON recomm_users.user_id = inst_site_app_proceedings.recomm_user_ref
LEFT JOIN AC_Meeting ON ac_id = inst_site_app_proceedings.ac_meeting_ref
LEFT JOIN HEQC_Meeting ON heqc_id = inst_site_app_proceedings.heqc_meeting_ref
WHERE inst_site_application.institution_ref = HEInstitution.HEI_id
AND (siteapp_doc > 0);