/* SQL for HEQC-online planning spreadsheet: HEQC-online planning yyyy-mm-dd.xlsx
	This spreadsheet summarises number of open processes per process, letters loaded and calculates age of processes.
    2. Open and Save report to new date.
	1. Update base date in SQL.  Run SQL
    3. Copy and paste results to Data worksheet table.  Make sure it is part of the table.  
    4. Go to the Data worksheet.  Sort by HEQC_start_date. Set all blank values to format Short date (they will be on format General).
		This is so that the 'Group' fields e.g. Age category are calculated correctly and don't defalt to full date values.
    4. Refresh all graphs and pivot tables
    5. Open last HEQC-online planning and letters loaded.docx and save to new date
    6. Search and replace dates to new dates. Copy and paste tables to the report.
*/
    
# SQL 1: Paste data from the following SQL to FILE: HEQC-online planning yyyy-mm-dd.xlsx WORKSHEET: Data 
SELECT '2023-06-09' AS base_date, Institutions_application.submission_date, 0 AS institution_replacement_ind,
	ia_proceedings.submission_date AS proc_submission_date, screened_date,
	DATEDIFF('2023-06-09', Institutions_application.submission_date) AS diff_orig_submission, 
	IF (DATEDIFF('2023-06-09', Institutions_application.submission_date) < 91, 'Current',
	IF (DATEDIFF('2023-06-09', Institutions_application.submission_date) BETWEEN 92 AND 182, '3-6 months',
	IF (DATEDIFF('2023-06-09', Institutions_application.submission_date) BETWEEN 183 AND 273, '7-9 months',
	IF (DATEDIFF('2023-06-09', Institutions_application.submission_date) BETWEEN 274 AND 365, '10-12 months',
	IF (DATEDIFF('2023-06-09', Institutions_application.submission_date) BETWEEN 366 AND 457, '13-15 months',
	IF (DATEDIFF('2023-06-09', Institutions_application.submission_date) > 457, '> 15 months', 'Undefined')))))) AS age_orig_submission,
    (SELECT count(*) FROM ia_proceedings WHERE application_ref = Institutions_application.application_id) AS nr_proceedings,
	IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date) AS calc_submission_date, 
      DATEDIFF('2023-06-09', IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
			IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
                ia_proceedings.screened_date)) AS diff_screening, 
			IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) < 91, 'Current', 
		IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 92 AND 182, '4-6 months',	 
		IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 183 AND 273, '7-9 months',	 
		IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 274 AND 365, '10-12 months',	 
		IF (DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 366 AND 457, '13-15 months',	 
		IF(DATEDIFF('2023-06-09', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
                ia_proceedings.screened_date)) > 457, '> 15 months', 'Undefined')))))) AS age_screening,
	lkp_proceedings_desc,  
	users.name, users.email, processes.processes_desc, IF(processes.processes_id = 170, 'Wait response', 'In process') AS in_process_status,
    CONCAT(LPAD(CAST(processes_id AS CHAR),4,'0'),' ',processes.processes_desc) AS processes_com, 
	Institutions_application.CHE_reference_code, program_name, processes.processes_id, 
	HEI_name, 	IF(priv_publ = 1, 'Private', 
		IF(hei_code='H01' OR hei_code='H03' OR hei_code='H04' OR hei_code='H25' OR hei_code='H18' OR hei_code='H16', 'UoT', 
			IF(hei_code='H07' OR hei_code='H10' OR hei_code='H17' OR hei_code='H19' OR hei_code='H22','Comprehensive',
				IF(hei_code='H14','UNISA','Research')))) AS inst_catg, 
    SpecialisationCESM_code1.Description AS CESM_code1_descr, cesm2.Description AS CESM_level2, 
    cesm3.Description AS CESM_level3, lkp_qualification_type_desc,
    recomm_user_ref, recomm_doc, recomm_access_end_date,  
    AC_Meeting.ac_start_date, ac_decision.lkp_title AS ac_outcome, heqc_start_date, 
	heqc_decision.lkp_title as heqc_outcome, heqc_outcome_approved_date, ia_proceedings.decision_doc, heqc_decision_due_date,
	conditions_submission_date, ia_proceedings.condition_doc, 
	ia_proceedings.condition_prior_due_date, ia_proceedings.condition_short_due_date, ia_proceedings.condition_long_due_date, 
	ia_proceedings.representation_doc, ia_proceedings.deferral_doc, 
	finind_complete_25, finind_complete_50, finind_complete_75, finind_complete_100, 
    tmp_aps.active_processes_id, tmp_aps.last_updated
FROM (tmp_aps, processes)
LEFT JOIN users ON users.user_id = tmp_aps.user_ref
LEFT JOIN ia_proceedings ON ia_proceedings.ia_proceedings_id = tmp_aps.ia_proceedings_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN Institutions_application ON Institutions_application.application_id = tmp_aps.application_id
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN AC_Meeting ON ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id
LEFT JOIN HEQC_Meeting ON ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id
LEFT JOIN lkp_desicion AS ac_decision ON  ac_decision.lkp_id = ia_proceedings.ac_decision_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
LEFT JOIN SpecialisationCESM_code1 ON SpecialisationCESM_code1.CESM_code1 = Institutions_application.CESM_code1
LEFT JOIN SpecialisationCESM_qualifiers AS cesm2 ON cesm2.SpecialisationCESM_qualifiers_id = CESM_level2_ref
LEFT JOIN SpecialisationCESM_qualifiers AS cesm3 ON cesm3.SpecialisationCESM_qualifiers_id = CESM_level3_ref
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
WHERE processes.processes_id = tmp_aps.processes_ref
AND tmp_aps.status = 0
AND users.institution_ref = 2
AND processes_id NOT IN (4, 9, 10, 17, 23, 41, 45, 52, 57, 92, 100, 103, 105, 107, 108 ,120, 145, 146, 147, 150, 153, 156, 157, 158, 164,  109, 102, 166, 154, 69, 183, 95, 19, 197, 172,
175, 176, 177, 178, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 202, 204, 205, 208 )
ORDER BY active_processes_id
AND  Institutions_application.submission_date ASC;

-- Monitoring report proceedings
-- Open and save heqc_online_proceedings....xlsx
-- Run SQL. Copy and paste to Proceedings Data Worksheet
-- 2019-12 New proceedings code added 9 Site visit linked to re-accreditation

# SQL 2: Paste data from the following SQL to FILE: HEQC-online proceedings yyyy-mm-dd.xlsx WORKSHEET: Proceedings Data *
SELECT IF(lkp_proceedings_desc IS NULL, IF(CHE_reference_code LIKE '%HEQSF%', 'Application for HEQSF-alignment','Application for programme accreditation'), lkp_proceedings_desc), 
	IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date) AS submission_date, 
    Institutions_application.CHE_reference_code, program_name, 
	HEI_name, IF(priv_publ = 1, 'Private','Public') AS inst_type,
		IF(priv_publ = 1, 'Private', 
		IF(hei_code='H01' OR hei_code='H03' OR hei_code='H04' OR hei_code='H25' OR hei_code='H18' OR hei_code='H16', 'UoT', 
			IF(hei_code='H07' OR hei_code='H10' OR hei_code='H17' OR hei_code='H19' OR hei_code='H22','Comprehensive',
				IF(hei_code='H14','UNISA','Research')))) AS inst_catg, SpecialisationCESM_code1.Description AS CESM_code1_descr, CESM_level2_ref, 
    CESM_level3_ref, lkp_qualification_type_desc, 
    recomm_user_ref, CONCAT(recomm.name," ", recomm.surname) AS recomm_writer, recomm_doc, recomm_access_end_date, screened_date, 
     AC_Meeting.ac_start_date, ac_decision.lkp_title, heqc_start_date, 
	heqc_decision.lkp_title, heqc_outcome_approved_date, ia_proceedings.decision_doc, heqc_decision_due_date,
	conditions_submission_date, ia_proceedings.condition_doc, 
	ia_proceedings.condition_prior_due_date, ia_proceedings.condition_short_due_date, ia_proceedings.condition_long_due_date, 
	ia_proceedings.representation_doc, ia_proceedings.deferral_doc, 
	finind_complete_25, finind_complete_50, finind_complete_75, finind_complete_100, proceeding_status_date, 
    IF(CHE_reference_code LIKE '%HEQSF%', 'HEQSF application','HEQC application') AS heqc_heqsf
FROM Institutions_application 
LEFT JOIN ia_proceedings ON ia_proceedings.application_ref = Institutions_application.application_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = qualification_type_ref
LEFT JOIN users AS recomm ON user_id = recomm_user_ref
LEFT JOIN AC_Meeting ON ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id
LEFT JOIN HEQC_Meeting ON ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id
LEFT JOIN lkp_desicion AS ac_decision ON  ac_decision.lkp_id = ia_proceedings.ac_decision_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
LEFT JOIN SpecialisationCESM_code1 ON SpecialisationCESM_code1.CESM_code1 = Institutions_application.CESM_code1
WHERE Institutions_application.submission_date > '1000-01-01'
AND (lkp_proceedings.lkp_proceedings_id IS NULL OR lkp_proceedings.lkp_proceedings_id NOT IN (5,6,7,8,9))
AND CHE_reference_code NOT LIKE '%HEQSF%';

#
# Supporting reports for Planning worksheet.  Lists programme detail to assist administrators to manage their portfolios
#
#

# SQL 3.1 Proceedings are Columns
# SQL 3.1: Paste data from the following SQL to FILE: HEQC-online reports yyyy-mm-dd.xlsx WORKSHEET: Programmes in Process

SELECT HEI_name, Institutions_application.CHE_reference_code, program_name, lkp_mode_of_delivery_desc, 
   	Institutions_application.submission_date,
    IF(Institutions_application.submission_date = '1000-01-01' OR Institutions_application.submission_date IS NULL, '4 Not submitted', 
    IF(Institutions_application.submission_date <= '2018-03-31', '1 Prior 31 March', 
    IF(Institutions_application.submission_date BETWEEN '2018-04-01' AND '2018-05-31', '2 Prior 31 May 2018', 
		'3 After 31 May 2018'))) AS submission_status,  
    AC_Meeting_date AS final_outcome_date,
	(SELECT lkp_title FROM lkp_desicion WHERE lkp_id = Institutions_application.AC_desision) AS final_outcome,   
    (SELECT AC_Meeting.ac_start_date FROM AC_Meeting, ia_proceedings WHERE ia_proceedings.ac_meeting_ref > 0 AND ac_decision_ref > 0 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_ac_date,
 	(SELECT lkp_title FROM lkp_desicion, ia_proceedings WHERE ia_proceedings.ac_meeting_ref > 0 AND ac_decision_ref > 0 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_ac_outcome,
    (SELECT heqc_start_date FROM HEQC_Meeting, ia_proceedings WHERE ia_proceedings.heqc_meeting_ref > 0 AND ia_proceedings.heqc_board_decision_ref > 0 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_heqc_date,
	(SELECT lkp_title FROM lkp_desicion, ia_proceedings WHERE ia_proceedings.heqc_meeting_ref > 0 AND ia_proceedings.heqc_board_decision_ref > 0 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_heqc_outcome,
 (SELECT GROUP_CONCAT(processes.processes_desc,'') FROM processes, tmp_aps 
		WHERE status = 0 AND processes.processes_id = tmp_aps.processes_ref AND processes_ref NOT IN (4, 9, 10, 41, 52, 57, 92, 100, 103, 105, 107, 108 ,120, 145, 146, 147, 150, 153, 157, 158, 164,  109, 102, 166, 154, 69, 183, 95, 19, 197, 172,
175, 176, 177, 178, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 202, 204, 208 ) AND Institutions_application.application_id = tmp_aps.application_id
		GROUP BY tmp_aps.application_id
		) AS in_process,
  (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 1 AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_recomm_appoint,
    (SELECT max(AC_Meeting.ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_ac_outcome,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_ac_outcome,
	(SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_ac_outcome,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_ac_outcome,
	(SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_heqc_outcome,
	Institutions_application.application_id 
FROM (tmp_aps, processes)
LEFT JOIN Institutions_application ON Institutions_application.application_id = tmp_aps.application_id
LEFT JOIN users ON users.user_id = tmp_aps.user_ref
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
LEFT JOIN lkp_mode_of_delivery ON lkp_mode_of_delivery_id = Institutions_application.mode_delivery
WHERE processes.processes_id = tmp_aps.processes_ref
AND (tmp_aps.status = 0 AND users.institution_ref = 2)
AND (tmp_aps.ia_proceedings_id IN (SELECT ia_proceedings_id FROM ia_proceedings WHERE ia_proceedings.lkp_proceedings_ref IN (1,2,3,4) OR ia_proceedings.lkp_proceedings_ref IS NULL))
AND Institutions_application.submission_date > '1000-01-01'
AND processes_id NOT IN (4, 9, 10, 17, 23, 41, 52, 56, 57, 92, 100, 103, 105, 107, 108 , 120, 145, 146, 147, 150, 153, 157, 158, 164,  109, 102, 166, 154, 69, 183, 95, 19, 197, 172,
175, 176, 177, 178, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 202, 204, 208 )
ORDER BY HEI_name, program_name;

# Backgrounds Currently unused in monitoring reports - Will re-add if requested
# SQL 3.2. All Backgrounds report that can be used to add onto previous backgrounds

SELECT HEI_name, Institutions_application.CHE_reference_code, program_name, Institutions_application.submission_date, lkp_proceedings_desc, 
ia_proceedings.submission_date, lkp_desicion.lkp_title, applic_background_ac
FROM (Institutions_application, ia_proceedings)
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN lkp_desicion ON ia_proceedings.heqc_board_decision_ref = lkp_desicion.lkp_id
WHERE Institutions_application.application_id = ia_proceedings.application_ref
AND applic_background_ac > ''
ORDER BY HEI_name, program_name;

# Backgrounds in process

SELECT HEI_name, Institutions_application.CHE_reference_code, program_name, Institutions_application.submission_date, lkp_proceedings_desc, 
ia_proceedings.submission_date, lkp_desicion.lkp_title, applic_background, applic_background_ac
FROM (Institutions_application, ia_proceedings, tmp_aps)
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN lkp_desicion ON ia_proceedings.heqc_board_decision_ref = lkp_desicion.lkp_id
WHERE Institutions_application.application_id = ia_proceedings.application_ref
AND tmp_aps.ia_proceedings_id = ia_proceedings.ia_proceedings_id
AND tmp_aps.status = 0 AND tmp_aps.processes_ref IN (7,47, 106, 112, 163)
AND proceeding_status_ind = 0 AND applic_background_ac = ''
ORDER BY HEI_name, program_name;

# SQL 3.3: Checklisting: Applications returned to institutions
SELECT HEI_name, Institutions_application.CHE_reference_code, Institutions_application.program_name, Institutions_application.submission_date, 
	comment_on_applicationForm, processes_ref, status,  tmp_aps.`name` AS active_user, 
    (SELECT users.email FROM users, sec_UserGroups WHERE sec_group_ref = 4 AND sec_user_ref = users.user_id and users.institution_ref = Institutions_application.institution_id) AS Institutional_administrator_email,
    (SELECT users.name FROM users, sec_UserGroups WHERE sec_group_ref = 4 AND sec_user_ref = users.user_id and users.institution_ref = Institutions_application.institution_id) AS Institutional_administrator_name,
	active_processes_id, tmp_aps.application_id, ia_proceedings_id, application_status
FROM HEInstitution, Institutions_application, tmp_aps
LEFT JOIN screening ON screening.application_ref = tmp_aps.application_id
WHERE HEInstitution.HEI_id = Institutions_application.institution_id 
AND tmp_aps.application_id = Institutions_application.application_id
AND tmp_aps.application_id IN (SELECT tmp_aps.application_id FROM tmp_aps WHERE processes_ref = 7)
AND tmp_aps.processes_ref = 113 and tmp_aps.status = 0;


# SQL 3.4. Evaluators to be appointed by CESM

SELECT Institutions_application.submission_date, ia_proceedings.submission_date AS proc_submission_date, 
	screened_date,
	IF (DATEDIFF('2020-07-16', Institutions_application.submission_date) < 91, 'Current',
	IF (DATEDIFF('2020-07-16', Institutions_application.submission_date) BETWEEN 92 AND 182, '3-6 months',
	IF (DATEDIFF('2020-07-16', Institutions_application.submission_date) BETWEEN 183 AND 273, '7-9 months',
	IF (DATEDIFF('2020-07-16', Institutions_application.submission_date) BETWEEN 274 AND 365, '10-12 months',
	IF (DATEDIFF('2020-07-16', Institutions_application.submission_date) BETWEEN 366 AND 457, '13-15 months',
	IF (DATEDIFF('2020-07-16', Institutions_application.submission_date) > 457, '> 15 months', 'Undefined')))))) AS age_orig_submission,
			IF (DATEDIFF('2020-07-16', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) < 91, 'Current', 
		IF (DATEDIFF('2020-07-16', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 92 AND 182, '4-6 months',	 
		IF (DATEDIFF('2020-07-16', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 183 AND 273, '7-9 months',	 
		IF (DATEDIFF('2020-07-16', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 274 AND 365, '10-12 months',	 
		IF (DATEDIFF('2020-07-16', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 366 AND 457, '13-15 months',	 
		IF(DATEDIFF('2020-07-16', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
                ia_proceedings.screened_date)) > 457, '> 15 months', 'Undefined')))))) AS age_screening,
	lkp_proceedings_desc,  
	users.name, processes.processes_desc, 
	Institutions_application.CHE_reference_code, program_name,  
	HEI_name, 
    SpecialisationCESM_code1.Description AS CESM_code1_descr, cesm2.Description AS CESM_level2, 
    cesm3.Description AS CESM_level3, lkp_qualification_type_desc,
    recomm_user_ref, recomm_doc, recomm_access_end_date,  
    AC_Meeting.ac_start_date, ac_decision.lkp_title AS ac_outcome, heqc_start_date, 
	heqc_decision.lkp_title as heqc_outcome, heqc_outcome_approved_date, ia_proceedings.decision_doc, heqc_decision_due_date,
	conditions_submission_date, ia_proceedings.condition_doc, 
	ia_proceedings.condition_prior_due_date, ia_proceedings.condition_short_due_date, ia_proceedings.condition_long_due_date, 
	ia_proceedings.representation_doc, ia_proceedings.deferral_doc, 
	finind_complete_25, finind_complete_50, finind_complete_75, finind_complete_100, 
    tmp_aps.active_processes_id, tmp_aps.last_updated
FROM (tmp_aps, processes)
LEFT JOIN users ON users.user_id = tmp_aps.user_ref
LEFT JOIN ia_proceedings ON ia_proceedings.ia_proceedings_id = tmp_aps.ia_proceedings_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN Institutions_application ON Institutions_application.application_id = tmp_aps.application_id
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN AC_Meeting ON ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id
LEFT JOIN HEQC_Meeting ON ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id
LEFT JOIN lkp_desicion AS ac_decision ON  ac_decision.lkp_id = ia_proceedings.ac_decision_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
LEFT JOIN SpecialisationCESM_code1 ON SpecialisationCESM_code1.CESM_code1 = Institutions_application.CESM_code1
LEFT JOIN SpecialisationCESM_qualifiers AS cesm2 ON cesm2.SpecialisationCESM_qualifiers_id = CESM_level2_ref
LEFT JOIN SpecialisationCESM_qualifiers AS cesm3 ON cesm3.SpecialisationCESM_qualifiers_id = CESM_level3_ref
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
WHERE processes.processes_id = tmp_aps.processes_ref
AND tmp_aps.status = 0
AND users.institution_ref = 2
AND processes_id IN (7, 47, 106)
AND (lkp_proceedings.lkp_proceedings_id IS NULL OR lkp_proceedings.lkp_proceedings_id NOT IN (5,6,7,8))
ORDER BY processes_desc, CESM_code1_descr, CESM_level2, CESM_level3, lkp_proceedings_desc, program_name;


# SQL 3.5. Evaluators in manage and approval

SELECT puser.name, processes.processes_desc, lkp_proceedings_desc, ia_proceedings.submission_date, HEI_name, 
Institutions_application.CHE_reference_code, program_name, tmp_aps.last_updated, 
 Names, Eval_Auditors.surname, eval_contract_doc, 
Work_Number, Home_Number, Mobile_Number, evalReport_date_sent, ia_proceedings.evaluator_access_end_date, 
datediff(now(),evalReport_date_sent) as days_assigned, Persnr,
Eval_Auditors.user_ref, E_mail, euser.email AS link_heqc_user_login,  evalReport_date_completed, evalReport_doc, 
tmp_aps.active_processes_id, tmp_aps.application_id, tmp_aps.ia_proceedings_id, lkp_desicion.lkp_title, tmp_aps.status
FROM (tmp_aps, processes)
LEFT JOIN users puser ON puser.user_id = tmp_aps.user_ref
LEFT JOIN ia_proceedings ON ia_proceedings.ia_proceedings_id = tmp_aps.ia_proceedings_id
LEFT JOIN evalReport ON evalReport.ia_proceedings_ref = ia_proceedings.ia_proceedings_id
LEFT JOIN Eval_Auditors ON Eval_Auditors.Persnr = evalReport.Persnr_ref
LEFT JOIN users euser ON euser.user_id = Eval_Auditors.user_ref
LEFT JOIN lkp_desicion ON ia_proceedings.heqc_board_decision_ref = lkp_desicion.lkp_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN Institutions_application ON Institutions_application.application_id = tmp_aps.application_id
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
WHERE processes.processes_id = tmp_aps.processes_ref
AND tmp_aps.status = 0
AND tmp_aps.processes_ref IN (110, 112)
AND (ia_proceedings.lkp_proceedings_ref IN (1,2,3,4) OR ia_proceedings.lkp_proceedings_ref IS NULL)
ORDER BY ia_proceedings.evaluator_access_end_date;

# SQL 3.6. Process Outcome

SELECT Institutions_application.submission_date, ia_proceedings.submission_date AS proc_submission_date, 
	screened_date,
	DATEDIFF('2020-08-01', Institutions_application.submission_date) AS diff_orig_submission, 
	IF (DATEDIFF('2020-08-01', Institutions_application.submission_date) < 91, 'Current',
	IF (DATEDIFF('2020-08-01', Institutions_application.submission_date) BETWEEN 92 AND 182, '3-6 months',
	IF (DATEDIFF('2020-08-01', Institutions_application.submission_date) BETWEEN 183 AND 273, '7-9 months',
	IF (DATEDIFF('2020-08-01', Institutions_application.submission_date) BETWEEN 274 AND 365, '10-12 months',
	IF (DATEDIFF('2020-08-01', Institutions_application.submission_date) BETWEEN 366 AND 457, '13-15 months',
	IF (DATEDIFF('2020-08-01', Institutions_application.submission_date) > 457, '> 15 months', 'Undefined')))))) AS age_orig_submission,
	IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date) AS calc_submission_date, 
      DATEDIFF('2020-08-01', IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
			IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
                ia_proceedings.screened_date)) AS diff_screening, 
			IF (DATEDIFF('2020-08-01', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) < 91, 'Current', 
		IF (DATEDIFF('2020-08-01', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 92 AND 182, '4-6 months',	 
		IF (DATEDIFF('2020-08-01', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 183 AND 273, '7-9 months',	 
		IF (DATEDIFF('2020-08-01', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 274 AND 365, '10-12 months',	 
		IF (DATEDIFF('2020-08-01', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
				ia_proceedings.screened_date)) BETWEEN 366 AND 457, '13-15 months',	 
		IF(DATEDIFF('2020-08-01', 
			IF (ia_proceedings.screened_date is NULL OR ia_proceedings.screened_date='1000-01-01', 
				IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date), 
                ia_proceedings.screened_date)) > 457, '> 15 months', 'Undefined')))))) AS age_screening,
	lkp_proceedings_desc,  
	users.name, processes.processes_desc, 
	Institutions_application.CHE_reference_code, program_name, 
	HEI_name, 	
    AC_Meeting.ac_start_date, heqc_start_date, 
	heqc_decision.lkp_title as heqc_outcome, ia_proceedings.decision_doc, 
   	(SELECT count(*) FROM ia_conditions WHERE application_ref = Institutions_application.application_id) AS n_conditions,
	(SELECT count(*) FROM ia_conditions WHERE condition_term_ref = 'p' AND application_ref = Institutions_application.application_id) AS n_ptc,
	(SELECT count(*) FROM ia_conditions WHERE condition_met_yn_ref <> 2 AND condition_term_ref = 'p' AND application_ref = Institutions_application.application_id) AS n_outstanding_ptc,
	(SELECT count(*) FROM ia_conditions WHERE condition_term_ref = 's' AND application_ref = Institutions_application.application_id) AS n_st,
	(SELECT count(*) FROM ia_conditions WHERE condition_met_yn_ref <> 2 AND condition_term_ref = 's' AND application_ref = Institutions_application.application_id) AS n_outstanding_st,
	(SELECT count(*) FROM ia_conditions WHERE condition_term_ref = 'l' AND application_ref = Institutions_application.application_id) AS n_lt,
	(SELECT count(*) FROM ia_conditions WHERE condition_met_yn_ref <> 2 AND condition_term_ref = 'l' AND application_ref = Institutions_application.application_id) AS n_outstanding_lt,
    heqc_decision_due_date,
	conditions_submission_date, ia_proceedings.condition_doc, 
	ia_proceedings.condition_prior_due_date, ia_proceedings.condition_short_due_date, ia_proceedings.condition_long_due_date, 
	ia_proceedings.representation_doc, ia_proceedings.deferral_doc,
	tmp_aps.active_processes_id, tmp_aps.last_updated, 

	(SELECT name
		FROM (users, sec_UserGroups) 
        WHERE users.user_id = sec_UserGroups.sec_user_ref
        AND sec_UserGroups.sec_group_ref = 4 
        AND users.active =1 
        AND users.institution_ref = HEI_id) AS Institutional_Administrator_Name,
        
		(SELECT surname
		FROM (users, sec_UserGroups) 
        WHERE users.user_id = sec_UserGroups.sec_user_ref
        AND sec_UserGroups.sec_group_ref = 4 
        AND users.active =1 
        AND users.institution_ref = HEI_id) AS Institutional_Administrator_Surname,
        
		(SELECT Email 
		FROM (users, sec_UserGroups) 
        WHERE users.user_id = sec_UserGroups.sec_user_ref
        AND sec_UserGroups.sec_group_ref = 4 
        AND users.active =1 
        AND users.institution_ref = HEI_id) AS Institutional_Administrator_Email, HEI_name


FROM (tmp_aps, processes)
LEFT JOIN users ON users.user_id = tmp_aps.user_ref
LEFT JOIN ia_proceedings ON ia_proceedings.ia_proceedings_id = tmp_aps.ia_proceedings_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN Institutions_application ON Institutions_application.application_id = tmp_aps.application_id
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN AC_Meeting ON ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id
LEFT JOIN HEQC_Meeting ON ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id
LEFT JOIN lkp_desicion AS ac_decision ON  ac_decision.lkp_id = ia_proceedings.ac_decision_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
LEFT JOIN SpecialisationCESM_code1 ON SpecialisationCESM_code1.CESM_code1 = Institutions_application.CESM_code1
LEFT JOIN SpecialisationCESM_qualifiers AS cesm2 ON cesm2.SpecialisationCESM_qualifiers_id = CESM_level2_ref
LEFT JOIN SpecialisationCESM_qualifiers AS cesm3 ON cesm3.SpecialisationCESM_qualifiers_id = CESM_level3_ref
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
WHERE processes.processes_id = tmp_aps.processes_ref
AND tmp_aps.status = 0
AND users.institution_ref = 2
AND processes_id IN (170)
AND (lkp_proceedings.lkp_proceedings_id IS NULL OR lkp_proceedings.lkp_proceedings_id NOT IN (5,6,7,8))
ORDER BY heqc_outcome, decision_doc, heqc_start_date;

# SQL 3.7. Accreditation Recommendation writer's report

SELECT IF(lkp_proceedings_desc IS NULL, IF(Institutions_application.CHE_reference_code LIKE '%HEQSF%', 'Application for HEQSF-alignment','Application for programme accreditation'), 
lkp_proceedings_desc) AS Proceeding_Type, 
IF(ia_proceedings.submission_date IS NULL, Institutions_application.submission_date, ia_proceedings.submission_date) AS submission_date, HEI_name, Program_name,
    Institutions_application.CHE_reference_code, 
    IF(priv_publ = 1, 'Private','Public') AS inst_type , lkp_qualification_type_desc, 
    recomm_user_ref, CONCAT(recomm.name," ", recomm.surname) AS recomm_writer, email,recomm_doc, portal_sent_date, recomm_access_end_date, recomm_approve_comment, recomm_complete_ind ,screened_date, 
     AC_Meeting.ac_start_date, heqc_start_date, proceeding_status_date ,processes_ref, processes_desc, tmp_aps.name AS who_currently_has_the_process  , tmp_aps.last_updated , tmp_aps.status
FROM Institutions_application
LEFT JOIN ia_proceedings ON ia_proceedings.application_ref = Institutions_application.application_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = qualification_type_ref
LEFT JOIN users AS recomm ON user_id = recomm_user_ref
LEFT JOIN AC_Meeting ON ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id
LEFT JOIN HEQC_Meeting ON ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id
LEFT JOIN lkp_desicion AS ac_decision ON  ac_decision.lkp_id = ia_proceedings.ac_decision_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
LEFT JOIN SpecialisationCESM_code1 ON SpecialisationCESM_code1.CESM_code1 = Institutions_application.CESM_code1
LEFT JOIN tmp_aps ON Institutions_application.application_id = tmp_aps.application_id 
WHERE Institutions_application.submission_date > '2009-01-01'
AND (lkp_proceedings.lkp_proceedings_id IS NULL OR lkp_proceedings.lkp_proceedings_id NOT IN (5,6,7,8,9))
AND Institutions_application.CHE_reference_code NOT LIKE '%HEQSF%'
AND lkp_proceedings_desc NOT LIKE '%non-accreditation%'
AND recomm_user_ref > 1
AND processes_ref IN (160,161,162)
AND tmp_aps.status >= 1
AND tmp_aps.last_updated > '2020-01-01'
AND recomm_approve_comment IS NOT NULL
AND recomm_approve_comment <> ''
ORDER BY submission_date DESC;


-- Sorry – Please try again with below

/* # SQL 3.8.1 Identify missing letters for 2020 
List of programmes that served at a specific HEQC meeting
Identify missing letters for 2021 */

SELECT  AC_Meeting.ac_start_date, heqc_start_date, lkp_proceedings_desc, HEI_name, Institutions_application.CHE_reference_code, program_name,  
               NQF_level, min_credit_range, num_credits, lkp_mode_of_delivery_desc, heqc_decision.lkp_title, ia_proceedings.decision_doc, SAQA_id,
    (SELECT processes.processes_desc FROM tmp_aps, processes WHERE processes.processes_id = tmp_aps.processes_ref 
                              AND ia_proceedings.ia_proceedings_id = tmp_aps.ia_proceedings_id AND tmp_aps.status = 0) AS current_process
FROM (Institutions_application, ia_proceedings)
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_proceedings ON lkp_proceedings.lkp_proceedings_id = ia_proceedings.lkp_proceedings_ref
LEFT JOIN AC_Meeting ON AC_Meeting.ac_id = ia_proceedings.ac_meeting_ref
LEFT JOIN HEQC_Meeting ON HEQC_Meeting.heqc_id = ia_proceedings.heqc_meeting_ref
LEFT JOIN lkp_desicion AS heqc_decision ON  heqc_decision.lkp_id = ia_proceedings.heqc_board_decision_ref
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
LEFT JOIN NQF_level ON NQF_id = NQF_ref
LEFT JOIN lkp_mode_of_delivery ON lkp_mode_of_delivery_id = Institutions_application.mode_delivery
WHERE ia_proceedings.application_ref = Institutions_application.application_id
AND (ia_proceedings.heqc_meeting_ref) > 52  
AND lkp_proceedings_ref IN (1,2,3)
AND decision_doc = 0;


# SQL 3.9. New checklisting report 

SELECT HEI_name, CHE_reference_code, program_name, Institutions_application.submission_date, ia_proceedings.submission_date AS proceedings_submission_date,
(SELECT GROUP_CONCAT(users.email,'') FROM users, tmp_aps 
                              WHERE status = 0 AND users.user_id = tmp_aps.user_ref AND Institutions_application.application_id = tmp_aps.application_id
                              GROUP BY tmp_aps.application_id
                              ) AS in_process_with_user,
IF(SAQA_screening_report_doc > 0, 'Yes', '') AS SAQA_screening_doc_uploaded, 
IF(checklist_doc > 0, 'Yes', '') AS checklist_doc_uploaded, IF(checklist_final_doc > 0, 'Yes', '') AS checklist_final_doc_uploaded, return_to_hei_date, 
resubmission_due_date, 
IF(completed_checklisting = 1, 'Yes', '') AS completed_checklisting, users.email as checklist_user_email, re_submission_date as checklist_update_date,
application_id, ia_proceedings_id, checklist_user_ref
FROM Institutions_application
LEFT JOIN ia_proceedings ON Institutions_application.application_id = ia_proceedings.application_ref
LEFT JOIN users ON users.user_id = ia_proceedings.checklist_user_ref
LEFT JOIN HEInstitution ON HEI_id = Institutions_application.institution_id
WHERE Institutions_application.application_id IN (SELECT application_id FROM tmp_aps WHERE processes_ref IN (221, 222)
)
ORDER BY completed_checklisting DESC, resubmission_due_date, return_to_hei_date,  
checklist_final_doc, SAQA_screening_report_doc, re_submission_date, ia_proceedings_id, CHE_reference_code;


#9. User's Active or Not Report

SELECT Name, Surname, Email, last_login_date, lkp_active_desc , HEI_name, GROUP_CONCAT(distinct sec_group_desc ORDER BY
sec_group_desc SEPARATOR '\n' ) AS access_type
FROM (sec_Groups , sec_UserGroups , users) 
LEFT JOIN lnk_SecGroup_process ON `secGroup_ref` = sec_group_id
LEFT JOIN processes ON `process_ref` = processes_id
LEFT JOIN lkp_active ON `lkp_active_id` = users.active
LEFT JOIN HEInstitution ON `HEI_id` = users.institution_ref
WHERE sec_group_ref = sec_group_id
AND user_id =`sec_user_ref` 
AND lkp_active_desc = 'Active'
GROUP BY lkp_active_desc, Name, Surname, Email, last_login_date, HEI_name  
ORDER BY lkp_active_desc, Name, Surname, EMail, last_login_date, HEI_name ASC;

SELECT Name, Surname, Email, last_login_date, lkp_active_desc , HEI_name, GROUP_CONCAT(distinct sec_group_desc ORDER BY
sec_group_desc SEPARATOR '\n' ) AS access_type
FROM (sec_Groups , sec_UserGroups , users) 
LEFT JOIN lnk_SecGroup_process ON `secGroup_ref` = sec_group_id
LEFT JOIN processes ON `process_ref` = processes_id
LEFT JOIN lkp_active ON `lkp_active_id` = users.active
LEFT JOIN HEInstitution ON `HEI_id` = users.institution_ref
WHERE sec_group_ref = sec_group_id
AND user_id =`sec_user_ref` 
AND lkp_active_desc = 'Disabled'
GROUP BY lkp_active_desc, Name, Surname, Email, last_login_date, HEI_name  
ORDER BY lkp_active_desc, Name, Surname, EMail, last_login_date, HEI_name ASC;




SELECT * FROM AC_Meeting;
SELECT * FROM HEQC_Meeting;
SELECT * FROM lkp_proceedings;
SELECT * FROM lkp_desicion;




-- Additional SQLS not currently used for monitoring report.
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
#10. Replacement programmes

SELECT replacement_programme_id, replacement_programme.institution_name, replacement_programme.replacement_list_title, replacement_programme.replacement_programme, 
	IF(priv_publ = 1, 'Private', 
		IF(hei_code='H01' OR hei_code='H03' OR hei_code='H04' OR hei_code='H25' OR hei_code='H18' OR hei_code='H16', 'UoT', 
			IF(hei_code='H07' OR hei_code='H10' OR hei_code='H17' OR hei_code='H19' OR hei_code='H22','Comprehensive',
				IF(hei_code='H14','UNISA','Research')))) AS inst_catg, 
	Institutions_application.CHE_reference_code, program_name, lkp_mode_of_delivery_desc, lkp_qualification_type_desc,
   	Institutions_application.submission_date,
    IF(Institutions_application.submission_date = '1000-01-01' OR Institutions_application.submission_date IS NULL, '4 Not submitted', 
    IF(Institutions_application.submission_date <= '2018-03-31', '1 Prior 31 March', 
    IF(Institutions_application.submission_date BETWEEN '2018-04-01' AND '2018-05-31', '2 Prior 31 May 2018', 
		'3 After 31 May 2018'))) AS submission_status,  
    IF(Institutions_application.submission_date = '1000-01-01' OR Institutions_application.submission_date IS NULL, '3 Not submitted', 
    IF(Institutions_application.submission_date <= '2018-05-31', '1 To be processed by June', 
		'2 Late submission')) AS process_status,  
    AC_Meeting_date AS final_outcome_date,
	(SELECT lkp_title FROM lkp_desicion WHERE lkp_id = Institutions_application.AC_desision) AS final_outcome,   

	(SELECT GROUP_CONCAT(processes.processes_desc,'') FROM processes, tmp_aps 
		WHERE status = 0 AND processes.processes_id = tmp_aps.processes_ref AND processes_ref NOT IN (4, 9, 10, 41, 52, 57, 92, 100, 103, 105, 107, 120, 145, 146, 147, 150, 153, 157, 158, 164,  109, 102, 166, 154, 69, 183, 95, 19, 197, 172,
175, 176, 177, 178, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 202, 204, 208 ) AND Institutions_application.application_id = tmp_aps.application_id
		GROUP BY tmp_aps.application_id
		) AS in_process,

    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 1 AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_recomm_appoint,
    (SELECT max(AC_Meeting.ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_ac_outcome,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_ac_outcome,
	(SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_ac_outcome,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_ac_outcome,
	(SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_heqc_outcome,
	Institutions_application.application_id 
FROM replacement_programme
LEFT JOIN Institutions_application ON (Institutions_application.institution_id = replacement_programme.hei_id 
	AND TRIM(UPPER(Institutions_application.program_name)) = TRIM(UPPER(replacement_programme.replacement_programme)) 
    AND submission_date > '2009-01-01' AND Institutions_application.CHE_reference_code not in ('H/H01/E088CAN', 'H/H03/E024CAN','H/H04/E043CAN','H/H11/E101CAN', 'H/H07/E162CAN'))
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
LEFT JOIN lkp_mode_of_delivery ON lkp_mode_of_delivery_id = Institutions_application.mode_delivery
ORDER BY replacement_programme.institution_name, replacement_programme.replacement_programme

#10.1 Replacement programme report for institutions

SELECT replacement_programme_id, replacement_programme.institution_name, replacement_programme.replacement_list_title,  
	Institutions_application.CHE_reference_code, program_name, lkp_mode_of_delivery_desc, 
   	Institutions_application.submission_date,
    IF(Institutions_application.submission_date = '1000-01-01' OR Institutions_application.submission_date IS NULL, '4 Not submitted', 
    IF(Institutions_application.submission_date <= '2018-03-31', '1 Prior 31 March', 
    IF(Institutions_application.submission_date BETWEEN '2018-04-01' AND '2018-05-31', '2 Prior 31 May 2018', 
		'3 After 31 May 2018'))) AS submission_status,  
    AC_Meeting_date AS final_outcome_date,
	(SELECT lkp_title FROM lkp_desicion WHERE lkp_id = Institutions_application.AC_desision) AS final_outcome,   
    (SELECT AC_Meeting.ac_start_date FROM AC_Meeting, ia_proceedings WHERE ia_proceedings.ac_meeting_ref > 0 AND ac_decision_ref > 0 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_ac_date,
 	(SELECT lkp_title FROM lkp_desicion, ia_proceedings WHERE ia_proceedings.ac_meeting_ref > 0 AND ac_decision_ref > 0 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_ac_outcome,
    (SELECT heqc_start_date FROM HEQC_Meeting, ia_proceedings WHERE ia_proceedings.heqc_meeting_ref > 0 AND ia_proceedings.heqc_board_decision_ref > 0 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_heqc_date,
	(SELECT lkp_title FROM lkp_desicion, ia_proceedings WHERE ia_proceedings.heqc_meeting_ref > 0 AND ia_proceedings.heqc_board_decision_ref > 0 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_heqc_outcome,
 (SELECT GROUP_CONCAT(processes.processes_desc,'') FROM processes, tmp_aps 
		WHERE status = 0 AND processes.processes_id = tmp_aps.processes_ref AND processes_ref NOT IN (4, 9, 10, 41, 52, 57, 92, 100, 103, 105, 107, 120, 145, 146, 147, 150, 153, 157, 158, 164,  109, 102, 166, 154, 69, 183, 95, 19, 197, 172,
175, 176, 177, 178, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 202, 204, 208 ) AND Institutions_application.application_id = tmp_aps.application_id
		GROUP BY tmp_aps.application_id
		) AS in_process,
  (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 1 AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_recomm_appoint,
    (SELECT max(AC_Meeting.ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_ac_outcome,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_ac_outcome,
	(SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_ac_outcome,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_ac_outcome,
	(SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_heqc_outcome,
	Institutions_application.application_id 
FROM replacement_programme
LEFT JOIN Institutions_application ON (Institutions_application.institution_id = replacement_programme.hei_id 
	AND TRIM(UPPER(Institutions_application.program_name)) = TRIM(UPPER(replacement_programme.replacement_programme)) 
    AND submission_date > '2009-01-01' AND Institutions_application.CHE_reference_code not in ('H/H01/E088CAN', 'H/H03/E024CAN','H/H04/E043CAN',
    'H/H11/E101CAN', 'H/H07/E162CAN', 'H/H13/E018CAN',
	'H/H07/E112CAN', 'H/H01/E082CAN', 'H/H13/E020CAN'
))
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
LEFT JOIN lkp_mode_of_delivery ON lkp_mode_of_delivery_id = Institutions_application.mode_delivery
ORDER BY replacement_programme.institution_name, replacement_programme.replacement_programme



-- Replacements identified by matching on title
-- May match to a submitted programme twice 
	-- e.g A programme with the same title submitted more than once e.g. Diploma in Pulp and Paper Technology (DUT) because it was not accredited.
    -- Programme submitted in distance and contact mode of delivery
-- May have 2 proceedings for 'New application'.  Shouldn't though.  This is dirty data e.g. H/H16/E134CAN.  Adding Distinct to eleiminate 1.

#11. Nursing programmes
SELECT application_id, HEI_name, 
	(SELECT DISTINCT public_nursing_college FROM users WHERE users.institution_ref = Institutions_application.institution_id AND public_nursing_college = 2) AS public_nursing_college, 
	'', 
	IF( LOCATE('PN', hei_code) > 0, 'Public Nursing College', IF(priv_publ = 1, 'Private', 
		IF(hei_code='H01' OR hei_code='H03' OR hei_code='H04' OR hei_code='H25' OR hei_code='H18' OR hei_code='H16', 'UoT', 
			IF(hei_code='H07' OR hei_code='H10' OR hei_code='H17' OR hei_code='H19' OR hei_code='H22','Comprehensive',
				IF(hei_code='H14','UNISA','Research'))))) AS inst_catg, 
	Institutions_application.CHE_reference_code, program_name, lkp_mode_of_delivery_desc, lkp_qualification_type_desc,
   	Institutions_application.submission_date,
    (SELECT AC_Meeting.ac_start_date FROM AC_Meeting, ia_proceedings WHERE ia_proceedings.ac_meeting_ref > 0 AND ac_decision_ref > 0 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_ac_date,
 	(SELECT lkp_title FROM lkp_desicion, ia_proceedings WHERE ia_proceedings.ac_meeting_ref > 0 AND ac_decision_ref > 0 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_ac_outcome,
    (SELECT heqc_start_date FROM HEQC_Meeting, ia_proceedings WHERE ia_proceedings.heqc_meeting_ref > 0 AND ia_proceedings.heqc_board_decision_ref > 0 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_heqc_date,
	(SELECT lkp_title FROM lkp_desicion, ia_proceedings WHERE ia_proceedings.heqc_meeting_ref > 0 AND ia_proceedings.heqc_board_decision_ref > 0 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_heqc_outcome,
    AC_Meeting_date AS final_outcome_date,
	(SELECT lkp_title FROM lkp_desicion WHERE lkp_id = Institutions_application.AC_desision) AS final_outcome,   
	(SELECT GROUP_CONCAT(processes.processes_desc,'') FROM processes, tmp_aps 
		WHERE status = 0 AND processes.processes_id = tmp_aps.processes_ref AND processes_ref NOT IN (4, 9, 10, 41, 52, 57, 92, 100, 103, 105, 107, 120, 145, 146, 147, 150, 153, 157, 158, 164,  109, 102, 166, 154, 69, 183, 95, 19, 197, 172,
175, 176, 177, 178, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 202, 204, 208 ) AND Institutions_application.application_id = tmp_aps.application_id
		GROUP BY tmp_aps.application_id
		) AS in_process,

    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 1 AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_recomm_appoint,
    (SELECT max(AC_Meeting.ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_ac_date,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_ac_date,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_ac_date,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_ac_date,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_heqc_outcome,

	Institutions_application.application_id 
FROM Institutions_application
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
LEFT JOIN lkp_mode_of_delivery ON lkp_mode_of_delivery_id = Institutions_application.mode_delivery
WHERE (program_name LIKE '%Nurs%' OR program_name LIKE '%Midwif%')
AND submission_date > '1000-01-01'
ORDER BY CHE_reference_code


SELECT * FROM screening 
WHERE application_ref = 7011;


#12. Programme status for all programmes submitted for accreditation that were not cancelled.

SELECT HEI_name, Institutions_application.CHE_reference_code, program_name, lkp_mode_of_delivery_desc, 
   	Institutions_application.submission_date,
    IF(Institutions_application.submission_date = '1000-01-01' OR Institutions_application.submission_date IS NULL, '4 Not submitted', 
    IF(Institutions_application.submission_date <= '2018-03-31', '1 Prior 31 March', 
    IF(Institutions_application.submission_date BETWEEN '2018-04-01' AND '2018-05-31', '2 Prior 31 May 2018', 
		'3 After 31 May 2018'))) AS submission_status,  
    AC_Meeting_date AS final_outcome_date,
	(SELECT lkp_title FROM lkp_desicion WHERE lkp_id = Institutions_application.AC_desision) AS final_outcome,   
    (SELECT AC_Meeting.ac_start_date FROM AC_Meeting, ia_proceedings WHERE ia_proceedings.ac_meeting_ref > 0 AND ac_decision_ref > 0 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_ac_date,
 	(SELECT lkp_title FROM lkp_desicion, ia_proceedings WHERE ia_proceedings.ac_meeting_ref > 0 AND ac_decision_ref > 0 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_ac_outcome,
    (SELECT heqc_start_date FROM HEQC_Meeting, ia_proceedings WHERE ia_proceedings.heqc_meeting_ref > 0 AND ia_proceedings.heqc_board_decision_ref > 0 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_heqc_date,
	(SELECT lkp_title FROM lkp_desicion, ia_proceedings WHERE ia_proceedings.heqc_meeting_ref > 0 AND ia_proceedings.heqc_board_decision_ref > 0 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref ORDER BY ia_proceedings_id DESC LIMIT 1) AS last_heqc_outcome,
 (SELECT GROUP_CONCAT(processes.processes_desc,'') FROM processes, tmp_aps 
		WHERE status = 0 AND processes.processes_id = tmp_aps.processes_ref AND processes_ref NOT IN (4, 9, 10, 41, 52, 57, 92, 100, 103, 105, 107, 120, 145, 146, 147, 150, 153, 157, 158, 164,  109, 102, 166, 154, 69, 183, 95, 19, 197, 172,
175, 176, 177, 178, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 202, 204, 208 ) AND Institutions_application.application_id = tmp_aps.application_id
		GROUP BY tmp_aps.application_id
		) AS in_process,
  (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 1 AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_recomm_appoint,
    (SELECT max(AC_Meeting.ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_ac_outcome,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 1 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS applic_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
			WHERE lkp_proceedings_ref = 1 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
            ) AS applic_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 3 AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_ac_outcome,
	(SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 3 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS repr_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 3 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
 			GROUP BY application_ref
		) AS repr_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 4 AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_ac_outcome,
    (SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 4 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS cond_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 4 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
        ) AS cond_heqc_outcome,

    (SELECT max(ia_proceedings.submission_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_submission_date,
    (SELECT max(portal_sent_date) FROM ia_proceedings WHERE lkp_proceedings_ref = 2 AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_recomm_appoint,
    (SELECT max(ac_start_date) FROM AC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.ac_meeting_ref = AC_Meeting.ac_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_ac_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.ac_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_ac_outcome,
	(SELECT max(heqc_start_date) FROM HEQC_Meeting, ia_proceedings WHERE lkp_proceedings_ref = 2 AND ia_proceedings.heqc_meeting_ref = HEQC_Meeting.heqc_id AND Institutions_application.application_id = ia_proceedings.application_ref) AS defer_heqc_date,
	(SELECT GROUP_CONCAT(lkp_title,'') FROM lkp_desicion, ia_proceedings 
		WHERE lkp_proceedings_ref = 2 AND lkp_id = ia_proceedings.heqc_board_decision_ref AND Institutions_application.application_id = ia_proceedings.application_ref
			GROUP BY application_ref
        	) AS defer_heqc_outcome,
	Institutions_application.application_id 
FROM Institutions_application
LEFT JOIN HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_qualification_type ON lkp_qualification_type_id = Institutions_application.qualification_type_ref
LEFT JOIN lkp_mode_of_delivery ON lkp_mode_of_delivery_id = Institutions_application.mode_delivery
WHERE Institutions_application.submission_date > '2009-01-01'
AND application_status <> -1
ORDER BY last_ac_date;

# 12.1 All application conditions and met or not

SELECT HEI_name, Institutions_application.CHE_reference_code, program_name, application_status, submission_date, decision_reason_condition, lkp_condition_term_desc, 
		IF (condition_met_yn_ref = 2, 'Has been met', 
			IF (@val:=(SELECT recomm_condition_met_yn_ref FROM ia_conditions_proceedings, ia_proceedings WHERE ia_proceedings.ia_proceedings_id = ia_conditions_proceedings.ia_proceedings_ref AND ia_proceedings.application_ref = Institutions_application.application_id AND ia_conditions_proceedings.decision_reason_condition = ia_conditions.decision_reason_condition AND recomm_condition_met_yn_ref = 2) = 2, 'Has been met', 
            'Not yet met')),
    (SELECT users.email FROM users, sec_UserGroups WHERE sec_group_ref = 4 AND sec_user_ref = users.user_id and users.institution_ref = Institutions_application.institution_id) AS Institutional_administrator_email,
    (SELECT users.name FROM users, sec_UserGroups WHERE sec_group_ref = 4 AND sec_user_ref = users.user_id and users.institution_ref = Institutions_application.institution_id) AS Institutional_administrator_name
FROM (heqcsupport.Institutions_application, heqcsupport.ia_conditions)
LEFT JOIN heqcsupport.HEInstitution ON Institutions_application.institution_id = HEInstitution.HEI_id
LEFT JOIN lkp_condition_term ON lkp_condition_term_id = condition_term_ref
WHERE ia_conditions.application_ref = Institutions_application.application_id
ORDER BY HEI_name, program_name, CHE_reference_code, decision_reason_condition

