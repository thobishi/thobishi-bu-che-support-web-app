<br>
<br>
<table border='0'>
<tr><td>&nbsp;</td><td>
	<table border='0'>
	<tr>
		<td>Title:</td>
		<td><%=$this->showField("title_ref")%></td>
	</tr>
	<tr>
		<td>Name:</td>
		<td><%=$this->showField("name")%></td>
	</tr>
	<tr>
		<td>Surname:</td>
		<td><%=$this->showField("surname")%></td>
	</tr>
	<tr>
		<td>E-mail:</td>
		<td><%=$this->showField("email")%></td>
	</tr>
	<tr>
		<td>Institution:</td>
		<td><%=$this->showField("institution_ref")%></td>
	</tr>
	<tr>
		<td>Contact Number:</td>
		<td><%=$this->showField("contact_nr")%></td>
	</tr>
	<tr>
		<td>Active:</td>
		<td><%=$this->showField("active")%></td>
	</tr>
	</table>
</td></tr></table>
