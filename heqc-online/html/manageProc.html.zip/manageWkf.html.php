<br>
<br>
<table border='0'>
<tr><td>&nbsp;</td><td>
	<table border='0'>
	Please select a process to manage:<br><br>
<%
$this->formFields["proc_nr"]->fieldValue = $_POST["proc_nr"];
$this->showField("proc_nr");
$this->showField("wkf_name");

$SQL = "SELECT * FROM work_flows WHERE processes_ref=".$_POST["proc_nr"]." ORDER BY sec_no";
$rs = mysql_query($SQL);
if (mysql_num_rows($rs) > 0){
	while ($row = mysql_fetch_array($rs)){
		echo "<a href='javascript:setProc(\"".$row["work_flows_id"]."\");moveto(\"next\");'>".$row["template"]." - <em>(<a href='javascript:setWkfRef(\"".$row["template"]."\");goto(63);'>Edit Fields</a>)</em><br>";
	
	}

}
%>
<br><br>
<a href='javascript:setProc("NEW");moveto("next");'>[Add new workflow]</a><br>
<script>
function setProc(val){
	document.defaultFrm.CHANGE_TO_RECORD.value='work_flows|'+val;
}

function setWkfRef (val) {
	document.defaultFrm.wkf_name.value = val;
}

</script>


	</table>
</td></tr></table>
