<?
$this->formFields["proc_nr"]->fieldValue = $_POST["proc_nr"];
$this->showField("proc_nr");

if (! ($this->formFields["processes_ref"]->fieldValue > "") ) {
	 $this->formFields["processes_ref"]->fieldValue = $this->formFields["proc_nr"]->fieldValue;
}
?>
<br>
<br>
<table border='0'>
<tr><td>&nbsp;</td><td>
	<table border='0'>
	<tr>
		<td>Process Ref:</td>
		<td><%=$this->showField("processes_ref")%></td>
	</tr><tr>
		<td>Sequence:</td>
		<td><%=$this->showField("sec_no")%></td>
	</tr><tr>
		<td>Workflow type:</td>
		<td><%=$this->showField("workFlowType_ref")%></td>
	</tr><tr>
		<td>Command:</td>
		<td><%=$this->showField("command")%></td>
	</tr><tr>
		<td>Condition:</td>
		<td><%=$this->showField("condition")%></td>
	</tr><tr>
		<td>Template:</td>
		<td><%=$this->showField("template")%></td>
	</tr><tr>
		<td>TaskName:</td>
		<td><%=$this->showField("taskName")%></td>
	</tr><tr>
		<td>Validation:</td>
		<td><%=$this->showField("validation")%></td>
	</tr><tr>
		<td>Security Level:</td>
		<td><%=$this->showField("securityLevel")%></td>
	</tr><tr>
		<td>Html name:</td>
		<td><%=$this->showField("html_name")%></td>
	</tr><tr>
		<td>dbTableName:</td>
		<td><%=$this->showField("template_dbTableName")%></td>
	</tr>
	<tr>
		<td>dbTableKeyField:</td>
		<td><%=$this->showField("template_dbTableKeyField")%></td>
	</tr>
	</table>
</td></tr></table>