<br>
<br>
<table border='0'>
<tr><td>&nbsp;</td><td>
	<table border='0'>
	Please select a group to manage:<br><br>
<%
$SQL = "SELECT * FROM sec_Groups WHERE 1";
$rs = mysql_query($SQL);
if (mysql_num_rows($rs) > 0){
	while ($row = mysql_fetch_array($rs)){
		echo "<a href='javascript:setGroup(\"".$row[0]."\")'>".$row[1]."</a><br>";
	
	}

}
%>
<input type='hidden' name='groupID'>
<script>
function setGroup(val){
	document.defaultFrm.groupID.value = val;
	document.defaultFrm.submit();
}
</script>


	</table>
</td></tr></table>
