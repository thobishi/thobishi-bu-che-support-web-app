<br>
<br>
<table border='0'>
<tr><td>&nbsp;</td><td>
	<table border='0'>
	<tr>
		<td>Process Number:</td>
		<td><%=$this->showField("processes_id")%></td>
	</tr><tr>
		<td>Process Description:</td>
		<td><%=$this->showField("processes_desc")%></td>
	</tr><tr>
		<td>Comment:</td>
		<td><%=$this->showField("processes_comment")%></td>
	</tr><tr>
		<td>Due duration:</td>
		<td><%=$this->showField("processes_due_duration")%></td>
	</tr><tr>
		<td>Expiry duration:</td>
		<td><%=$this->showField("processes_expiry_duration")%></td>
	</tr><tr>
		<td>Descriptive fields:</td>
		<td><%=$this->showField("desc_fields")%></td>
	</tr><tr>
		<td>Write current user to db:</td>
		<td><%=$this->showField("write_current_user_to_db")%></td>
	</tr><tr>
		<td>Post process field:</td>
		<td><%=$this->showField("post_process_field")%></td>
	</tr><tr>
		<td>CurrentFlow next process ref:</td>
		<td><%=$this->showField("currentFlow_next_process_ref")%></td>
	</tr><tr>
		<td>CurrentFlow settings key:</td>
		<td><%=$this->showField("currentFlow_settings_key")%></td>
	</tr><tr>
		<td>CurrentFlow message:</td>
		<td><%=$this->showField("currentFlow_message")%></td>
	</tr><tr>
		<td>CurrentFlow skip test:</td>
		<td><%=$this->showField("currentFlow_skip_test")%></td>
	</tr>
	<tr>
		<td>Spawn user next process_ref:</td>
		<td><%=$this->showField("spawnUser_next_process_ref")%></td>
	</tr><tr>
		<td>Spawn user settings key:</td>
		<td><%=$this->showField("spawnUser_settings_key")%></td>
	</tr><tr>
		<td>Spawn user message:</td>
		<td><%=$this->showField("spawnUser_message")%></td>
	</tr><tr>
		<td>Spawn user activeDate:</td>
		<td><%=$this->showField("spawnUser_activeDate")%></td>
	</tr><tr>
		<td>May go previous:</td>
		<td><%=$this->showField("may_go_previous")%></td>
	</tr><tr>
		<td>Keep workflow settings:</td>
		<td><%=$this->showField("keep_workflow_settings")%></td>
	</tr><tr>
		<td>Menu is item:</td>
		<td><%=$this->showField("menu_is_item")%></td>
	</tr><tr>
		<td>Menu perant:</td>
		<td><%=$this->showField("menu_perant")%></td>
	</tr><tr>
		<td>Menu alt name:</td>
		<td><%=$this->showField("menu_alt_name")%></td>
	</tr><tr>
		<td>Menu in menu:</td>
		<td><%=$this->showField("menu_in_menu")%></td>
	</tr><tr>
		<td>On item click:</td>
		<td><%=$this->showField("on_item_click")%></td>
	</tr><tr>
		<td>Menu sequence number:</td>
		<td><%=$this->showField("menu_sequence_number")%></td>
	</tr><tr>
		<td>Proscess supervisor:</td>
		<td><%=$this->showField("proscess_supervisor")%></td>
	</tr>
	</table>
</td></tr></table>