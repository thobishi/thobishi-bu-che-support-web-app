<br>
<br>
<input type='hidden' name='groupID' value="<%=$_POST["groupID"]%>">
<table border='0'>
<tr><td>&nbsp;</td><td>
	<table border='0'>
	<tr>
	<td valign="top"><strong>Group name:</strong> </td>
<%
$SQL = "SELECT * FROM sec_Groups WHERE sec_group_id=".$_POST["groupID"];
$rs = mysql_query($SQL);
if (mysql_num_rows($rs) > 0){
	while ($row = mysql_fetch_array($rs)){
		echo "<td><input type='text' value='".$row[1]."' name='groupName'</td>";
	
	}

}
%>
</tr>
	<tr>
	<td valign="top"><strong>Group members:</strong> </td>
	<td>
	<table border="0"><tr><td><strong>Selected</strong><br>
<%
$SQL = "SELECT user_id,name,surname FROM sec_UserGroups,users WHERE sec_user_ref=user_id and sec_group_ref=".$_POST["groupID"]." ORDER BY surname";
$tmpArray = array();
$rs = mysql_query($SQL);
if (mysql_num_rows($rs) > 0){
	%>
	<select name="members[]" multiple size="10">
	<%
	while ($row = mysql_fetch_array($rs)){
	array_push($tmpArray,$row["user_id"])
	%>
	<option value="<%=$row["user_id"]%>"><%=$row["name"]%> <%=$row["surname"]%></option>
	<%
	}
}
	%>
	</select>
	</td><td>	
	<input onclick="javascript:removeMembers(document.defaultFrm.elements['Allmembers'],document.defaultFrm.elements['members[]']);" type="Button" value=">>"><br>
	<input onclick="javascript:addMembers(document.defaultFrm.elements['Allmembers'],document.defaultFrm.elements['members[]']);" type="Button" value="<<">
</td>
	<td><strong>Available<br></strong>
<%
$SQL = "SELECT user_id,name,surname FROM users WHERE user_id not in('".implode(',',$tmpArray)."') ORDER BY name";
$rs = mysql_query($SQL);
if (mysql_num_rows($rs) > 0){
	%>
	<select name="Allmembers" multiple size="10">
	<%
	while ($row = mysql_fetch_array($rs)){
	%>
	<option value="<%=$row["user_id"]%>"><%=$row["name"]%> <%=$row["surname"]%></option>
	<%
	}
	%>
	</select>
	<%
}
%>
	</td></tr></table></td>
</tr>
	<tr>
	<td valign="top"><strong>Group processes:</strong> </td>
	<td>
	<table border="0"><tr><td><strong>Selected</strong><br>
<%
$SQL = "SELECT processes_id,processes_desc FROM processes,lnk_SecGroup_process WHERE process_ref=processes_id and secGroup_ref=".$_POST["groupID"]." ORDER BY processes_desc";
$rs = mysql_query($SQL);
$tmpArray = array();
if (mysql_num_rows($rs) > 0){
	%>
	<select name="processes[]" multiple size="10">
	<%
	while ($row = mysql_fetch_array($rs)){
	array_push($tmpArray,$row["processes_id"])
	%>
	<option value="<%=$row["processes_id"]%>"><%=$row["processes_desc"]%></option>
	<%
	}
}
	%>
	</select>
	</td><td>
	<input onclick="javascript:removeMembers(document.defaultFrm.elements['Allprocesses'],document.defaultFrm.elements['processes[]']);" type="Button" value=">>"><br>
	<input onclick="javascript:addMembers(document.defaultFrm.elements['Allprocesses'],document.defaultFrm.elements['processes[]']);" type="Button" value="<<">
	</td>
	<td><strong>Available<br></strong>
<%
$SQL = "SELECT processes_id,processes_desc FROM processes WHERE processes_id not in('".implode(',',$tmpArray)."') and menu_is_item='Yes' ORDER BY processes_desc";
$rs = mysql_query($SQL);
if (mysql_num_rows($rs) > 0){
	%>
	<select name="Allprocesses" multiple size="10">
	<%
	while ($row = mysql_fetch_array($rs)){
	%>
	<option value="<%=$row["processes_id"]%>"><%=$row["processes_desc"]%></option>
	<%
	}
	%>
	</select>
	<%
}
%>
	</td></tr></table></td>
</tr>
</table>
</td></tr></table>

<script>
function selectAll() {
	sLength = document.defaultFrm.elements['members[]'].length;
	for (i=0; i<sLength; i++) {
		document.defaultFrm.elements['members[]'].options[i].selected = true;
	}
	sLength = document.defaultFrm.elements['processes[]'].length;
	for (i=0; i<sLength; i++) {
		document.defaultFrm.elements['processes[]'].options[i].selected = true;
	}
	
}

function addMembers(obj,obj2) {
	sLen = obj.length;
	for ( i=0; i<sLen; i++){
		if (obj.options[i].selected == true ) {
			obj2Len = obj2.length;
			obj2.options[obj2Len]= new Option(obj.options[i].text, obj.options[i].value);
		}
	}
	for ( i=(sLen-1); i>=0; i--) {
		if (obj.options[i].selected == true ) {
			obj.options[i] = null;
		}
	}
}
function removeMembers(obj,obj2) {
	sLen = obj2.length;
	for ( i=0; i<sLen ; i++){
		if (obj2.options[i].selected == true ) {
			objLen = obj.length;
			obj.options[objLen]= new Option(obj2.options[i].text, obj2.options[i].value);
		}
	}
	for ( i = (sLen -1); i>=0; i--){
		if (obj2.options[i].selected == true ) {
			obj2.options[i] = null;
		}
	}
}


</script>