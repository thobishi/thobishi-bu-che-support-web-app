<br>
<br>
<table border='0'>
<tr><td>&nbsp;</td><td>
	<table border='0'>
	Please select a user to manage:<br><br>
<%
$SQL = "SELECT * FROM users WHERE active=1 ORDER BY surname,name";
$rs = mysql_query($SQL);
if (mysql_num_rows($rs) > 0){
	while ($row = mysql_fetch_array($rs)){
		echo "<a href='javascript:setUser(\"".$row["user_id"]."\");moveto(\"next\");'>".$row["surname"]." ".$row["name"]."</a><br>";
	
	}

}
%>
<br><br>
<a href='javascript:setUser("NEW");moveto("next");'>[Add new user]</a><br>
<script>
function setUser(val){
	document.defaultFrm.CHANGE_TO_RECORD.value='users|'+val;
}
</script>


	</table>
</td></tr></table>
